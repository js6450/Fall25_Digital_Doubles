"""
01: Face Detection with Haar Cascades
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Introduction to face detection using Haar Cascade classifiers.
This is a classical computer vision approach that's fast and lightweight.

Concepts:
- Haar Cascade classifier (Viola-Jones algorithm)
- detectMultiScale() parameters
- Drawing bounding boxes
- Multiple face detection

Usage:
    python 01_face_detection_haar.py

Controls:
    - Press any key to move to next image
    - Press 'q' to quit

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.detection_visualizer import DetectionVisualizer


class HaarFaceDetector:
    """
    Face detector using Haar Cascade classifier.
    """
    
    def __init__(self):
        """Initialize Haar Cascade face detector."""
        # Load pre-trained Haar Cascade for frontal faces
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        
        if self.face_cascade.empty():
            raise IOError("Failed to load Haar Cascade classifier")
        
        # Initialize visualizer
        self.viz = DetectionVisualizer()
        
        print("Haar Cascade Face Detector initialized")
        print(f"Model loaded from: {cascade_path}")
    
    def detect_faces(self, image, scale_factor=1.1, min_neighbors=5, min_size=(30, 30)):
        """
        Detect faces in an image using Haar Cascade.
        
        Args:
            image: Input image (BGR format)
            scale_factor: How much image size is reduced at each scale
                         (1.1 = 10% reduction, smaller = more thorough but slower)
            min_neighbors: How many neighbors each candidate should have
                          (higher = fewer false positives, but might miss faces)
            min_size: Minimum face size (width, height) in pixels
        
        Returns:
            faces: Array of (x, y, w, h) for each detected face
        """
        # Convert to grayscale (Haar Cascades work on grayscale)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=scale_factor,
            minNeighbors=min_neighbors,
            minSize=min_size,
            flags=cv2.CASCADE_SCALE_IMAGE
        )
        
        return faces
    
    def draw_detections(self, image, faces, show_count=True):
        """
        Draw face detection results on image.
        
        Args:
            image: Image to draw on
            faces: Array of face rectangles (x, y, w, h)
            show_count: Whether to show face count
        
        Returns:
            image: Image with detections drawn
        """
        # Make a copy to avoid modifying original
        result = image.copy()
        
        # Draw each face
        for i, (x, y, w, h) in enumerate(faces):
            # Draw bounding box using visualizer
            label = f"Face {i+1}"
            self.viz.draw_face(result, x, y, w, h, label=label)
        
        # Draw face count
        if show_count:
            self.viz.draw_detection_count(
                result, 
                len(faces), 
                label="Faces Detected",
                position=(10, 30)
            )
        
        return result


def demonstrate_parameter_effects(detector, image):
    """
    Demonstrate how different parameters affect detection.
    
    Shows 4 different parameter combinations side-by-side.
    """
    h, w = image.shape[:2]
    
    # Create 2x2 grid
    grid = np.zeros((h*2, w*2, 3), dtype=np.uint8)
    
    # Parameter sets to test
    params = [
        {"scale_factor": 1.1, "min_neighbors": 3, "label": "Sensitive (1.1, 3)"},
        {"scale_factor": 1.1, "min_neighbors": 5, "label": "Balanced (1.1, 5)"},
        {"scale_factor": 1.3, "min_neighbors": 5, "label": "Fast (1.3, 5)"},
        {"scale_factor": 1.1, "min_neighbors": 8, "label": "Conservative (1.1, 8)"},
    ]
    
    positions = [(0, 0), (0, 1), (1, 0), (1, 1)]
    
    for param, (row, col) in zip(params, positions):
        # Detect faces with these parameters
        faces = detector.detect_faces(
            image,
            scale_factor=param["scale_factor"],
            min_neighbors=param["min_neighbors"]
        )
        
        # Draw results
        result = detector.draw_detections(image, faces, show_count=False)
        
        # Add parameter label
        label_text = f"{param['label']} - {len(faces)} faces"
        cv2.putText(result, label_text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Place in grid
        y_start = row * h
        x_start = col * w
        grid[y_start:y_start+h, x_start:x_start+w] = result
    
    return grid


def main():
    """
    Main function to demonstrate Haar Cascade face detection.
    """
    print("\n" + "="*60)
    print("HAAR CASCADE FACE DETECTION")
    print("="*60)
    
    # Initialize detector
    detector = HaarFaceDetector()
    
    # Get image files
    resources_dir = Path(__file__).parent / "resources"
    image_files = sorted(resources_dir.glob("*.jpg"))
    
    if not image_files:
        print("Error: No images found in resources folder")
        return
    
    print(f"\nFound {len(image_files)} images")
    print("\nControls:")
    print("  - Press any key to see next image")
    print("  - Press 'q' to quit")
    print("  - Press 'p' to see parameter comparison")
    
    # Process each image
    for img_path in image_files:
        print(f"\nProcessing: {img_path.name}")
        
        # Load image
        image = cv2.imread(str(img_path))
        if image is None:
            print(f"  Error loading {img_path.name}, skipping...")
            continue
        
        # Detect faces with default parameters
        print("  Detecting faces...")
        faces = detector.detect_faces(image)
        print(f"  Found {len(faces)} face(s)")
        
        # Draw results
        result = detector.draw_detections(image, faces)
        
        # Display
        window_name = f"Haar Face Detection - {img_path.name}"
        cv2.imshow(window_name, result)
        
        # Wait for key
        key = cv2.waitKey(0)
        
        # Check if user wants parameter comparison
        if key == ord('p'):
            print("  Showing parameter comparison...")
            grid = demonstrate_parameter_effects(detector, image)
            cv2.imshow("Parameter Comparison", grid)
            cv2.waitKey(0)
            cv2.destroyWindow("Parameter Comparison")
        
        # Quit if 'q' pressed
        if key == ord('q'):
            print("\nQuitting...")
            break
        
        cv2.destroyWindow(window_name)
    
    cv2.destroyAllWindows()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ Haar Cascades are FAST - suitable for real-time")
    print("✓ Work well on frontal faces with good lighting")
    print("✓ Parameters affect detection sensitivity:")
    print("  - Lower scaleFactor = more thorough but slower")
    print("  - Higher minNeighbors = fewer false positives")
    print("✗ Limited accuracy with angles, occlusion, poor lighting")
    print("✗ Many false positives possible")
    print("\nNext: Try 02_face_detection_dnn.py for deep learning approach")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
