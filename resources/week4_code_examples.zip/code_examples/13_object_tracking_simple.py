"""
13: Simple Object Tracking
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Track specific objects in real-time and collect statistics.
Filter by object class and track counts, positions, and movement over time.

Concepts:
- Object tracking by detection
- Class-based filtering
- Temporal data collection
- Statistics and visualization

Usage:
    python 13_object_tracking_simple.py

Controls:
    - '1-9' - Select class to track (1=person, 2=cup, etc.)
    - 'a' - Track all objects
    - 'g' - Toggle statistics graph
    - 'r' - Reset statistics
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Track yourself (person class)
    - Track your cup as you move it
    - Track multiple objects entering/leaving frame
    - See statistics over time

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime
from collections import deque, defaultdict

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class ObjectTracker:
    """
    Simple object tracking using detection + filtering.
    """
    
    def __init__(self):
        """Initialize object tracker."""
        # Load MobileNet-SSD (faster for tracking)
        models_dir = Path(__file__).parent / "models" / "object_detection"
        
        prototxt = models_dir / "MobileNetSSD_deploy.prototxt"
        model = models_dir / "MobileNetSSD_deploy.caffemodel"
        
        if not prototxt.exists() or not model.exists():
            raise FileNotFoundError(
                "MobileNet-SSD files not found!\n"
                "Run: python utils/model_downloader.py"
            )
        
        print("Loading MobileNet-SSD for tracking...")
        self.net = cv2.dnn.readNetFromCaffe(str(prototxt), str(model))
        
        self.classes = [
            "background", "aeroplane", "bicycle", "bird", "boat",
            "bottle", "bus", "car", "cat", "chair", "cow",
            "diningtable", "dog", "horse", "motorbike", "person",
            "pottedplant", "sheep", "sofa", "train", "tvmonitor"
        ]
        
        print("✓ Tracker initialized")
        
        # Tracking settings
        self.tracked_class = "all"  # or specific class name
        self.confidence_threshold = 0.5
        
        # Quick select classes
        self.quick_select = {
            '1': "person",
            '2': "cup",
            '3': "bottle",
            '4': "laptop",
            '5': "chair",
            '6': "book",
            '7': "phone",
            '8': "car",
            '9': "dog"
        }
        
        # Statistics tracking
        self.object_counts = deque(maxlen=300)  # Last 300 frames (10 sec at 30fps)
        self.frame_count = 0
        self.max_objects_seen = 0
        self.total_detections = 0
        self.class_history = defaultdict(int)
        
        # Visualization
        self.show_graph = True
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        # Colors
        np.random.seed(42)
        self.colors = np.random.uniform(0, 255, size=(len(self.classes), 3))
    
    def detect_objects(self, frame):
        """Detect and filter objects."""
        h, w = frame.shape[:2]
        
        blob = cv2.dnn.blobFromImage(
            frame, 0.007843, (300, 300), (127.5, 127.5, 127.5)
        )
        
        self.net.setInput(blob)
        detections = self.net.forward()
        
        results = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.confidence_threshold:
                class_id = int(detections[0, 0, i, 1])
                if class_id >= len(self.classes):
                    continue
                
                class_name = self.classes[class_id]
                if class_name == "background":
                    continue
                
                # Filter by tracked class
                if self.tracked_class != "all" and class_name != self.tracked_class:
                    continue
                
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                box_w, box_h = x2 - x, y2 - y
                
                x, y = max(0, x), max(0, y)
                box_w = min(box_w, w - x)
                box_h = min(box_h, h - y)
                
                results.append((class_name, float(confidence), x, y, box_w, box_h))
        
        return results
    
    def update_statistics(self, detections):
        """Update tracking statistics."""
        self.frame_count += 1
        
        # Count objects in this frame
        count = len(detections)
        self.object_counts.append(count)
        self.max_objects_seen = max(self.max_objects_seen, count)
        self.total_detections += count
        
        # Track class history
        for class_name, _, _, _, _, _ in detections:
            self.class_history[class_name] += 1
    
    def draw_detections(self, frame, detections):
        """Draw detections with tracking info."""
        result = frame.copy()
        
        for i, (class_name, conf, x, y, w, h) in enumerate(detections, 1):
            class_id = self.classes.index(class_name)
            color = tuple(map(int, self.colors[class_id]))
            
            # Draw box
            cv2.rectangle(result, (x, y), (x+w, y+h), color, 2)
            
            # Label with ID
            label = f"#{i} {class_name}: {conf:.2f}"
            cv2.putText(result, label, (x, y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Draw center point
            center_x = x + w // 2
            center_y = y + h // 2
            cv2.circle(result, (center_x, center_y), 4, color, -1)
        
        return result
    
    def draw_statistics(self, frame):
        """Draw tracking statistics panel."""
        info = {
            'Tracking': self.tracked_class.upper(),
            'Current': self.object_counts[-1] if len(self.object_counts) > 0 else 0,
            'Max Seen': self.max_objects_seen,
            'Total': self.total_detections,
            'Frames': self.frame_count,
            'FPS': f"{self.fps.get_fps():.1f}"
        }

        self.viz.draw_info_panel(frame, info, position=(10, 30))

        # Average over last second
        if len(self.object_counts) >= 30:
            avg = np.mean(list(self.object_counts)[-30:])
            cv2.putText(frame, f"Avg (1s): {avg:.1f}", (10, 220),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        return frame
    
    def draw_graph(self, frame):
        """Draw object count graph over time."""
        if not self.object_counts or not self.show_graph:
            return frame
        
        h, w = frame.shape[:2]
        graph_h = 150
        graph_w = 400
        graph_x = w - graph_w - 20
        graph_y = 20
        
        # Create graph background
        overlay = frame.copy()
        cv2.rectangle(overlay, (graph_x, graph_y), 
                     (graph_x + graph_w, graph_y + graph_h),
                     (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Border
        cv2.rectangle(frame, (graph_x, graph_y), 
                     (graph_x + graph_w, graph_y + graph_h),
                     (255, 255, 255), 2)
        
        # Title
        cv2.putText(frame, "Object Count Over Time", (graph_x + 10, graph_y + 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Draw graph
        if len(self.object_counts) > 1:
            counts = list(self.object_counts)
            max_count = max(counts) if max(counts) > 0 else 1
            
            points = []
            for i, count in enumerate(counts):
                x = graph_x + int((i / len(counts)) * graph_w)
                y = graph_y + graph_h - int((count / max_count) * (graph_h - 40))
                points.append((x, y))
            
            # Draw line
            for i in range(len(points) - 1):
                cv2.line(frame, points[i], points[i+1], (0, 255, 255), 2)
            
            # Current value
            if points:
                cv2.circle(frame, points[-1], 4, (0, 255, 0), -1)
        
        # Y-axis labels
        cv2.putText(frame, f"{self.max_objects_seen}", (graph_x + 5, graph_y + 35),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(frame, "0", (graph_x + 5, graph_y + graph_h - 5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        return frame
    
    def draw_class_history(self, frame):
        """Draw class detection history."""
        if not self.class_history:
            return frame
        
        h = frame.shape[0]
        y_pos = h - 150
        
        cv2.putText(frame, "Detection History:", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        y_pos += 25
        
        # Show top 3 classes
        sorted_classes = sorted(self.class_history.items(), 
                               key=lambda x: x[1], reverse=True)[:3]
        
        for class_name, count in sorted_classes:
            text = f"  {class_name}: {count}"
            cv2.putText(frame, text, (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
            y_pos += 20
        
        return frame
    
    def draw_ui(self, frame):
        """Draw UI controls."""
        h = frame.shape[0]
        
        controls = [
            f"Tracking: {self.tracked_class.upper()} | 1-9: Quick select | A: All",
            "G: Graph | R: Reset | S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def reset_statistics(self):
        """Reset tracking statistics."""
        self.object_counts.clear()
        self.frame_count = 0
        self.max_objects_seen = 0
        self.total_detections = 0
        self.class_history.clear()
        print("Statistics reset")
    
    def run(self):
        """Run object tracking."""
        print("\n" + "="*60)
        print("SIMPLE OBJECT TRACKING")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting tracking...")
        print("\nQUICK SELECT CLASSES:")
        for key, class_name in sorted(self.quick_select.items()):
            print(f"  {key} - {class_name}")
        print("  A - Track all objects")
        print("\nPress 'g' to toggle statistics graph")
        
        window_name = "Object Tracking"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                frame = cv2.flip(frame, 1)
                
                # Detect and track
                detections = self.detect_objects(frame)
                self.update_statistics(detections)
                
                # Draw results
                result = self.draw_detections(frame, detections)
                result = self.draw_statistics(result)
                result = self.draw_graph(result)
                result = self.draw_class_history(result)
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key in [ord(k) for k in self.quick_select.keys()]:
                    self.tracked_class = self.quick_select[chr(key)]
                    print(f"Tracking: {self.tracked_class}")
                    
                elif key == ord('a'):
                    self.tracked_class = "all"
                    print("Tracking: ALL objects")
                    
                elif key == ord('g'):
                    self.show_graph = not self.show_graph
                    print(f"Graph: {'ON' if self.show_graph else 'OFF'}")
                    
                elif key == ord('r'):
                    self.reset_statistics()
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"tracking_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            # Print final statistics
            print("\n" + "="*60)
            print("TRACKING SESSION SUMMARY")
            print("="*60)
            print(f"Frames processed: {self.frame_count}")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")
            print(f"Total detections: {self.total_detections}")
            print(f"Max objects in frame: {self.max_objects_seen}")
            if self.class_history:
                print("\nMost detected classes:")
                for class_name, count in sorted(self.class_history.items(), 
                                               key=lambda x: x[1], reverse=True)[:5]:
                    print(f"  {class_name}: {count}")
            print("="*60)


def main():
    """Main function."""
    print("\n" + "="*60)
    print("SIMPLE OBJECT TRACKING")
    print("="*60)
    print("\nTrack specific objects and collect statistics over time.")
    print("\nHOW IT WORKS:")
    print("  • Detects objects in each frame")
    print("  • Filters by selected class")
    print("  • Counts objects over time")
    print("  • Shows statistics and graphs")
    print("\nUSE CASES:")
    print("  • Count people entering/leaving")
    print("  • Track specific objects")
    print("  • Monitor object presence")
    print("  • Collect temporal data")
    print("\nQUICK SELECT:")
    print("  1 - person    2 - cup       3 - bottle")
    print("  4 - laptop    5 - chair     6 - book")
    print("  7 - phone     8 - car       9 - dog")
    print("  A - All objects")
    print("\nCONTROLS:")
    print("  1-9 - Select class to track")
    print("  A - Track all objects")
    print("  G - Toggle statistics graph")
    print("  R - Reset statistics")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    try:
        tracker = ObjectTracker()
        tracker.run()
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ Detection-based tracking is simple but effective")
    print("✓ Class filtering enables specific object tracking")
    print("✓ Temporal data reveals patterns over time")
    print("✓ Statistics help understand object behavior")
    print("\n🎯 APPLICATIONS:")
    print("  • People counting")
    print("  • Object monitoring")
    print("  • Activity analysis")
    print("  • Interactive installations")
    print("\n✗ LIMITATIONS:")
    print("  • No object identity (can't tell if same object)")
    print("  • Works frame-by-frame (no temporal continuity)")
    print("  • For true tracking, need algorithms like SORT, DeepSORT")
    print("\n💡 IMPROVEMENTS:")
    print("  • Add centroid tracking for object identity")
    print("  • Use Kalman filters for motion prediction")
    print("  • Implement DeepSORT for robust tracking")
    print("\nThis completes the object detection examples!")
    print("Next: Try pose estimation (14-17)")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
