"""
Week 4 - Example 17: Real-time Pose Tracking
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Optimized real-time pose tracking from webcam with FPS monitoring
    and smooth skeleton rendering. Demonstrates performance optimization
    techniques for interactive applications.

Key Concepts:
    - Real-time pose detection optimization
    - FPS monitoring and display
    - Smooth skeleton visualization
    - Performance trade-offs

Controls:
    '1' - Toggle skeleton
    '2' - Toggle FPS
    '3' - Cycle through visualization modes
    's' - Save current frame
    'q' - Quit

Usage:
    python 17_realtime_pose_tracking.py
    python 17_realtime_pose_tracking.py --resolution 480
"""

import cv2
import numpy as np
import time
import argparse
import sys
from pathlib import Path
from collections import deque

# Add utils to path
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator

class RealtimePoseTracker:
    """Optimized real-time pose tracking"""
    
    # Keypoint indices
    BODY_PARTS = {
        0: "Nose", 1: "Neck",
        2: "RShoulder", 3: "RElbow", 4: "RWrist",
        5: "LShoulder", 6: "LElbow", 7: "LWrist",
        8: "RHip", 9: "RKnee", 10: "RAnkle",
        11: "LHip", 12: "LKnee", 13: "LAnkle",
        14: "REye", 15: "LEye", 16: "REar", 17: "LEar"
    }
    
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13),
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)
    ]
    
    # Color palette for skeleton
    COLORS = [
        (255, 0, 0), (255, 85, 0), (255, 170, 0),
        (255, 255, 0), (170, 255, 0), (85, 255, 0),
        (0, 255, 0), (0, 255, 85), (0, 255, 170),
        (0, 255, 255), (0, 170, 255), (0, 85, 255),
        (0, 0, 255), (85, 0, 255), (170, 0, 255),
        (255, 0, 255), (255, 0, 170), (255, 0, 85)
    ]
    
    def __init__(self, proto_file, weights_file, input_size=368):
        """
        Initialize pose tracker
        
        Args:
            proto_file: Path to prototxt
            weights_file: Path to caffemodel
            input_size: Network input size (smaller = faster, less accurate)
        """
        self.threshold = 0.1
        self.input_size = input_size
        
        # Load model
        try:
            self.net = cv2.dnn.readNetFromCaffe(proto_file, weights_file)
            print(f"✓ Loaded OpenPose model (input size: {input_size})")
        except Exception as e:
            print(f"✗ Error loading model: {e}")
            sys.exit(1)
        
        # Visualization settings
        self.show_skeleton = True
        self.show_fps = True
        self.viz_mode = 0  # 0=full, 1=skeleton only, 2=keypoints only
        
        # Smoothing for keypoints (reduces jitter)
        self.use_smoothing = True
        self.point_history = deque(maxlen=5)
        
        # FPS calculator
        self.fps_calc = FPSCalculator()
    
    def detect_keypoints(self, frame):
        """Detect keypoints with timing"""
        start_time = time.time()
        
        frame_height, frame_width = frame.shape[:2]
        
        # Prepare input
        inpBlob = cv2.dnn.blobFromImage(
            frame, 1.0 / 255,
            (self.input_size, self.input_size),
            (0, 0, 0), swapRB=False, crop=False
        )
        
        # Run inference
        self.net.setInput(inpBlob)
        output = self.net.forward()
        
        inference_time = time.time() - start_time
        
        H = output.shape[2]
        W = output.shape[3]
        
        # Extract keypoints
        points = []
        for i in range(18):
            probMap = output[0, i, :, :]
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            if prob > self.threshold:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        # Apply smoothing if enabled
        if self.use_smoothing:
            points = self.smooth_keypoints(points)
        
        return points, inference_time
    
    def smooth_keypoints(self, points):
        """Smooth keypoints using temporal averaging"""
        self.point_history.append(points)
        
        if len(self.point_history) < 2:
            return points
        
        # Average keypoints over history
        smoothed = []
        for i in range(18):
            valid_points = []
            for frame_points in self.point_history:
                if frame_points[i] is not None:
                    valid_points.append(frame_points[i])
            
            if valid_points:
                avg_x = int(np.mean([p[0] for p in valid_points]))
                avg_y = int(np.mean([p[1] for p in valid_points]))
                smoothed.append((avg_x, avg_y))
            else:
                smoothed.append(None)
        
        return smoothed
    
    def draw_full_visualization(self, frame, points):
        """Draw full skeleton with colors"""
        result = frame.copy()
        
        # Draw connections
        for i, pair in enumerate(self.POSE_PAIRS):
            partA, partB = pair
            
            if points[partA] is not None and points[partB] is not None:
                color = self.COLORS[i % len(self.COLORS)]
                cv2.line(result, points[partA], points[partB],
                        color, 3, lineType=cv2.LINE_AA)
        
        # Draw keypoints
        for i, point in enumerate(points):
            if point is not None:
                cv2.circle(result, point, 6, (255, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
                cv2.circle(result, point, 5, (0, 0, 0),
                          thickness=-1, lineType=cv2.FILLED)
        
        return result
    
    def draw_skeleton_only(self, frame, points):
        """Draw minimal skeleton"""
        result = frame.copy()
        
        # Draw connections only
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            
            if points[partA] is not None and points[partB] is not None:
                cv2.line(result, points[partA], points[partB],
                        (0, 255, 0), 2, lineType=cv2.LINE_AA)
        
        return result
    
    def draw_keypoints_only(self, frame, points):
        """Draw keypoints only"""
        result = frame.copy()
        
        for point in points:
            if point is not None:
                cv2.circle(result, point, 5, (0, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
        
        return result
    
    def draw_stick_figure(self, frame, points):
        """Draw simple stick figure"""
        result = frame.copy()
        
        # Simplified connections (just main body structure)
        simple_pairs = [
            (0, 1),   # Head-Neck
            (1, 2), (1, 5),  # Neck-Shoulders
            (2, 3), (3, 4),  # Right arm
            (5, 6), (6, 7),  # Left arm
            (1, 8), (1, 11), # Neck-Hips
            (8, 9), (9, 10), # Right leg
            (11, 12), (12, 13) # Left leg
        ]
        
        for pair in simple_pairs:
            partA, partB = pair
            if points[partA] is not None and points[partB] is not None:
                cv2.line(result, points[partA], points[partB],
                        (255, 255, 255), 4, lineType=cv2.LINE_AA)
                cv2.line(result, points[partA], points[partB],
                        (0, 255, 0), 2, lineType=cv2.LINE_AA)
        
        return result
    
    def render_frame(self, frame, points, inference_time):
        """Render final frame with all overlays"""
        # Choose visualization mode
        if not self.show_skeleton:
            result = frame.copy()
        elif self.viz_mode == 0:
            result = self.draw_full_visualization(frame, points)
        elif self.viz_mode == 1:
            result = self.draw_skeleton_only(frame, points)
        elif self.viz_mode == 2:
            result = self.draw_keypoints_only(frame, points)
        else:
            result = self.draw_stick_figure(frame, points)
        
        # Add FPS overlay
        if self.show_fps:
            self.fps_calc.update()
            result = self.fps_calc.draw_fps(result)
            
            # Add inference time
            cv2.putText(result, f"Inference: {inference_time*1000:.1f}ms",
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                       (0, 255, 0), 2)
        
        # Add keypoint count
        detected = sum(1 for p in points if p is not None)
        cv2.putText(result, f"Keypoints: {detected}/18",
                   (10, result.shape[0] - 70), cv2.FONT_HERSHEY_SIMPLEX,
                   0.6, (255, 255, 255), 2)
        
        # Add visualization mode
        mode_names = ["Full Color", "Skeleton", "Keypoints", "Stick Figure"]
        if self.show_skeleton:
            cv2.putText(result, f"Mode: {mode_names[self.viz_mode]}",
                       (10, result.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX,
                       0.6, (255, 255, 255), 2)
        
        # Add controls
        cv2.putText(result, "1:Skeleton 2:FPS 3:Mode s:Save q:Quit",
                   (10, result.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX,
                   0.5, (255, 255, 255), 1)
        
        return result


def main():
    parser = argparse.ArgumentParser(
        description='Real-time pose tracking with optimization'
    )
    parser.add_argument(
        '--resolution', type=int, default=368,
        help='Network input resolution (lower = faster, default: 368)'
    )
    parser.add_argument(
        '--no-smooth', action='store_true',
        help='Disable keypoint smoothing'
    )
    
    args = parser.parse_args()
    
    print("=== Real-time Pose Tracking ===\n")
    
    # Model paths
    models_dir = Path(__file__).parent / 'models' / 'pose_estimation'
    proto_file = models_dir / 'pose_deploy_linevec.prototxt'
    weights_file = models_dir / 'pose_iter_440000.caffemodel'
    
    # Check models
    if not proto_file.exists() or not weights_file.exists():
        print("✗ OpenPose models not found!")
        print(f"\nRequired:\n  {proto_file}\n  {weights_file}")
        return
    
    # Initialize tracker
    tracker = RealtimePoseTracker(
        str(proto_file),
        str(weights_file),
        input_size=args.resolution
    )
    
    if args.no_smooth:
        tracker.use_smoothing = False
        print("Smoothing: DISABLED")
    
    print("\nControls:")
    print("  '1' - Toggle skeleton on/off")
    print("  '2' - Toggle FPS display")
    print("  '3' - Cycle visualization modes")
    print("  's' - Save current frame")
    print("  'q' - Quit")
    print("\nStarting webcam...\n")
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ Webcam ready!\n")
    
    frame_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        frame_count += 1
        
        # Detect pose
        points, inference_time = tracker.detect_keypoints(frame)
        
        # Render result
        result = tracker.render_frame(frame, points, inference_time)
        
        cv2.imshow('Real-time Pose Tracking', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('1'):
            tracker.show_skeleton = not tracker.show_skeleton
            print(f"Skeleton: {'ON' if tracker.show_skeleton else 'OFF'}")
        elif key == ord('2'):
            tracker.show_fps = not tracker.show_fps
            print(f"FPS display: {'ON' if tracker.show_fps else 'OFF'}")
        elif key == ord('3'):
            tracker.viz_mode = (tracker.viz_mode + 1) % 4
            mode_names = ["Full Color", "Skeleton", "Keypoints", "Stick Figure"]
            print(f"Visualization: {mode_names[tracker.viz_mode]}")
        elif key == ord('s'):
            filename = f'pose_tracking_{frame_count}.jpg'
            cv2.imwrite(filename, result)
            print(f"✓ Saved: {filename}")
    
    cap.release()
    cv2.destroyAllWindows()
    
    # Print performance summary
    print("\n=== Performance Summary ===")
    print(f"Average FPS: {tracker.fps_calc.get_fps():.1f}")
    print(f"Total frames: {frame_count}")


if __name__ == '__main__':
    main()
