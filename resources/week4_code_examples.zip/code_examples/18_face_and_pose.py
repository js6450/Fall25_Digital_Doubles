"""
Week 4 - Example 18: Combined Face and Pose Detection
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Combine face detection with pose estimation for multi-modal analysis.
    Demonstrates coordinating multiple detection systems and creating
    layered interactive effects.

Key Concepts:
    - Running multiple detectors simultaneously
    - Coordinating detection results
    - Privacy-aware applications (blur faces, show pose)
    - Multi-modal interaction

Effects:
    - Face blur + Pose skeleton (privacy mode)
    - Face detection + Pose tracking
    - Coordinated visualizations

Controls:
    '1' - Toggle face detection
    '2' - Toggle pose detection
    '3' - Toggle face blur (privacy mode)
    'q' - Quit

Usage:
    python 18_face_and_pose.py
"""

import cv2
import numpy as np
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator

class FaceAndPoseDetector:
    """Combined face and pose detection system"""
    
    # Pose keypoint indices
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13),
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)
    ]
    
    def __init__(self, face_proto, face_model, pose_proto, pose_model):
        """Initialize both detectors"""
        # Load face detector
        try:
            self.face_net = cv2.dnn.readNetFromCaffe(face_proto, face_model)
            print("✓ Loaded face detection model")
        except Exception as e:
            print(f"✗ Error loading face model: {e}")
            sys.exit(1)
        
        # Load pose detector
        try:
            self.pose_net = cv2.dnn.readNetFromCaffe(pose_proto, pose_model)
            print("✓ Loaded pose estimation model")
        except Exception as e:
            print(f"✗ Error loading pose model: {e}")
            sys.exit(1)
        
        # Settings
        self.show_faces = True
        self.show_pose = True
        self.blur_faces = False
        self.face_confidence_threshold = 0.5
        self.pose_confidence_threshold = 0.1
        
        # Pose model settings
        self.pose_input_width = 368
        self.pose_input_height = 368
        
        # FPS tracker
        self.fps_calc = FPSCalculator()
    
    def detect_faces(self, frame):
        """Detect faces using DNN"""
        h, w = frame.shape[:2]
        
        # Prepare input
        blob = cv2.dnn.blobFromImage(
            frame, 1.0, (300, 300),
            (104.0, 177.0, 123.0), swapRB=False
        )
        
        # Run detection
        self.face_net.setInput(blob)
        detections = self.face_net.forward()
        
        # Process detections
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.face_confidence_threshold:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x1, y1, x2, y2) = box.astype("int")
                faces.append((x1, y1, x2, y2, confidence))
        
        return faces
    
    def detect_pose(self, frame):
        """Detect pose keypoints"""
        frame_height, frame_width = frame.shape[:2]
        
        # Prepare input
        inpBlob = cv2.dnn.blobFromImage(
            frame, 1.0 / 255,
            (self.pose_input_width, self.pose_input_height),
            (0, 0, 0), swapRB=False, crop=False
        )
        
        # Run detection
        self.pose_net.setInput(inpBlob)
        output = self.pose_net.forward()
        
        H = output.shape[2]
        W = output.shape[3]
        
        # Extract keypoints
        points = []
        for i in range(18):
            probMap = output[0, i, :, :]
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            if prob > self.pose_confidence_threshold:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        return points
    
    def blur_face_regions(self, frame, faces):
        """Apply Gaussian blur to detected face regions"""
        result = frame.copy()
        
        for (x1, y1, x2, y2, conf) in faces:
            # Extract face region
            face_roi = result[y1:y2, x1:x2]
            
            if face_roi.size > 0:
                # Apply strong blur
                blurred = cv2.GaussianBlur(face_roi, (99, 99), 30)
                result[y1:y2, x1:x2] = blurred
        
        return result
    
    def draw_faces(self, frame, faces):
        """Draw face detection boxes"""
        for (x1, y1, x2, y2, conf) in faces:
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"Face: {conf*100:.1f}%"
            cv2.putText(frame, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        return frame
    
    def draw_pose(self, frame, points):
        """Draw pose skeleton"""
        # Draw connections
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            if points[partA] is not None and points[partB] is not None:
                cv2.line(frame, points[partA], points[partB],
                        (255, 0, 255), 3, lineType=cv2.LINE_AA)
        
        # Draw keypoints
        for point in points:
            if point is not None:
                cv2.circle(frame, point, 5, (0, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
        
        return frame
    
    def process_frame(self, frame):
        """Process frame with both detectors"""
        result = frame.copy()
        
        # Detect faces
        faces = []
        if self.show_faces or self.blur_faces:
            faces = self.detect_faces(frame)
        
        # Detect pose
        points = []
        if self.show_pose:
            points = self.detect_pose(frame)
        
        # Apply face blur if enabled (do this first)
        if self.blur_faces and faces:
            result = self.blur_face_regions(result, faces)
        
        # Draw detections
        if self.show_pose and points:
            result = self.draw_pose(result, points)
        
        if self.show_faces and not self.blur_faces and faces:
            result = self.draw_faces(result, faces)
        
        # Add status info
        self.fps_calc.update()
        result = self.fps_calc.draw_fps(result)
        
        # Add counts
        face_count = len(faces)
        pose_keypoints = sum(1 for p in points if p is not None) if points else 0
        
        y_offset = 60
        cv2.putText(result, f"Faces: {face_count}", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        y_offset += 30
        cv2.putText(result, f"Pose points: {pose_keypoints}/18", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)
        
        # Mode indicator
        if self.blur_faces:
            cv2.rectangle(result, (10, 130), (250, 170), (0, 0, 0), -1)
            cv2.putText(result, "PRIVACY MODE", (20, 160),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        
        # Controls
        controls = [
            "1: Toggle Faces",
            "2: Toggle Pose",
            "3: Privacy Mode",
            "q: Quit"
        ]
        y_offset = result.shape[0] - 90
        for control in controls:
            cv2.putText(result, control, (10, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            y_offset += 20
        
        return result


def main():
    print("=== Face + Pose Detection ===\n")
    
    # Model paths
    models_dir = Path(__file__).parent / 'models'
    
    face_proto = models_dir / 'face_detection' / 'deploy.prototxt'
    face_model = models_dir / 'face_detection' / 'res10_300x300_ssd_iter_140000.caffemodel'
    pose_proto = models_dir / 'pose_estimation' / 'pose_deploy_linevec.prototxt'
    pose_model = models_dir / 'pose_estimation' / 'pose_iter_440000.caffemodel'
    
    # Check models
    if not all([face_proto.exists(), face_model.exists(),
                pose_proto.exists(), pose_model.exists()]):
        print("✗ Required models not found!")
        print("\nNeed:")
        print(f"  {face_proto}")
        print(f"  {face_model}")
        print(f"  {pose_proto}")
        print(f"  {pose_model}")
        return
    
    # Initialize detector
    detector = FaceAndPoseDetector(
        str(face_proto), str(face_model),
        str(pose_proto), str(pose_model)
    )
    
    print("Controls:")
    print("  '1' - Toggle face detection")
    print("  '2' - Toggle pose detection")
    print("  '3' - Toggle privacy mode (blur faces)")
    print("  'q' - Quit")
    print("\nStarting webcam...\n")
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ Ready! Try enabling privacy mode (press '3')\n")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        
        # Process with both detectors
        result = detector.process_frame(frame)
        
        cv2.imshow('Face + Pose Detection', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('1'):
            detector.show_faces = not detector.show_faces
            print(f"Face detection: {'ON' if detector.show_faces else 'OFF'}")
        elif key == ord('2'):
            detector.show_pose = not detector.show_pose
            print(f"Pose detection: {'ON' if detector.show_pose else 'OFF'}")
        elif key == ord('3'):
            detector.blur_faces = not detector.blur_faces
            print(f"Privacy mode: {'ON' if detector.blur_faces else 'OFF'}")
    
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
