# Week 4: Computer Vision - Detection & Feature Recognition
## Code Examples

This folder contains code examples for Week 4, covering computer vision detection techniques including face detection, feature detection and matching, object detection, and pose estimation.

---

## 📋 Quick Start

### 1. Fix SSL Certificates (macOS only)

If you're on macOS with a fresh Python installation, run this first to avoid SSL errors:

```bash
# For Python 3.13
"/Applications/Python 3.13/Install Certificates.command"

# For Python 3.12
"/Applications/Python 3.12/Install Certificates.command"

# Or for your specific Python version
"/Applications/Python X.XX/Install Certificates.command"
```

This prevents "SSL: CERTIFICATE_VERIFY_FAILED" errors when downloading models.

### 2. Install Requirements

```bash
cd Week4/code_examples
pip install -r requirements.txt
```

**Required packages:**
- `opencv-python` - Computer vision library
- `opencv-contrib-python` - Extended OpenCV modules
- `numpy` - Numerical computing

### 3. Download Pre-trained Models

**IMPORTANT:** Run this from the `code_examples` directory (not from `utils`):

```bash
# Make sure you're in the code_examples directory
cd Week4/code_examples

# Download models
python3 utils/model_downloader.py
```

This will download all necessary pre-trained models for face detection and object detection.

**Verify models downloaded successfully:**
```bash
python3 utils/model_downloader.py --verify
```

**Optional:** To include YOLO models (large files):
```bash
python3 utils/model_downloader.py --with-yolo
```

### 4. Run Examples

```bash
# Face detection examples
python 01_face_detection_haar.py
python 03_realtime_face_detection.py

# Object detection examples
python 10_object_detection_mobilenet.py

# Pose estimation examples
python 14_pose_estimation_mediapipe.py
```

---

## 📁 Folder Structure

```
code_examples/
├── utils/                          # Reusable utility modules
│   ├── fps_calculator.py          # FPS calculation and display
│   ├── detection_visualizer.py    # Detection result visualization
│   ├── model_downloader.py        # Model downloading utility
│   └── README.md                  # Utilities documentation
│
├── models/                         # Pre-trained models (created by downloader)
│   ├── face_detection/
│   └── object_detection/
│
├── media/                          # Sample images and videos
│   ├── images/
│   └── videos/
│
├── 01-05_*.py                     # Face detection examples
├── 06-09_*.py                     # Feature detection examples
├── 10-13_*.py                     # Object detection examples
├── 14-17_*.py                     # Pose estimation examples
├── 18-20_*.py                     # Combined detection systems
│
├── requirements.txt               # Python package requirements
└── README.md                      # This file
```

---

## 🎯 Code Examples Overview

### Face Detection (5 examples)

**01_face_detection_haar.py**
- Basic Haar Cascade face detection
- Parameter tuning (scaleFactor, minNeighbors)
- Works on static images

**02_face_detection_dnn.py**
- Deep learning-based face detection
- ResNet SSD model
- Higher accuracy than Haar Cascades

**03_realtime_face_detection.py**
- Real-time webcam face detection
- FPS display and face counting
- Interactive demonstration

**04_face_blur_privacy.py**
- Automatic face blurring for privacy
- Multiple face detection and processing
- Privacy-preserving video processing

**05_face_comparison.py**
- Side-by-side comparison of Haar vs DNN
- Performance benchmarking
- Visual comparison of detection quality

---

### Feature Detection & Matching (4 examples)

**06_corner_detection.py**
- Harris corner detection
- Shi-Tomasi corner detection
- Comparing both methods

**07_sift_features.py**
- SIFT (Scale-Invariant Feature Transform)
- Keypoint detection and description
- Understanding feature descriptors

**08_orb_features.py**
- ORB (Oriented FAST and Rotated BRIEF)
- Faster alternative to SIFT
- Real-time feature detection

**09_feature_matching.py**
- Matching features between images
- BFMatcher and FLANN
- Object recognition by features

---

### Object Detection (4 examples)

**10_object_detection_mobilenet.py**
- MobileNet-SSD object detection
- Multi-class detection (80+ COCO classes)
- Static image processing

**11_object_detection_yolo.py**
- YOLO (You Only Look Once) detection
- Fast real-time object detection
- Non-Maximum Suppression (NMS)

**12_realtime_object_detection.py**
- Live webcam object detection
- Performance optimization
- Object counting and filtering

**13_object_tracking_simple.py**
- Track specific object types
- Detection-based tracking
- Object counting over time

---

### Pose Estimation (4 examples)

**14_pose_estimation_openpose.py**
- OpenPose body keypoint detection using OpenCV DNN
- 18-point COCO body model
- Skeleton visualization

**15_pose_keypoints_access.py**
- Accessing specific body keypoints
- Calculating joint distances and angles
- Understanding OpenPose output format

**16_pose_interactive_effects.py**
- Pose-triggered visual effects
- Body-controlled interactions
- Real-time pose-based effects

**17_realtime_pose_tracking.py**
- Real-time pose detection from webcam
- Performance optimization techniques
- Smooth skeleton rendering

---

### Combined Systems (3 examples)

**18_face_and_pose.py**
- Combine face detection with pose estimation
- Multi-modal detection system
- Example: Face blur + pose skeleton

**19_object_and_face.py**
- Face detection + object detection
- Context-aware detection
- Example: "Person holding phone" detection

**20_complete_detection_system.py**
- Full interactive system
- All detection types integrated
- Mode switching and performance optimization

---

## 🎮 Controls

Most real-time examples use these keyboard controls:

- **'q'** - Quit the program
- **'s'** - Save current frame
- **Space** - Pause/play
- **'r'** - Reset/restart
- **Numbers (1-9)** - Switch between modes (in combined examples)

Specific controls are documented in each example's docstring.

---

## 🔧 Utilities

The `utils/` folder contains reusable modules:

### FPSCalculator
Calculate and display frames per second:
```python
from utils.fps_calculator import FPSCalculator

fps = FPSCalculator()
fps.update()
fps.draw_fps(frame)
```

### DetectionVisualizer
Draw detection results with consistent styling:
```python
from utils.detection_visualizer import DetectionVisualizer

viz = DetectionVisualizer()
viz.draw_face(frame, x, y, w, h, confidence=0.95)
viz.draw_object(frame, x, y, w, h, "person", confidence=0.87)
```

### ModelDownloader
Download and manage pre-trained models:
```bash
python model_downloader.py
python model_downloader.py --face-only
python model_downloader.py --with-yolo
```

See `utils/README.md` for detailed utility documentation.

---

## 📸 Media Assets

Sample images and videos are located in the `media/` folder:

```
media/
├── images/
│   ├── faces/          # Face detection test images
│   ├── features/       # Feature detection test images
│   ├── objects/        # Object detection scenes
│   └── poses/          # Pose estimation test images
└── videos/
    ├── people_walking.mp4
    ├── traffic.mp4
    ├── dance.mp4
    └── workout.mp4
```

---

## ⚙️ Model Files

Pre-trained models are stored in the `models/` directory:

### Face Detection Models
- `deploy.prototxt` - ResNet-SSD architecture
- `res10_300x300_ssd_iter_140000.caffemodel` - Pre-trained weights

### Object Detection Models
- `MobileNetSSD_deploy.prototxt` - MobileNet architecture
- `MobileNetSSD_deploy.caffemodel` - Pre-trained weights (~23MB)
- `mobilenet_classes.txt` - Class labels
- `coco.names` - COCO dataset class names

### YOLO Models (Optional)
- `yolov3.cfg` / `yolov4-tiny.cfg` - Model architecture
- `yolov3.weights` / `yolov4-tiny.weights` - Pre-trained weights (large files)

Download all models: `python utils/model_downloader.py`

---

## 🐛 Troubleshooting

### "SSL: CERTIFICATE_VERIFY_FAILED" (macOS)
**Cause:** Fresh Python installation on macOS needs SSL certificates installed.

**Solution:**
```bash
# Run the Install Certificates command for your Python version
"/Applications/Python 3.13/Install Certificates.command"
# Or for Python 3.12:
"/Applications/Python 3.12/Install Certificates.command"
```

After running this, re-run the model downloader:
```bash
cd utils
python model_downloader.py
```

### "No module named 'cv2'"
```bash
pip install opencv-python
```

### "Cannot open webcam"
- Check if another application is using the webcam
- Try changing camera index: `cv2.VideoCapture(1)` instead of `(0)`
- On Mac: Grant camera permissions in System Preferences

### "Model file not found"
**Cause:** Models not downloaded or downloaded to wrong location.

**Solution:**
```bash
# Make sure you're in the code_examples directory (not utils!)
cd Week4/code_examples

# Verify models
python3 utils/model_downloader.py --verify

# Re-download if needed
python3 utils/model_downloader.py
```

**Important:** Always run the model_downloader from the `code_examples` directory, not from inside `utils/`. The script uses relative paths and needs to save models to `code_examples/models/`.

If model downloads fail, manually download them:
```bash
cd models/object_detection

# Download prototxt (architecture)
curl -o MobileNetSSD_deploy.prototxt "https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/f5d072ccc7e3dcddaa830e9805da4bf1000b2836/MobileNetSSD_deploy.prototxt"

# Download caffemodel (weights) - 22MB file
curl -L -o MobileNetSSD_deploy.caffemodel "https://github.com/chuanqi305/MobileNet-SSD/raw/master/mobilenet_iter_73000.caffemodel"
```

### Slow performance / Low FPS
- Reduce webcam resolution in code
- Use Haar Cascades instead of DNN for face detection
- Use YOLOv4-tiny instead of YOLOv3
- Process every Nth frame instead of every frame

### "AttributeError: module 'cv2' has no attribute 'dnn'"
- Install opencv-contrib-python: `pip install opencv-contrib-python`

---

## 📚 Additional Resources

### Documentation
- [OpenCV Documentation](https://docs.opencv.org/)
- [MediaPipe Documentation](https://google.github.io/mediapipe/)
- [YOLO Official Site](https://pjreddie.com/darknet/yolo/)

### Tutorials
- [PyImageSearch](https://pyimagesearch.com/)
- [Learn OpenCV](https://learnopencv.com/)
- [OpenCV Tutorials](https://docs.opencv.org/master/d9/df8/tutorial_root.html)

### Research Papers
- Viola-Jones Face Detection (2001)
- YOLO: You Only Look Once (2016)
- MediaPipe: BlazePose (2020)

---

## 🔗 Course Links

- **Course Website:** [Digital Doubles](https://js6450.github.io/Fall25_Digital_Doubles/)
- **Google Drive:** [Course Materials](https://drive.google.com/drive/folders/1QBC_GxFM-6KoTL7bqZjC76_r6MVasSG8)
- **Instructor:** jiwon.shin@nyu.edu

---

## 📝 Notes

- All examples are designed to be self-contained and runnable
- Code includes detailed comments and docstrings
- Each example can serve as a starting point for Lab 4
- Examples progressively increase in complexity
- Test on diverse subjects to understand detection bias
- Consider ethical implications when using detection technologies

---

## 👤 Author

**Jiwon Shin**  
Digital Doubles - Fall 2025  
NYU Tandon School of Engineering  
Integrated Design & Media

---

## 📅 Version

Week 4 - November 2025

---

**Happy coding! 🚀**
