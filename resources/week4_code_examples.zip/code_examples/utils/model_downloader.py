"""
Model Downloader Utility
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Script to download all required pre-trained models for Week 4 examples:
- Face detection models (DNN)
- Object detection models (MobileNet-SSD, YOLO)
- Class label files

Models will be organized in a ../models/ directory structure.

Usage:
    python model_downloader.py
    
    # Or download specific models:
    python model_downloader.py --face-only
    python model_downloader.py --object-only

Author: Jiwon Shin
Date: November 2025
"""

import os
import sys
import urllib.request
import argparse
from pathlib import Path


class ModelDownloader:
    """
    Download and organize pre-trained models for computer vision tasks.
    """
    
    def __init__(self, base_dir="models"):
        """
        Initialize the model downloader.
        
        Args:
            base_dir: Base directory for storing models
        """
        self.base_dir = Path(base_dir)
        self.face_dir = self.base_dir / "face_detection"
        self.object_dir = self.base_dir / "object_detection"
        
        # Create directories
        self.face_dir.mkdir(parents=True, exist_ok=True)
        self.object_dir.mkdir(parents=True, exist_ok=True)
        
        # Model URLs
        self.models = {
            'face': {
                'deploy.prototxt': 'https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt',
                'res10_300x300_ssd_iter_140000.caffemodel': 'https://raw.githubusercontent.com/opencv/opencv_3rdparty/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel',
            },
            'object': {
                'MobileNetSSD_deploy.prototxt': 'https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/f5d072ccc7e3dcddaa830e9805da4bf1000b2836/MobileNetSSD_deploy.prototxt',
                'MobileNetSSD_deploy.caffemodel': 'https://github.com/chuanqi305/MobileNet-SSD/raw/master/mobilenet_iter_73000.caffemodel',
                'coco.names': 'https://raw.githubusercontent.com/pjreddie/darknet/master/data/coco.names',
            },
            'yolo': {
                'yolov3.cfg': 'https://raw.githubusercontent.com/pjreddie/darknet/master/cfg/yolov3.cfg',
                'yolov3.weights': 'https://pjreddie.com/media/files/yolov3.weights',
                'yolov4-tiny.cfg': 'https://raw.githubusercontent.com/AlexeyAB/darknet/master/cfg/yolov4-tiny.cfg',
                'yolov4-tiny.weights': 'https://github.com/AlexeyAB/darknet/releases/download/darknet_yolo_v4_pre/yolov4-tiny.weights',
            }
        }
        
        # Alternative download sources (some files are large and may need alternatives)
        self.alternative_sources = {
            'MobileNetSSD_deploy.caffemodel': [
                'https://github.com/chuanqi305/MobileNet-SSD/raw/master/mobilenet_iter_73000.caffemodel',
            ],
            'yolov3.weights': [
                'https://pjreddie.com/media/files/yolov3.weights',
            ]
        }
    
    def download_file(self, url, destination, show_progress=True):
        """
        Download a file from URL to destination.
        
        Args:
            url: URL to download from
            destination: Local file path to save to
            show_progress: Whether to show download progress
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            print(f"Downloading {destination.name}...")
            
            if show_progress:
                def reporthook(count, block_size, total_size):
                    percent = int(count * block_size * 100 / total_size)
                    sys.stdout.write(f"\r  Progress: {percent}%")
                    sys.stdout.flush()
                
                urllib.request.urlretrieve(url, destination, reporthook=reporthook)
                print()  # New line after progress
            else:
                urllib.request.urlretrieve(url, destination)
            
            print(f"  ✓ Downloaded: {destination.name}")
            return True
            
        except Exception as e:
            print(f"  ✗ Error downloading {destination.name}: {str(e)}")
            return False
    
    def check_file_exists(self, filepath):
        """
        Check if file already exists and is not empty.
        
        Args:
            filepath: Path to check
            
        Returns:
            bool: True if file exists and has content
        """
        return filepath.exists() and filepath.stat().st_size > 0
    
    def download_face_models(self):
        """
        Download face detection models.
        """
        print("\n" + "="*60)
        print("DOWNLOADING FACE DETECTION MODELS")
        print("="*60)
        
        for filename, url in self.models['face'].items():
            destination = self.face_dir / filename
            
            if self.check_file_exists(destination):
                print(f"✓ {filename} already exists, skipping...")
                continue
            
            self.download_file(url, destination)
        
        print("\nFace detection models ready!")
        print(f"Location: {self.face_dir.absolute()}")
    
    def download_object_models(self, include_yolo=False):
        """
        Download object detection models.
        
        Args:
            include_yolo: Whether to download YOLO models (large files)
        """
        print("\n" + "="*60)
        print("DOWNLOADING OBJECT DETECTION MODELS")
        print("="*60)
        
        # MobileNet-SSD
        for filename, url in self.models['object'].items():
            destination = self.object_dir / filename
            
            if self.check_file_exists(destination):
                print(f"✓ {filename} already exists, skipping...")
                continue
            
            # Special handling for large caffemodel
            if 'caffemodel' in filename:
                print(f"\n{filename} is a large file (~23MB)")
                print("This may take a few minutes...")
            
            success = self.download_file(url, destination)
            
            # Try alternative sources if primary fails
            if not success and filename in self.alternative_sources:
                print(f"Trying alternative source for {filename}...")
                for alt_url in self.alternative_sources[filename]:
                    if self.download_file(alt_url, destination):
                        break
        
        # YOLO (optional, very large files)
        if include_yolo:
            print("\n" + "="*60)
            print("DOWNLOADING YOLO MODELS (Large files - this may take a while)")
            print("="*60)
            
            for filename, url in self.models['yolo'].items():
                destination = self.object_dir / filename
                
                if self.check_file_exists(destination):
                    print(f"✓ {filename} already exists, skipping...")
                    continue
                
                # Warn about large files
                if '.weights' in filename:
                    if 'yolov3' in filename:
                        print(f"\n{filename} is ~240MB - this will take several minutes")
                    elif 'yolov4-tiny' in filename:
                        print(f"\n{filename} is ~23MB")
                
                self.download_file(url, destination)
        
        print("\nObject detection models ready!")
        print(f"Location: {self.object_dir.absolute()}")
    
    def create_class_labels_file(self):
        """
        Create a COCO class labels file for MobileNet-SSD.
        """
        coco_classes = [
            "background", "aeroplane", "bicycle", "bird", "boat",
            "bottle", "bus", "car", "cat", "chair",
            "cow", "diningtable", "dog", "horse", "motorbike",
            "person", "pottedplant", "sheep", "sofa", "train",
            "tvmonitor"
        ]
        
        labels_file = self.object_dir / "mobilenet_classes.txt"
        with open(labels_file, 'w') as f:
            for class_name in coco_classes:
                f.write(f"{class_name}\n")
        
        print(f"✓ Created class labels file: {labels_file.name}")
    
    def download_all(self, include_yolo=False):
        """
        Download all models.
        
        Args:
            include_yolo: Whether to include YOLO models
        """
        print("\n" + "="*60)
        print("MODEL DOWNLOADER - Week 4: Computer Vision Detection")
        print("="*60)
        
        self.download_face_models()
        self.download_object_models(include_yolo=include_yolo)
        self.create_class_labels_file()
        
        print("\n" + "="*60)
        print("DOWNLOAD COMPLETE!")
        print("="*60)
        print(f"\nModels saved to: {self.base_dir.absolute()}")
        self.print_model_summary()
    
    def print_model_summary(self):
        """
        Print summary of downloaded models.
        """
        print("\n📁 Downloaded Models:")
        
        print("\n  Face Detection:")
        for item in self.face_dir.iterdir():
            if item.is_file():
                size = item.stat().st_size / (1024 * 1024)  # MB
                print(f"    - {item.name} ({size:.1f} MB)")
        
        print("\n  Object Detection:")
        for item in self.object_dir.iterdir():
            if item.is_file():
                size = item.stat().st_size / (1024 * 1024)  # MB
                print(f"    - {item.name} ({size:.1f} MB)")
    
    def verify_models(self):
        """
        Verify that all essential models are present.
        
        Returns:
            bool: True if all essential models exist
        """
        print("\n" + "="*60)
        print("VERIFYING MODELS")
        print("="*60)
        
        essential_files = {
            'Face Detection': [
                self.face_dir / 'deploy.prototxt',
                self.face_dir / 'res10_300x300_ssd_iter_140000.caffemodel',
            ],
            'Object Detection (MobileNet)': [
                self.object_dir / 'MobileNetSSD_deploy.prototxt',
                self.object_dir / 'MobileNetSSD_deploy.caffemodel',
            ]
        }
        
        all_present = True
        
        for category, files in essential_files.items():
            print(f"\n{category}:")
            for filepath in files:
                if self.check_file_exists(filepath):
                    print(f"  ✓ {filepath.name}")
                else:
                    print(f"  ✗ {filepath.name} - MISSING!")
                    all_present = False
        
        if all_present:
            print("\n✓ All essential models are present!")
        else:
            print("\n✗ Some models are missing. Please run the downloader again.")
        
        return all_present


def main():
    """
    Main function with command-line interface.
    """
    parser = argparse.ArgumentParser(
        description='Download pre-trained models for Week 4 CV detection'
    )
    parser.add_argument(
        '--face-only',
        action='store_true',
        help='Download only face detection models'
    )
    parser.add_argument(
        '--object-only',
        action='store_true',
        help='Download only object detection models'
    )
    parser.add_argument(
        '--with-yolo',
        action='store_true',
        help='Include YOLO models (large downloads)'
    )
    parser.add_argument(
        '--verify',
        action='store_true',
        help='Only verify existing models, do not download'
    )
    parser.add_argument(
        '--models-dir',
        type=str,
        default='models',
        help='Directory to store models (default: models)'
    )
    
    args = parser.parse_args()
    
    # Initialize downloader
    downloader = ModelDownloader(base_dir=args.models_dir)
    
    # Verify only
    if args.verify:
        downloader.verify_models()
        return
    
    # Download specific models
    if args.face_only:
        downloader.download_face_models()
    elif args.object_only:
        downloader.download_object_models(include_yolo=args.with_yolo)
    else:
        # Download all
        downloader.download_all(include_yolo=args.with_yolo)
    
    # Verify after download
    downloader.verify_models()
    
    print("\n" + "="*60)
    print("SETUP INSTRUCTIONS")
    print("="*60)
    print("\n1. Models are ready to use in your code examples")
    print("2. MediaPipe Pose requires installation:")
    print("   pip install mediapipe")
    print("\n3. For YOLO models (optional), run:")
    print("   python model_downloader.py --with-yolo")
    print("\n4. To verify models anytime, run:")
    print("   python model_downloader.py --verify")
    print("\n" + "="*60)


if __name__ == "__main__":
    main()
