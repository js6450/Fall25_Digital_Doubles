"""
Utility Package for Week 4 Computer Vision Detection
Digital Doubles - Fall 2025

This package contains reusable utilities for computer vision detection tasks:
- FPS calculation and display
- Detection result visualization
- Model downloading and management

Usage:
    from utils.fps_calculator import FPSCalculator
    from utils.detection_visualizer import DetectionVisualizer
    from utils.model_downloader import ModelDownloader
"""

from .fps_calculator import FPSCalculator
from .detection_visualizer import DetectionVisualizer
from .model_downloader import ModelDownloader

__all__ = ['FPSCalculator', 'DetectionVisualizer', 'ModelDownloader']
__version__ = '1.0.0'
