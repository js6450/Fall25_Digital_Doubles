"""
FPS Calculator Utility
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

A reusable class for calculating and displaying frames per second (FPS)
in real-time computer vision applications.

Usage:
    from utils.fps_calculator import FPSCalculator
    
    fps = FPSCalculator()
    
    while True:
        # Your processing code here
        fps.update()
        
        # Get current FPS
        current_fps = fps.get_fps()
        
        # Draw FPS on frame
        fps.draw_fps(frame)

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import time
from collections import deque


class FPSCalculator:
    """
    Calculate and display FPS for real-time video processing.
    
    Uses a moving average over a window of frames to provide
    smooth and accurate FPS measurements.
    """
    
    def __init__(self, window_size=30):
        """
        Initialize the FPS calculator.
        
        Args:
            window_size (int): Number of frames to average over.
                              Larger = smoother but slower to respond.
                              Default is 30 frames.
        """
        self.window_size = window_size
        self.frame_times = deque(maxlen=window_size)
        self.start_time = time.time()
        self.frame_count = 0
        
    def update(self):
        """
        Update the FPS calculation with a new frame.
        Call this once per frame in your main loop.
        """
        current_time = time.time()
        self.frame_times.append(current_time)
        self.frame_count += 1
        
    def get_fps(self):
        """
        Get the current FPS value.
        
        Returns:
            float: Current frames per second, or 0.0 if not enough data yet.
        """
        if len(self.frame_times) < 2:
            return 0.0
        
        # Calculate FPS from time differences
        time_diff = self.frame_times[-1] - self.frame_times[0]
        if time_diff > 0:
            fps = (len(self.frame_times) - 1) / time_diff
            return fps
        return 0.0
    
    def get_average_fps(self):
        """
        Get the average FPS since the calculator was started.
        
        Returns:
            float: Average frames per second over entire runtime.
        """
        elapsed_time = time.time() - self.start_time
        if elapsed_time > 0:
            return self.frame_count / elapsed_time
        return 0.0
    
    def draw_fps(self, frame, position=(10, 30), color=(0, 255, 0), 
                 font_scale=1.0, thickness=2):
        """
        Draw FPS text on a frame.
        
        Args:
            frame: Image/frame to draw on (will be modified in place)
            position: (x, y) tuple for text position, default (10, 30)
            color: BGR color tuple, default green (0, 255, 0)
            font_scale: Size of the font, default 1.0
            thickness: Thickness of the text, default 2
            
        Returns:
            frame: The frame with FPS text drawn on it
        """
        fps = self.get_fps()
        text = f"FPS: {fps:.1f}"
        
        # Draw text with black outline for visibility
        cv2.putText(frame, text, position, cv2.FONT_HERSHEY_SIMPLEX,
                   font_scale, (0, 0, 0), thickness + 2)
        cv2.putText(frame, text, position, cv2.FONT_HERSHEY_SIMPLEX,
                   font_scale, color, thickness)
        
        return frame
    
    def draw_detailed_stats(self, frame, position=(10, 30), color=(0, 255, 0)):
        """
        Draw detailed performance statistics on frame.
        
        Shows current FPS, average FPS, and total frames processed.
        
        Args:
            frame: Image/frame to draw on (will be modified in place)
            position: (x, y) tuple for starting position, default (10, 30)
            color: BGR color tuple, default green (0, 255, 0)
            
        Returns:
            frame: The frame with statistics drawn on it
        """
        current_fps = self.get_fps()
        avg_fps = self.get_average_fps()
        
        x, y = position
        line_height = 30
        
        # Current FPS
        text1 = f"Current FPS: {current_fps:.1f}"
        cv2.putText(frame, text1, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, (0, 0, 0), 4)
        cv2.putText(frame, text1, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, color, 2)
        
        # Average FPS
        text2 = f"Average FPS: {avg_fps:.1f}"
        cv2.putText(frame, text2, (x, y + line_height), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, (0, 0, 0), 4)
        cv2.putText(frame, text2, (x, y + line_height), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, color, 2)
        
        # Frame count
        text3 = f"Frames: {self.frame_count}"
        cv2.putText(frame, text3, (x, y + line_height * 2), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, (0, 0, 0), 4)
        cv2.putText(frame, text3, (x, y + line_height * 2), cv2.FONT_HERSHEY_SIMPLEX,
                   0.7, color, 2)
        
        return frame
    
    def reset(self):
        """
        Reset the FPS calculator to initial state.
        Useful when starting a new session or switching modes.
        """
        self.frame_times.clear()
        self.start_time = time.time()
        self.frame_count = 0
        
    def is_slow(self, threshold=15.0):
        """
        Check if FPS is below a threshold (indicating slow performance).
        
        Args:
            threshold (float): FPS threshold, default 15.0
            
        Returns:
            bool: True if current FPS is below threshold
        """
        return self.get_fps() < threshold
    
    def __str__(self):
        """String representation of current FPS."""
        return f"FPS: {self.get_fps():.1f}"
    
    def __repr__(self):
        """Detailed string representation."""
        return (f"FPSCalculator(current={self.get_fps():.1f}, "
                f"average={self.get_average_fps():.1f}, "
                f"frames={self.frame_count})")


# Example usage and testing
if __name__ == "__main__":
    """
    Test the FPS calculator with a simple webcam feed.
    Press 'q' to quit.
    """
    print("Testing FPS Calculator")
    print("Press 'q' to quit")
    
    # Initialize webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()
    
    # Create FPS calculator
    fps = FPSCalculator(window_size=30)
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Update FPS
        fps.update()
        
        # Draw FPS on frame (two different styles to demonstrate)
        if frame.shape[1] > 640:  # If frame is wide enough, show detailed stats
            fps.draw_detailed_stats(frame, position=(10, 30))
        else:
            fps.draw_fps(frame, position=(10, 30))
        
        # Performance warning
        if fps.is_slow(threshold=20.0):
            cv2.putText(frame, "LOW FPS WARNING", (10, frame.shape[0] - 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        # Display
        cv2.imshow('FPS Calculator Test', frame)
        
        # Quit on 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    # Cleanup
    cap.release()
    cv2.destroyAllWindows()
    
    # Print final statistics
    print(f"\nFinal Statistics:")
    print(f"  Total frames processed: {fps.frame_count}")
    print(f"  Average FPS: {fps.get_average_fps():.2f}")
    print(f"  Final FPS: {fps.get_fps():.2f}")
