# Week 4 Utilities

Reusable utility modules for Week 4 Computer Vision Detection examples.

## Contents

### 1. FPS Calculator (`fps_calculator.py`)

Calculate and display frames per second for real-time video processing.

**Features:**
- Moving average FPS calculation
- Visual FPS display on frames
- Detailed statistics (current FPS, average FPS, frame count)
- Performance warning detection

**Basic Usage:**
```python
from utils.fps_calculator import FPSCalculator

fps = FPSCalculator()

while True:
    ret, frame = cap.read()
    
    # Update FPS counter
    fps.update()
    
    # Draw FPS on frame
    fps.draw_fps(frame)
    
    # Or get FPS value
    current_fps = fps.get_fps()
```

**Advanced Usage:**
```python
# Detailed statistics
fps.draw_detailed_stats(frame)

# Check for slow performance
if fps.is_slow(threshold=15.0):
    print("Warning: Low FPS")

# Reset counter
fps.reset()
```

---

### 2. Detection Visualizer (`detection_visualizer.py`)

Visualization utilities for drawing detection results with consistent styling.

**Features:**
- Face detection visualization
- Object detection with labeled bounding boxes
- Keypoint and skeleton drawing
- Information panels and legends
- Confidence score visualization
- Color-coded by detection type

**Basic Usage:**
```python
from utils.detection_visualizer import DetectionVisualizer

viz = DetectionVisualizer()

# Draw face detection
viz.draw_face(frame, x, y, w, h, confidence=0.95)

# Draw object detection
viz.draw_object(frame, x, y, w, h, label="person", confidence=0.87)

# Draw keypoints
keypoints = [(100, 150), (120, 170), (140, 150)]
viz.draw_keypoints(frame, keypoints)

# Draw skeleton
skeleton = {
    'head': (200, 100),
    'neck': (200, 140),
    'shoulder_left': (180, 160),
    'shoulder_right': (220, 160)
}
connections = [('head', 'neck'), ('neck', 'shoulder_left'), ('neck', 'shoulder_right')]
viz.draw_skeleton(frame, skeleton, connections)
```

**Advanced Features:**
```python
# Information panel
info = {'Faces': 2, 'People': 3, 'FPS': 30.5}
viz.draw_info_panel(frame, info)

# Confidence bar
viz.draw_confidence_bar(frame, confidence=0.85, position=(10, 100))

# Color legend
legend = {'Face': (255, 100, 100), 'Person': (0, 255, 0)}
viz.create_legend(frame, legend)
```

**Color Scheme:**
- Face: Light blue `(255, 100, 100)`
- Person: Green `(0, 255, 0)`
- Object: Orange `(0, 165, 255)`
- Vehicle: Magenta `(255, 0, 255)`
- Animal: Cyan `(255, 255, 0)`
- Keypoint: Yellow `(0, 255, 255)`
- Skeleton: Blue `(255, 0, 0)`

---

### 3. Model Downloader (`model_downloader.py`)

Download and organize pre-trained models for computer vision tasks.

**Features:**
- Automatic model downloading
- Progress tracking
- Model verification
- Organized directory structure
- Support for face detection, object detection, and YOLO models

**Basic Usage:**

**IMPORTANT:** Always run from the `code_examples` directory (not from `utils`):

```bash
# Navigate to code_examples directory first
cd Week4/code_examples

# Download all essential models
python3 utils/model_downloader.py

# Download only face detection models
python3 utils/model_downloader.py --face-only

# Download only object detection models
python3 utils/model_downloader.py --object-only

# Include YOLO models (large files)
python3 utils/model_downloader.py --with-yolo

# Verify existing models
python3 utils/model_downloader.py --verify

# Specify custom models directory
python3 utils/model_downloader.py --models-dir /path/to/models
```

**Why run from code_examples?** The model_downloader uses relative paths and saves models to `models/` relative to your current directory. The Python scripts expect models in `code_examples/models/`, so you must run the downloader from `code_examples/`.

**Programmatic Usage:**
```python
from utils.model_downloader import ModelDownloader

downloader = ModelDownloader(base_dir='models')

# Download face detection models
downloader.download_face_models()

# Download object detection models
downloader.download_object_models(include_yolo=False)

# Verify all models
downloader.verify_models()
```

**Downloaded Models:**

*Face Detection:*
- `deploy.prototxt` - Model architecture
- `res10_300x300_ssd_iter_140000.caffemodel` - Pre-trained weights

*Object Detection (MobileNet-SSD):*
- `MobileNetSSD_deploy.prototxt` - Model architecture
- `MobileNetSSD_deploy.caffemodel` - Pre-trained weights (~23MB)
- `coco.names` - Class labels
- `mobilenet_classes.txt` - MobileNet class labels

*Object Detection (YOLO - Optional):*
- `yolov3.cfg` - YOLOv3 architecture
- `yolov3.weights` - YOLOv3 weights (~240MB)
- `yolov4-tiny.cfg` - YOLOv4-tiny architecture
- `yolov4-tiny.weights` - YOLOv4-tiny weights (~23MB)

**Directory Structure After Download:**
```
code_examples/
├── models/                        # <-- Models are saved here
│   ├── face_detection/
│   │   ├── deploy.prototxt
│   │   └── res10_300x300_ssd_iter_140000.caffemodel
│   └── object_detection/
│       ├── MobileNetSSD_deploy.prototxt
│       ├── MobileNetSSD_deploy.caffemodel
│       ├── mobilenet_classes.txt
│       ├── coco.names
│       ├── yolov3.cfg
│       ├── yolov3.weights
│       ├── yolov4-tiny.cfg
│       └── yolov4-tiny.weights
├── utils/
│   └── model_downloader.py        # <-- Run from parent directory
└── 01_face_detection_haar.py
```

---

## Installation Requirements

All utilities require:
```bash
pip install opencv-python numpy
```

For MediaPipe pose estimation (used in some examples):
```bash
pip install mediapipe
```

---

## Quick Start

1. **Download models:**
```bash
# Navigate to code_examples directory (not utils!)
cd Week4/code_examples
python3 utils/model_downloader.py
```

2. **Import utilities in your code:**
```python
import sys
sys.path.append('..')  # Add parent directory to path

from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer

# Or import the whole package
import utils
```

3. **Use in your detection scripts:**
```python
import cv2
from utils import FPSCalculator, DetectionVisualizer

# Initialize utilities
fps = FPSCalculator()
viz = DetectionVisualizer()

cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    # Your detection code here
    # ...
    
    # Visualize results
    viz.draw_face(frame, x, y, w, h)
    
    # Update and display FPS
    fps.update()
    fps.draw_fps(frame)
    
    cv2.imshow('Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
```

---

## Testing

Each utility has a built-in test when run directly:

```bash
# Test FPS calculator
python fps_calculator.py

# Test detection visualizer
python detection_visualizer.py

# Test model downloader
python model_downloader.py --verify
```

---

## Notes

- All utilities are designed to be reusable across multiple examples
- They follow consistent styling and naming conventions
- Error handling is built-in for robustness
- Type hints are included for better IDE support
- Docstrings follow Google style guide

---

## Author

Jiwon Shin  
Digital Doubles - Fall 2025  
NYU Tandon School of Engineering

---

## Version

1.0.0 - November 2025
