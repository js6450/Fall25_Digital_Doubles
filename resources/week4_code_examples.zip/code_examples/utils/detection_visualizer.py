"""
Detection Visualizer Utility
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Reusable visualization functions for drawing detection results including:
- Bounding boxes with labels and confidence scores
- Keypoints and features
- Pose skeletons
- Text overlays
- Color-coded detection types

Usage:
    from utils.detection_visualizer import DetectionVisualizer
    
    viz = DetectionVisualizer()
    
    # Draw face detection
    viz.draw_face(frame, x, y, w, h, confidence=0.95)
    
    # Draw object detection
    viz.draw_object(frame, x, y, w, h, label="person", confidence=0.87)
    
    # Draw keypoints
    viz.draw_keypoints(frame, keypoints)

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from typing import Tuple, List, Optional, Dict


class DetectionVisualizer:
    """
    Utility class for visualizing computer vision detection results.
    Provides consistent styling and easy-to-use drawing functions.
    """
    
    # Color schemes (BGR format)
    COLORS = {
        'face': (255, 100, 100),      # Light blue
        'person': (0, 255, 0),         # Green
        'object': (0, 165, 255),       # Orange
        'vehicle': (255, 0, 255),      # Magenta
        'animal': (255, 255, 0),       # Cyan
        'keypoint': (0, 255, 255),     # Yellow
        'skeleton': (255, 0, 0),       # Blue
        'text': (255, 255, 255),       # White
        'background': (0, 0, 0),       # Black
    }
    
    def __init__(self, font_scale=0.6, thickness=2, show_confidence=True):
        """
        Initialize the visualizer.
        
        Args:
            font_scale (float): Size of text labels
            thickness (int): Thickness of lines and boxes
            show_confidence (bool): Whether to show confidence scores by default
        """
        self.font_scale = font_scale
        self.thickness = thickness
        self.show_confidence = show_confidence
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        
    def draw_box(self, frame: np.ndarray, x: int, y: int, w: int, h: int,
                 color: Tuple[int, int, int] = (0, 255, 0),
                 thickness: Optional[int] = None) -> np.ndarray:
        """
        Draw a bounding box on the frame.
        
        Args:
            frame: Image to draw on
            x, y, w, h: Bounding box coordinates (x, y, width, height)
            color: BGR color tuple
            thickness: Line thickness (uses default if None)
            
        Returns:
            frame: Modified frame with box drawn
        """
        thickness = thickness or self.thickness
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, thickness)
        return frame
    
    def draw_label(self, frame: np.ndarray, text: str, x: int, y: int,
                   color: Tuple[int, int, int] = (255, 255, 255),
                   background: bool = True) -> np.ndarray:
        """
        Draw a text label on the frame.
        
        Args:
            frame: Image to draw on
            text: Text to display
            x, y: Position for text (top-left corner)
            color: Text color (BGR)
            background: Whether to draw background rectangle
            
        Returns:
            frame: Modified frame with label drawn
        """
        # Get text size for background
        (text_w, text_h), baseline = cv2.getTextSize(
            text, self.font, self.font_scale, self.thickness
        )
        
        if background:
            # Draw background rectangle
            cv2.rectangle(frame,
                         (x, y - text_h - baseline - 5),
                         (x + text_w + 5, y),
                         self.COLORS['background'],
                         -1)
        
        # Draw text
        cv2.putText(frame, text, (x + 2, y - 5),
                   self.font, self.font_scale, color, self.thickness)
        
        return frame
    
    def draw_face(self, frame: np.ndarray, x: int, y: int, w: int, h: int,
                  confidence: Optional[float] = None,
                  label: str = "Face") -> np.ndarray:
        """
        Draw face detection result.
        
        Args:
            frame: Image to draw on
            x, y, w, h: Face bounding box
            confidence: Detection confidence (0-1)
            label: Label text
            
        Returns:
            frame: Modified frame
        """
        # Draw box
        self.draw_box(frame, x, y, w, h, self.COLORS['face'])
        
        # Create label with confidence
        if confidence is not None and self.show_confidence:
            text = f"{label}: {confidence:.2f}"
        else:
            text = label
        
        # Draw label
        self.draw_label(frame, text, x, y, self.COLORS['face'])
        
        return frame
    
    def draw_object(self, frame: np.ndarray, x: int, y: int, w: int, h: int,
                    label: str, confidence: Optional[float] = None,
                    color: Optional[Tuple[int, int, int]] = None) -> np.ndarray:
        """
        Draw object detection result.
        
        Args:
            frame: Image to draw on
            x, y, w, h: Object bounding box
            label: Object class label
            confidence: Detection confidence (0-1)
            color: Custom color (uses default category color if None)
            
        Returns:
            frame: Modified frame
        """
        # Determine color based on object type
        if color is None:
            if 'person' in label.lower():
                color = self.COLORS['person']
            elif any(v in label.lower() for v in ['car', 'truck', 'bus', 'bike']):
                color = self.COLORS['vehicle']
            elif any(a in label.lower() for a in ['cat', 'dog', 'bird', 'horse']):
                color = self.COLORS['animal']
            else:
                color = self.COLORS['object']
        
        # Draw box
        self.draw_box(frame, x, y, w, h, color)
        
        # Create label
        if confidence is not None and self.show_confidence:
            text = f"{label}: {confidence:.2f}"
        else:
            text = label
        
        # Draw label
        self.draw_label(frame, text, x, y, color)
        
        return frame
    
    def draw_keypoint(self, frame: np.ndarray, x: int, y: int,
                      radius: int = 5,
                      color: Tuple[int, int, int] = None) -> np.ndarray:
        """
        Draw a single keypoint (feature point).
        
        Args:
            frame: Image to draw on
            x, y: Keypoint coordinates
            radius: Circle radius
            color: Color (uses default if None)
            
        Returns:
            frame: Modified frame
        """
        color = color or self.COLORS['keypoint']
        cv2.circle(frame, (int(x), int(y)), radius, color, -1)
        # Draw outline
        cv2.circle(frame, (int(x), int(y)), radius, (0, 0, 0), 1)
        return frame
    
    def draw_keypoints(self, frame: np.ndarray,
                       keypoints: List[Tuple[float, float]],
                       radius: int = 5,
                       color: Tuple[int, int, int] = None) -> np.ndarray:
        """
        Draw multiple keypoints.
        
        Args:
            frame: Image to draw on
            keypoints: List of (x, y) tuples
            radius: Circle radius
            color: Color for all keypoints
            
        Returns:
            frame: Modified frame
        """
        for kp in keypoints:
            x, y = kp[0], kp[1]
            self.draw_keypoint(frame, x, y, radius, color)
        return frame
    
    def draw_skeleton(self, frame: np.ndarray,
                      keypoints: Dict[str, Tuple[float, float]],
                      connections: List[Tuple[str, str]],
                      color: Tuple[int, int, int] = None) -> np.ndarray:
        """
        Draw a skeleton by connecting keypoints.
        
        Args:
            frame: Image to draw on
            keypoints: Dict mapping body part names to (x, y) coordinates
            connections: List of (start_name, end_name) tuples defining bones
            color: Line color
            
        Returns:
            frame: Modified frame
        """
        color = color or self.COLORS['skeleton']
        
        # Draw connections (bones)
        for start, end in connections:
            if start in keypoints and end in keypoints:
                start_point = (int(keypoints[start][0]), int(keypoints[start][1]))
                end_point = (int(keypoints[end][0]), int(keypoints[end][1]))
                cv2.line(frame, start_point, end_point, color, self.thickness)
        
        # Draw keypoints on top
        for point in keypoints.values():
            self.draw_keypoint(frame, point[0], point[1], radius=4)
        
        return frame
    
    def draw_simple_skeleton(self, frame: np.ndarray,
                            landmarks: List,
                            connections: List[Tuple[int, int]]) -> np.ndarray:
        """
        Draw skeleton from indexed landmarks (for MediaPipe format).
        
        Args:
            frame: Image to draw on
            landmarks: List of landmark objects with x, y attributes
            connections: List of (start_idx, end_idx) tuples
            
        Returns:
            frame: Modified frame
        """
        h, w = frame.shape[:2]
        
        # Draw connections
        for start_idx, end_idx in connections:
            start = landmarks[start_idx]
            end = landmarks[end_idx]
            
            start_point = (int(start.x * w), int(start.y * h))
            end_point = (int(end.x * w), int(end.y * h))
            
            cv2.line(frame, start_point, end_point,
                    self.COLORS['skeleton'], self.thickness)
        
        # Draw keypoints
        for landmark in landmarks:
            x = int(landmark.x * w)
            y = int(landmark.y * h)
            self.draw_keypoint(frame, x, y, radius=3)
        
        return frame
    
    def draw_info_panel(self, frame: np.ndarray,
                       info: Dict[str, any],
                       position: Tuple[int, int] = (10, 30)) -> np.ndarray:
        """
        Draw an information panel with multiple lines of text.
        
        Args:
            frame: Image to draw on
            info: Dictionary of label: value pairs to display
            position: Starting (x, y) position
            
        Returns:
            frame: Modified frame
        """
        x, y = position
        line_height = 30
        
        for i, (label, value) in enumerate(info.items()):
            text = f"{label}: {value}"
            y_pos = y + (i * line_height)
            
            # Background
            (text_w, text_h), _ = cv2.getTextSize(
                text, self.font, self.font_scale, self.thickness
            )
            cv2.rectangle(frame,
                         (x - 5, y_pos - text_h - 5),
                         (x + text_w + 5, y_pos + 5),
                         self.COLORS['background'],
                         -1)
            
            # Text
            cv2.putText(frame, text, (x, y_pos),
                       self.font, self.font_scale,
                       self.COLORS['text'], self.thickness)
        
        return frame
    
    def draw_detection_count(self, frame: np.ndarray,
                            count: int,
                            label: str = "Detections",
                            position: Tuple[int, int] = (10, 30)) -> np.ndarray:
        """
        Draw detection count overlay.
        
        Args:
            frame: Image to draw on
            count: Number of detections
            label: Label for the count
            position: Text position
            
        Returns:
            frame: Modified frame
        """
        text = f"{label}: {count}"
        self.draw_label(frame, text, position[0], position[1],
                       self.COLORS['text'], background=True)
        return frame
    
    def draw_confidence_bar(self, frame: np.ndarray,
                           confidence: float,
                           position: Tuple[int, int],
                           width: int = 100,
                           height: int = 15) -> np.ndarray:
        """
        Draw a confidence score as a horizontal bar.
        
        Args:
            frame: Image to draw on
            confidence: Confidence value (0-1)
            position: Top-left position of bar
            width: Bar width in pixels
            height: Bar height in pixels
            
        Returns:
            frame: Modified frame
        """
        x, y = position
        
        # Background bar
        cv2.rectangle(frame, (x, y), (x + width, y + height),
                     (100, 100, 100), -1)
        
        # Confidence bar (color changes with confidence)
        filled_width = int(width * confidence)
        if confidence > 0.7:
            color = (0, 255, 0)  # Green
        elif confidence > 0.5:
            color = (0, 255, 255)  # Yellow
        else:
            color = (0, 0, 255)  # Red
        
        cv2.rectangle(frame, (x, y), (x + filled_width, y + height),
                     color, -1)
        
        # Border
        cv2.rectangle(frame, (x, y), (x + width, y + height),
                     (255, 255, 255), 1)
        
        # Text
        text = f"{confidence:.2f}"
        cv2.putText(frame, text, (x + width + 5, y + height - 2),
                   self.font, 0.4, (255, 255, 255), 1)
        
        return frame
    
    def create_legend(self, frame: np.ndarray,
                     items: Dict[str, Tuple[int, int, int]],
                     position: Tuple[int, int] = None) -> np.ndarray:
        """
        Create a color legend for different detection types.
        
        Args:
            frame: Image to draw on
            items: Dict of label: color pairs
            position: Top-left position (default: top-right corner)
            
        Returns:
            frame: Modified frame
        """
        if position is None:
            position = (frame.shape[1] - 150, 30)
        
        x, y = position
        box_size = 20
        line_height = 30
        
        for i, (label, color) in enumerate(items.items()):
            y_pos = y + (i * line_height)
            
            # Color box
            cv2.rectangle(frame,
                         (x, y_pos - box_size + 5),
                         (x + box_size, y_pos + 5),
                         color, -1)
            cv2.rectangle(frame,
                         (x, y_pos - box_size + 5),
                         (x + box_size, y_pos + 5),
                         (255, 255, 255), 1)
            
            # Label
            self.draw_label(frame, label, x + box_size + 10, y_pos,
                           (255, 255, 255), background=False)
        
        return frame


# Example usage and testing
if __name__ == "__main__":
    """
    Test the detection visualizer with various drawing functions.
    """
    print("Testing Detection Visualizer")
    
    # Create a test image
    frame = np.zeros((600, 800, 3), dtype=np.uint8)
    frame[:] = (50, 50, 50)  # Dark gray background
    
    # Initialize visualizer
    viz = DetectionVisualizer()
    
    # Test face detection visualization
    viz.draw_face(frame, 50, 50, 100, 120, confidence=0.95)
    
    # Test object detection visualization
    viz.draw_object(frame, 200, 50, 80, 150, "person", confidence=0.87)
    viz.draw_object(frame, 320, 70, 120, 100, "car", confidence=0.78)
    
    # Test keypoints
    keypoints = [(500, 100), (520, 120), (480, 120), (500, 140)]
    viz.draw_keypoints(frame, keypoints)
    
    # Test skeleton
    skeleton_kp = {
        'head': (600, 100),
        'neck': (600, 140),
        'left_shoulder': (580, 160),
        'right_shoulder': (620, 160),
        'left_elbow': (570, 200),
        'right_elbow': (630, 200)
    }
    connections = [
        ('head', 'neck'),
        ('neck', 'left_shoulder'),
        ('neck', 'right_shoulder'),
        ('left_shoulder', 'left_elbow'),
        ('right_shoulder', 'right_elbow')
    ]
    viz.draw_skeleton(frame, skeleton_kp, connections)
    
    # Test info panel
    info = {
        'Faces': 1,
        'People': 1,
        'Vehicles': 1,
        'FPS': 30.5
    }
    viz.draw_info_panel(frame, info, position=(50, 350))
    
    # Test confidence bars
    viz.draw_confidence_bar(frame, 0.95, (50, 500))
    viz.draw_confidence_bar(frame, 0.65, (50, 525))
    viz.draw_confidence_bar(frame, 0.45, (50, 550))
    
    # Test legend
    legend_items = {
        'Face': viz.COLORS['face'],
        'Person': viz.COLORS['person'],
        'Vehicle': viz.COLORS['vehicle']
    }
    viz.create_legend(frame, legend_items)
    
    # Display
    cv2.imshow('Detection Visualizer Test', frame)
    print("Press any key to close...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
    print("Test complete!")
