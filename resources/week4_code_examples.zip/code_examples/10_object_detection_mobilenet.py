"""
10: Object Detection with MobileNet-SSD
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time multi-class object detection using MobileNet-SSD.
Point your webcam at objects in your environment and watch as the
system detects and labels them from 80+ COCO classes!

Concepts:
- Multi-class object detection
- MobileNet-SSD architecture
- COCO dataset classes
- Confidence thresholds
- Real-time detection

Usage:
    python 10_object_detection_mobilenet.py

Prerequisites:
    Run utils/model_downloader.py first to download models

Controls:
    - '+' / '-' - Adjust confidence threshold
    - 'f' - Toggle class filter mode
    - 'l' - Toggle label display
    - 'c' - Toggle class list display
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Point at yourself (person)
    - Show your laptop, phone, keyboard
    - Hold up a cup, bottle, book
    - Test with multiple objects
    - See what gets detected!

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class MobileNetObjectDetector:
    """
    Real-time object detection using MobileNet-SSD.
    """
    
    def __init__(self):
        """Initialize MobileNet-SSD detector."""
        # Load class labels
        models_dir = Path(__file__).parent / "models" / "object_detection"
        
        # MobileNet class labels (21 classes)
        self.classes = [
            "background", "aeroplane", "bicycle", "bird", "boat",
            "bottle", "bus", "car", "cat", "chair", "cow",
            "diningtable", "dog", "horse", "motorbike", "person",
            "pottedplant", "sheep", "sofa", "train", "tvmonitor"
        ]
        
        # Load model
        prototxt = models_dir / "MobileNetSSD_deploy.prototxt"
        model = models_dir / "MobileNetSSD_deploy.caffemodel"
        
        if not prototxt.exists() or not model.exists():
            raise FileNotFoundError(
                f"MobileNet-SSD model files not found!\n"
                f"Please run: python utils/model_downloader.py\n"
                f"Looking for:\n"
                f"  {prototxt}\n"
                f"  {model}"
            )
        
        print("Loading MobileNet-SSD...")
        self.net = cv2.dnn.readNetFromCaffe(str(prototxt), str(model))
        print("✓ MobileNet-SSD loaded")
        
        # Detection parameters
        self.confidence_threshold = 0.5
        self.filter_mode = False
        self.filter_classes = ["person", "laptop", "phone", "cup", "bottle"]
        self.show_labels = True
        self.show_class_list = False
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        # Colors for each class
        np.random.seed(42)
        self.colors = np.random.uniform(0, 255, size=(len(self.classes), 3))
        
        print(f"Classes available: {len(self.classes)}")
        print(f"Confidence threshold: {self.confidence_threshold}")
    
    def detect_objects(self, frame):
        """
        Detect objects in frame.
        
        Returns:
            detections: List of (class_name, confidence, x, y, w, h) tuples
        """
        h, w = frame.shape[:2]
        
        # Prepare blob
        blob = cv2.dnn.blobFromImage(
            frame,
            scalefactor=0.007843,
            size=(300, 300),
            mean=(127.5, 127.5, 127.5),
            swapRB=False,
            crop=False
        )
        
        # Run detection
        self.net.setInput(blob)
        detections = self.net.forward()
        
        # Process detections
        results = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.confidence_threshold:
                class_id = int(detections[0, 0, i, 1])
                
                if class_id >= len(self.classes):
                    continue
                
                class_name = self.classes[class_id]
                
                # Skip background
                if class_name == "background":
                    continue
                
                # Apply filter if enabled
                if self.filter_mode and class_name not in self.filter_classes:
                    continue
                
                # Get bounding box
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                
                # Convert to (x, y, w, h)
                box_w = x2 - x
                box_h = y2 - y
                
                # Clip to frame bounds
                x = max(0, x)
                y = max(0, y)
                box_w = min(box_w, w - x)
                box_h = min(box_h, h - y)
                
                results.append((class_name, float(confidence), x, y, box_w, box_h))
        
        return results
    
    def draw_detections(self, frame, detections):
        """Draw detection results on frame."""
        result = frame.copy()
        
        for class_name, confidence, x, y, w, h in detections:
            # Get class index for color
            class_id = self.classes.index(class_name)
            color = tuple(map(int, self.colors[class_id]))
            
            # Draw using visualizer
            if self.show_labels:
                self.viz.draw_object(result, x, y, w, h, class_name, confidence, color)
            else:
                # Just draw box without label
                cv2.rectangle(result, (x, y), (x+w, y+h), color, 2)
        
        return result
    
    def draw_info(self, frame, detections):
        """Draw information panel."""
        # Count objects by class
        class_counts = {}
        for class_name, _, _, _, _, _ in detections:
            class_counts[class_name] = class_counts.get(class_name, 0) + 1
        
        # Info panel
        info = {
            'Objects': len(detections),
            'Threshold': f"{self.confidence_threshold:.2f}",
            'Filter': 'ON' if self.filter_mode else 'OFF',
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        # Class counts
        if class_counts:
            y_pos = 160
            cv2.putText(frame, "Detected:", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            y_pos += 25
            
            for class_name, count in sorted(class_counts.items()):
                text = f"  {class_name}: {count}"
                cv2.putText(frame, text, (10, y_pos),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
                y_pos += 20
                if y_pos > frame.shape[0] - 100:  # Don't overflow
                    break
        
        return frame
    
    def draw_class_list(self, frame):
        """Draw available classes list."""
        h, w = frame.shape[:2]
        
        # Create semi-transparent overlay on right side
        overlay = frame.copy()
        overlay_width = 250
        cv2.rectangle(overlay, (w - overlay_width, 0), (w, h), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Title
        cv2.putText(frame, "Available Classes:", (w - overlay_width + 10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # List classes
        y_pos = 60
        for i, class_name in enumerate(self.classes[1:], 1):  # Skip background
            color = (0, 255, 0) if class_name in self.filter_classes else (255, 255, 255)
            text = f"{i}. {class_name}"
            cv2.putText(frame, text, (w - overlay_width + 10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
            y_pos += 20
            if y_pos > h - 20:
                break
        
        return frame
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "+/-: Threshold | F: Filter | L: Labels | C: Classes",
            "S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run real-time object detection."""
        print("\n" + "="*60)
        print("REAL-TIME OBJECT DETECTION - MobileNet-SSD")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting detection...")
        print("\nTRY THESE OBJECTS:")
        print("  • Point camera at yourself (person)")
        print("  • Show your laptop, phone, keyboard")
        print("  • Hold up a cup, bottle, book")
        print("  • Try chairs, tables, other furniture")
        print("  • Test with multiple objects at once")
        print("\nPress 'c' to see all available classes")
        
        window_name = "MobileNet-SSD Object Detection"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect objects
                detections = self.detect_objects(frame)
                
                # Draw results
                result = self.draw_detections(frame, detections)
                result = self.draw_info(result, detections)
                
                # Show class list if enabled
                if self.show_class_list:
                    result = self.draw_class_list(result)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('+') or key == ord('='):
                    self.confidence_threshold = min(0.95, self.confidence_threshold + 0.05)
                    print(f"Confidence threshold: {self.confidence_threshold:.2f}")
                    
                elif key == ord('-') or key == ord('_'):
                    self.confidence_threshold = max(0.1, self.confidence_threshold - 0.05)
                    print(f"Confidence threshold: {self.confidence_threshold:.2f}")
                    
                elif key == ord('f'):
                    self.filter_mode = not self.filter_mode
                    print(f"Filter mode: {'ON' if self.filter_mode else 'OFF'}")
                    if self.filter_mode:
                        print(f"  Showing only: {', '.join(self.filter_classes)}")
                    
                elif key == ord('l'):
                    self.show_labels = not self.show_labels
                    print(f"Labels: {'ON' if self.show_labels else 'OFF'}")
                    
                elif key == ord('c'):
                    self.show_class_list = not self.show_class_list
                    print(f"Class list: {'ON' if self.show_class_list else 'OFF'}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"mobilenet_detection_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps.frame_count} frames")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("MobileNet-SSD OBJECT DETECTION")
    print("="*60)
    print("\nMobileNet-SSD is a fast object detector optimized for")
    print("mobile and embedded devices.")
    print("\nWHAT IS MobileNet-SSD?")
    print("  • MobileNet: Efficient neural network architecture")
    print("  • SSD: Single Shot Detector (fast detection)")
    print("  • Detects 20 object classes from COCO dataset")
    print("  • Optimized for real-time performance")
    print("\nCLASSES DETECTED:")
    print("  • People & animals (person, cat, dog, bird, etc.)")
    print("  • Vehicles (car, bus, train, bicycle, etc.)")
    print("  • Furniture (chair, sofa, table, etc.)")
    print("  • Electronics (tvmonitor)")
    print("  • Everyday objects (bottle, cup, book, etc.)")
    print("\nCONTROLS:")
    print("  +/- - Adjust confidence threshold")
    print("  F - Toggle filter mode (common objects only)")
    print("  L - Toggle label display")
    print("  C - Show/hide available classes")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    try:
        detector = MobileNetObjectDetector()
        detector.run()
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ MobileNet-SSD is FAST - good for real-time")
    print("✓ Detects 20 common object classes")
    print("✓ Works well on mobile and embedded devices")
    print("✓ Efficient architecture (fewer parameters)")
    print("\n📊 PERFORMANCE:")
    print("  • Typical FPS: 15-30 (depends on hardware)")
    print("  • Input size: 300x300 pixels")
    print("  • Optimized for speed over accuracy")
    print("\n🎯 WHEN TO USE:")
    print("  • Real-time applications")
    print("  • Mobile/embedded devices")
    print("  • When speed is priority")
    print("  • Common object detection")
    print("\n✗ LIMITATIONS:")
    print("  • Only 20 classes (limited compared to YOLO)")
    print("  • Less accurate than larger models")
    print("  • May miss small objects")
    print("  • Struggles with overlapping objects")
    print("\nNext: Try 11_object_detection_yolo.py for more classes")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
