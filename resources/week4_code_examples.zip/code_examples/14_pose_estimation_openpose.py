"""
Week 4 - Example 14: OpenPose Body Keypoint Detection
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Basic pose estimation using OpenPose COCO model via OpenCV DNN.
    Detects 18 body keypoints and visualizes the skeleton.

Key Concepts:
    - Loading OpenPose model (Caffe format)
    - Body keypoint detection (18-point COCO model)
    - Drawing pose landmarks
    - Visualizing skeleton connections

Required Models:
    - pose_deploy_linevec.prototxt (architecture)
    - pose_iter_440000.caffemodel (weights)
    Download from: https://github.com/CMU-Perceptual-Computing-Lab/openpose

Controls:
    's' - Save current frame with detections
    'q' - Quit

Usage:
    python 14_pose_estimation_openpose.py
    python 14_pose_estimation_openpose.py --image path/to/image.jpg
"""

import cv2
import numpy as np
import argparse
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))
from utils.detection_visualizer import DetectionVisualizer

class OpenPoseDetector:
    """OpenPose body keypoint detector using OpenCV DNN"""
    
    # Body keypoints for COCO model (18 points)
    BODY_PARTS = {
        0: "Nose", 1: "Neck",
        2: "RShoulder", 3: "RElbow", 4: "RWrist",
        5: "LShoulder", 6: "LElbow", 7: "LWrist",
        8: "RHip", 9: "RKnee", 10: "RAnkle",
        11: "LHip", 12: "LKnee", 13: "LAnkle",
        14: "REye", 15: "LEye",
        16: "REar", 17: "LEar"
    }
    
    # Skeleton connections (pairs of keypoints to connect)
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),      # Arms
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13), # Legs
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)         # Head
    ]
    
    def __init__(self, proto_file, weights_file, threshold=0.1):
        """
        Initialize OpenPose detector
        
        Args:
            proto_file: Path to .prototxt file
            weights_file: Path to .caffemodel file
            threshold: Confidence threshold for keypoint detection
        """
        self.threshold = threshold
        self.inWidth = 368
        self.inHeight = 368
        
        # Load the network
        try:
            self.net = cv2.dnn.readNetFromCaffe(proto_file, weights_file)
            print(f"✓ Loaded OpenPose model successfully")
            print(f"  Input size: {self.inWidth}x{self.inHeight}")
            print(f"  Confidence threshold: {self.threshold}")
        except Exception as e:
            print(f"✗ Error loading model: {e}")
            print("\nMake sure you have downloaded the OpenPose models:")
            print("  models/pose_estimation/pose_deploy_linevec.prototxt")
            print("  models/pose_estimation/pose_iter_440000.caffemodel")
            sys.exit(1)
    
    def detect(self, frame):
        """
        Detect body keypoints in frame
        
        Args:
            frame: Input image (BGR)
        
        Returns:
            points: List of (x, y) tuples for 18 keypoints (None if not detected)
        """
        frame_height, frame_width = frame.shape[:2]
        
        # Prepare input blob
        inpBlob = cv2.dnn.blobFromImage(
            frame,
            1.0 / 255,
            (self.inWidth, self.inHeight),
            (0, 0, 0),
            swapRB=False,
            crop=False
        )
        
        # Run inference
        self.net.setInput(inpBlob)
        output = net.forward()
        
        # Output shape: (1, 19, output_height, output_width)
        # 19 = 18 keypoints + 1 background
        H = output.shape[2]
        W = output.shape[3]
        
        # Detect keypoints
        points = []
        for i in range(18):
            # Get confidence map for this keypoint
            probMap = output[0, i, :, :]
            
            # Find location of maximum confidence
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            # Scale to original image dimensions
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            # Store if confidence exceeds threshold
            if prob > self.threshold:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        return points
    
    def draw_skeleton(self, frame, points, show_labels=True):
        """
        Draw detected skeleton on frame
        
        Args:
            frame: Image to draw on
            points: List of detected keypoints
            show_labels: Whether to show keypoint labels
        
        Returns:
            frame: Image with skeleton drawn
        """
        frame_copy = frame.copy()
        
        # Draw skeleton connections
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            
            if points[partA] is not None and points[partB] is not None:
                cv2.line(frame_copy, points[partA], points[partB], 
                        (0, 255, 0), 3, lineType=cv2.LINE_AA)
        
        # Draw keypoints
        for i, point in enumerate(points):
            if point is not None:
                cv2.circle(frame_copy, point, 5, (0, 255, 255), 
                          thickness=-1, lineType=cv2.FILLED)
                
                if show_labels:
                    label = f"{i}"  # Just show keypoint index
                    cv2.putText(frame_copy, label, 
                              (point[0] + 8, point[1] - 8),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.4, 
                              (255, 255, 255), 1, lineType=cv2.LINE_AA)
        
        return frame_copy
    
    def count_detected_keypoints(self, points):
        """Count how many keypoints were detected"""
        return sum(1 for p in points if p is not None)


def process_image(detector, image_path, output_path=None):
    """Process a single image"""
    # Load image
    img = cv2.imread(image_path)
    if img is None:
        print(f"✗ Error loading image: {image_path}")
        return
    
    print(f"\nProcessing: {image_path}")
    print(f"Image size: {img.shape[1]}x{img.shape[0]}")
    
    # Detect pose
    points = detector.detect(img)
    detected_count = detector.count_detected_keypoints(points)
    print(f"Detected keypoints: {detected_count}/18")
    
    # Draw skeleton
    result = detector.draw_skeleton(img, points, show_labels=True)
    
    # Add info text
    cv2.putText(result, f"Keypoints: {detected_count}/18", 
               (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, 
               (0, 255, 0), 2)
    
    # Save if output path specified
    if output_path:
        cv2.imwrite(output_path, result)
        print(f"✓ Saved result to: {output_path}")
    
    # Display
    cv2.imshow('OpenPose Detection', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def process_samples(detector):
    """Process sample images from resources folder"""
    resources_dir = Path(__file__).parent / 'resources'
    
    # Look for person images
    sample_images = [
        'person1.jpg', 'person2.jpg', 'person3.jpg',
        'person4.jpg', 'person5.jpg'
    ]
    
    found_images = []
    for img_name in sample_images:
        img_path = resources_dir / img_name
        if img_path.exists():
            found_images.append(str(img_path))
    
    if not found_images:
        print("✗ No sample images found in resources/ folder")
        print("  Place some person images in resources/ to try detection")
        return
    
    print(f"\nFound {len(found_images)} sample images")
    print("Press any key to advance to next image, 'q' to quit\n")
    
    for img_path in found_images:
        # Load and process
        img = cv2.imread(img_path)
        if img is None:
            continue
        
        print(f"Processing: {Path(img_path).name}")
        
        # Detect pose
        points = detector.detect(img)
        detected_count = detector.count_detected_keypoints(points)
        print(f"  Detected: {detected_count}/18 keypoints")
        
        # Draw result
        result = detector.draw_skeleton(img, points, show_labels=True)
        
        # Add filename
        filename = Path(img_path).name
        cv2.putText(result, filename, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(result, f"Keypoints: {detected_count}/18", (10, 60),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Display
        cv2.imshow('OpenPose Detection', result)
        
        key = cv2.waitKey(0) & 0xFF
        if key == ord('q'):
            break
    
    cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(
        description='OpenPose body keypoint detection'
    )
    parser.add_argument(
        '--image', type=str,
        help='Path to input image (if not provided, processes sample images)'
    )
    parser.add_argument(
        '--output', type=str,
        help='Path to save output image'
    )
    parser.add_argument(
        '--threshold', type=float, default=0.1,
        help='Confidence threshold for keypoint detection (default: 0.1)'
    )
    
    args = parser.parse_args()
    
    # Model paths
    models_dir = Path(__file__).parent / 'models' / 'pose_estimation'
    proto_file = models_dir / 'pose_deploy_linevec.prototxt'
    weights_file = models_dir / 'pose_iter_440000.caffemodel'
    
    # Check if models exist
    if not proto_file.exists() or not weights_file.exists():
        print("✗ OpenPose models not found!")
        print("\nRequired files:")
        print(f"  {proto_file}")
        print(f"  {weights_file}")
        print("\nDownload from:")
        print("  https://github.com/CMU-Perceptual-Computing-Lab/openpose")
        print("  Look in: models/pose/coco/")
        return
    
    # Initialize detector
    detector = OpenPoseDetector(
        str(proto_file), 
        str(weights_file),
        threshold=args.threshold
    )
    
    # Process image or samples
    if args.image:
        process_image(detector, args.image, args.output)
    else:
        process_samples(detector)


if __name__ == '__main__':
    main()
