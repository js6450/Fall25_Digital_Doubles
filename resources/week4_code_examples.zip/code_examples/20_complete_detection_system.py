"""
Week 4 - Example 20: Complete Multi-Modal Detection System
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Full interactive system combining face detection, object detection,
    and pose estimation. Demonstrates mode switching, performance
    optimization, and coordinated multi-modal detection.

Key Concepts:
    - Integrating all detection types
    - Mode switching and UI design
    - Performance optimization for multiple detectors
    - Creative applications of combined detections

Detection Modes:
    1. Faces Only
    2. Objects Only
    3. Pose Only
    4. Faces + Pose
    5. Faces + Objects
    6. All Three Combined

Controls:
    '1-6' - Switch detection modes
    'f' - Toggle FPS display
    's' - Save screenshot
    'r' - Record mode
    'q' - Quit

Usage:
    python 20_complete_detection_system.py
"""

import cv2
import numpy as np
import sys
import time
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator

class CompleteDetectionSystem:
    """Full multi-modal detection system"""
    
    # Detection modes
    MODE_FACES = 0
    MODE_OBJECTS = 1
    MODE_POSE = 2
    MODE_FACE_POSE = 3
    MODE_FACE_OBJECTS = 4
    MODE_ALL = 5
    
    MODE_NAMES = [
        "Faces Only",
        "Objects Only",
        "Pose Only",
        "Faces + Pose",
        "Faces + Objects",
        "All Combined"
    ]
    
    # Object classes (MobileNet-SSD)
    OBJECT_CLASSES = [
        "background", "aeroplane", "bicycle", "bird", "boat",
        "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
        "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
        "sofa", "train", "tvmonitor"
    ]
    
    # Pose pairs
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13),
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)
    ]
    
    def __init__(self, face_proto, face_model, object_proto, object_model,
                 pose_proto, pose_model):
        """Initialize all three detectors"""
        print("Initializing detection system...")
        
        # Load face detector
        try:
            self.face_net = cv2.dnn.readNetFromCaffe(face_proto, face_model)
            print("  ✓ Face detection")
        except Exception as e:
            print(f"  ✗ Face detection failed: {e}")
            sys.exit(1)
        
        # Load object detector
        try:
            self.object_net = cv2.dnn.readNetFromCaffe(object_proto, object_model)
            print("  ✓ Object detection")
        except Exception as e:
            print(f"  ✗ Object detection failed: {e}")
            sys.exit(1)
        
        # Load pose detector
        try:
            self.pose_net = cv2.dnn.readNetFromCaffe(pose_proto, pose_model)
            print("  ✓ Pose estimation")
        except Exception as e:
            print(f"  ✗ Pose estimation failed: {e}")
            sys.exit(1)
        
        # Settings
        self.current_mode = self.MODE_ALL
        self.show_fps = True
        self.recording = False
        self.video_writer = None
        
        # Confidence thresholds
        self.face_confidence = 0.5
        self.object_confidence = 0.5
        self.pose_confidence = 0.1
        
        # Pose settings
        self.pose_input_size = 368
        
        # FPS tracker
        self.fps_calc = FPSCalculator()
        
        # Colors
        self.object_colors = np.random.uniform(0, 255, 
                                               size=(len(self.OBJECT_CLASSES), 3))
        
        print("\n✓ System initialized successfully!\n")
    
    def detect_faces(self, frame):
        """Detect faces"""
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300),
                                     (104.0, 177.0, 123.0), swapRB=False)
        
        self.face_net.setInput(blob)
        detections = self.face_net.forward()
        
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > self.face_confidence:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                faces.append({
                    'box': box.astype("int"),
                    'confidence': confidence
                })
        
        return faces
    
    def detect_objects(self, frame):
        """Detect objects"""
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)),
                                     0.007843, (300, 300),
                                     (127.5, 127.5, 127.5), swapRB=False)
        
        self.object_net.setInput(blob)
        detections = self.object_net.forward()
        
        objects = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > self.object_confidence:
                class_id = int(detections[0, 0, i, 1])
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                objects.append({
                    'class_id': class_id,
                    'class_name': self.OBJECT_CLASSES[class_id],
                    'box': box.astype("int"),
                    'confidence': confidence
                })
        
        return objects
    
    def detect_pose(self, frame):
        """Detect pose keypoints"""
        frame_height, frame_width = frame.shape[:2]
        
        inpBlob = cv2.dnn.blobFromImage(
            frame, 1.0 / 255,
            (self.pose_input_size, self.pose_input_size),
            (0, 0, 0), swapRB=False, crop=False
        )
        
        self.pose_net.setInput(inpBlob)
        output = self.pose_net.forward()
        
        H = output.shape[2]
        W = output.shape[3]
        
        points = []
        for i in range(18):
            probMap = output[0, i, :, :]
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            if prob > self.pose_confidence:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        return points
    
    def draw_faces(self, frame, faces):
        """Draw face detections"""
        for face in faces:
            x1, y1, x2, y2 = face['box']
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{face['confidence']*100:.0f}%",
                       (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                       0.5, (0, 255, 0), 2)
        return frame
    
    def draw_objects(self, frame, objects):
        """Draw object detections"""
        for obj in objects:
            x1, y1, x2, y2 = obj['box']
            color = self.object_colors[obj['class_id']]
            
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            label = f"{obj['class_name']}: {obj['confidence']*100:.0f}%"
            cv2.putText(frame, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        return frame
    
    def draw_pose(self, frame, points):
        """Draw pose skeleton"""
        # Draw connections
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            if points[partA] is not None and points[partB] is not None:
                cv2.line(frame, points[partA], points[partB],
                        (255, 0, 255), 2, lineType=cv2.LINE_AA)
        
        # Draw keypoints
        for point in points:
            if point is not None:
                cv2.circle(frame, point, 4, (0, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
        
        return frame
    
    def process_frame(self, frame):
        """Process frame based on current mode"""
        result = frame.copy()
        
        faces = []
        objects = []
        points = []
        
        # Detect based on mode
        if self.current_mode in [self.MODE_FACES, self.MODE_FACE_POSE,
                                 self.MODE_FACE_OBJECTS, self.MODE_ALL]:
            faces = self.detect_faces(frame)
        
        if self.current_mode in [self.MODE_OBJECTS, self.MODE_FACE_OBJECTS,
                                 self.MODE_ALL]:
            objects = self.detect_objects(frame)
        
        if self.current_mode in [self.MODE_POSE, self.MODE_FACE_POSE,
                                 self.MODE_ALL]:
            points = self.detect_pose(frame)
        
        # Draw detections
        if faces:
            result = self.draw_faces(result, faces)
        if objects:
            result = self.draw_objects(result, objects)
        if points:
            result = self.draw_pose(result, points)
        
        # Draw UI
        result = self.draw_ui(result, len(faces), len(objects),
                             sum(1 for p in points if p is not None))
        
        return result
    
    def draw_ui(self, frame, face_count, object_count, pose_count):
        """Draw user interface overlays"""
        # Mode indicator (top-left)
        mode_name = self.MODE_NAMES[self.current_mode]
        cv2.rectangle(frame, (5, 5), (300, 50), (0, 0, 0), -1)
        cv2.putText(frame, f"Mode: {mode_name}", (15, 35),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        # FPS (top-right)
        if self.show_fps:
            self.fps_calc.update()
            fps_text = f"FPS: {self.fps_calc.get_fps():.1f}"
            text_size = cv2.getTextSize(fps_text, cv2.FONT_HERSHEY_SIMPLEX,
                                       0.7, 2)[0]
            x = frame.shape[1] - text_size[0] - 15
            cv2.rectangle(frame, (x - 10, 5), (frame.shape[1] - 5, 50),
                         (0, 0, 0), -1)
            cv2.putText(frame, fps_text, (x, 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Detection counts (bottom-left)
        y_offset = frame.shape[0] - 120
        cv2.rectangle(frame, (5, y_offset - 10), (200, frame.shape[0] - 45),
                     (0, 0, 0), -1)
        
        cv2.putText(frame, f"Faces: {face_count}", (15, y_offset + 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        y_offset += 30
        cv2.putText(frame, f"Objects: {object_count}", (15, y_offset + 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        y_offset += 30
        cv2.putText(frame, f"Pose: {pose_count}/18", (15, y_offset + 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)
        
        # Recording indicator
        if self.recording:
            cv2.circle(frame, (frame.shape[1] - 30, 30), 10, (0, 0, 255), -1)
            cv2.putText(frame, "REC", (frame.shape[1] - 70, 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        
        # Controls (bottom)
        controls = "1-6: Modes | f: FPS | s: Save | r: Record | q: Quit"
        cv2.putText(frame, controls, (10, frame.shape[0] - 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        return frame
    
    def start_recording(self, frame):
        """Start video recording"""
        if self.video_writer is not None:
            self.stop_recording()
        
        filename = f"detection_recording_{int(time.time())}.avi"
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        fps = 20.0
        h, w = frame.shape[:2]
        
        self.video_writer = cv2.VideoWriter(filename, fourcc, fps, (w, h))
        self.recording = True
        print(f"✓ Started recording: {filename}")
    
    def stop_recording(self):
        """Stop video recording"""
        if self.video_writer is not None:
            self.video_writer.release()
            self.video_writer = None
            self.recording = False
            print("✓ Recording stopped")
    
    def save_frame(self, frame):
        """Save current frame"""
        filename = f"detection_frame_{int(time.time())}.jpg"
        cv2.imwrite(filename, frame)
        print(f"✓ Saved: {filename}")


def main():
    print("="*60)
    print(" COMPLETE MULTI-MODAL DETECTION SYSTEM")
    print("="*60)
    print()
    
    # Model paths
    models_dir = Path(__file__).parent / 'models'
    
    face_proto = models_dir / 'face_detection' / 'deploy.prototxt'
    face_model = models_dir / 'face_detection' / 'res10_300x300_ssd_iter_140000.caffemodel'
    object_proto = models_dir / 'object_detection' / 'MobileNetSSD_deploy.prototxt'
    object_model = models_dir / 'object_detection' / 'MobileNetSSD_deploy.caffemodel'
    pose_proto = models_dir / 'pose_estimation' / 'pose_deploy_linevec.prototxt'
    pose_model = models_dir / 'pose_estimation' / 'pose_iter_440000.caffemodel'
    
    # Check all models
    required_files = [
        face_proto, face_model, object_proto,
        object_model, pose_proto, pose_model
    ]
    
    if not all(f.exists() for f in required_files):
        print("✗ Missing required model files!")
        print("\nRequired:")
        for f in required_files:
            status = "✓" if f.exists() else "✗"
            print(f"  {status} {f}")
        return
    
    # Initialize system
    system = CompleteDetectionSystem(
        str(face_proto), str(face_model),
        str(object_proto), str(object_model),
        str(pose_proto), str(pose_model)
    )
    
    print("Detection Modes:")
    for i, mode_name in enumerate(system.MODE_NAMES):
        print(f"  {i+1}. {mode_name}")
    
    print("\nControls:")
    print("  1-6  : Switch detection mode")
    print("  f    : Toggle FPS display")
    print("  s    : Save screenshot")
    print("  r    : Toggle recording")
    print("  q    : Quit")
    
    print("\nStarting webcam...")
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ System ready!\n")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        
        # Process frame
        result = system.process_frame(frame)
        
        # Record if enabled
        if system.recording and system.video_writer is not None:
            system.video_writer.write(result)
        
        cv2.imshow('Complete Detection System', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key in [ord('1'), ord('2'), ord('3'), 
                     ord('4'), ord('5'), ord('6')]:
            system.current_mode = int(chr(key)) - 1
            print(f"Mode: {system.MODE_NAMES[system.current_mode]}")
        elif key == ord('f'):
            system.show_fps = not system.show_fps
            print(f"FPS display: {'ON' if system.show_fps else 'OFF'}")
        elif key == ord('s'):
            system.save_frame(result)
        elif key == ord('r'):
            if system.recording:
                system.stop_recording()
            else:
                system.start_recording(result)
    
    # Cleanup
    if system.recording:
        system.stop_recording()
    
    cap.release()
    cv2.destroyAllWindows()
    
    print("\n✓ System shutdown complete")


if __name__ == '__main__':
    main()
