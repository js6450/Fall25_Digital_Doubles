"""
02: Face Detection with Deep Neural Networks (DNN)
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Face detection using deep learning models (ResNet-based SSD).
More accurate than Haar Cascades, especially with varied angles and lighting.

Concepts:
- OpenCV DNN module
- Loading pre-trained deep learning models
- Blob preparation and inference
- Confidence scores and thresholds

Usage:
    python 02_face_detection_dnn.py

Prerequisites:
    Run utils/model_downloader.py first to download models

Controls:
    - Press any key to move to next image
    - Press 'q' to quit
    - Press 't' to adjust confidence threshold

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.detection_visualizer import DetectionVisualizer


class DNNFaceDetector:
    """
    Face detector using deep neural network (ResNet-based SSD).
    """
    
    def __init__(self, confidence_threshold=0.5):
        """
        Initialize DNN face detector.
        
        Args:
            confidence_threshold: Minimum confidence for detection (0-1)
        """
        self.confidence_threshold = confidence_threshold
        
        # Model paths
        models_dir = Path(__file__).parent / "models" / "face_detection"
        prototxt_path = models_dir / "deploy.prototxt"
        model_path = models_dir / "res10_300x300_ssd_iter_140000.caffemodel"
        
        # Check if models exist
        if not prototxt_path.exists() or not model_path.exists():
            raise FileNotFoundError(
                f"Model files not found!\n"
                f"Please run: python utils/model_downloader.py\n"
                f"Looking for:\n"
                f"  {prototxt_path}\n"
                f"  {model_path}"
            )
        
        # Load DNN model
        print("Loading DNN face detection model...")
        self.net = cv2.dnn.readNetFromCaffe(
            str(prototxt_path),
            str(model_path)
        )
        
        # Initialize visualizer
        self.viz = DetectionVisualizer()
        
        print("DNN Face Detector initialized")
        print(f"Model: ResNet-based SSD")
        print(f"Confidence threshold: {confidence_threshold}")
    
    def detect_faces(self, image):
        """
        Detect faces using DNN model.
        
        Args:
            image: Input image (BGR format)
        
        Returns:
            detections: List of (x, y, w, h, confidence) tuples
        """
        h, w = image.shape[:2]
        
        # Prepare input blob
        # DNN expects 300x300 input with mean subtraction
        blob = cv2.dnn.blobFromImage(
            image,
            scalefactor=1.0,
            size=(300, 300),
            mean=(104.0, 177.0, 123.0),
            swapRB=False,
            crop=False
        )
        
        # Run inference
        self.net.setInput(blob)
        detections = self.net.forward()
        
        # Process detections
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            # Filter by confidence
            if confidence > self.confidence_threshold:
                # Get bounding box coordinates
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                
                # Convert to (x, y, w, h) format
                face_w = x2 - x
                face_h = y2 - y
                
                # Ensure coordinates are valid
                x = max(0, x)
                y = max(0, y)
                face_w = min(face_w, w - x)
                face_h = min(face_h, h - y)
                
                faces.append((x, y, face_w, face_h, float(confidence)))
        
        return faces
    
    def draw_detections(self, image, faces, show_confidence=True):
        """
        Draw face detection results on image.
        
        Args:
            image: Image to draw on
            faces: List of (x, y, w, h, confidence) tuples
            show_confidence: Whether to show confidence scores
        
        Returns:
            image: Image with detections drawn
        """
        result = image.copy()
        
        # Draw each face
        for i, face_data in enumerate(faces):
            x, y, w, h, confidence = face_data
            
            # Draw using visualizer
            label = f"Face {i+1}"
            self.viz.draw_face(
                result, x, y, w, h,
                confidence=confidence if show_confidence else None,
                label=label
            )
            
            # Draw confidence bar below face
            if show_confidence:
                bar_y = y + h + 10
                if bar_y + 15 < result.shape[0]:  # Check if bar fits in image
                    self.viz.draw_confidence_bar(
                        result,
                        confidence,
                        position=(x, bar_y),
                        width=min(w, 100)
                    )
        
        # Draw detection info
        info = {
            'Faces': len(faces),
            'Threshold': f"{self.confidence_threshold:.2f}"
        }
        self.viz.draw_info_panel(result, info, position=(10, 30))
        
        return result
    
    def set_confidence_threshold(self, threshold):
        """Update confidence threshold."""
        self.confidence_threshold = max(0.0, min(1.0, threshold))
        print(f"Confidence threshold: {self.confidence_threshold:.2f}")


def compare_thresholds(detector, image):
    """
    Show how different confidence thresholds affect detection.
    """
    h, w = image.shape[:2]
    
    # Create 2x2 grid
    grid = np.zeros((h*2, w*2, 3), dtype=np.uint8)
    
    thresholds = [0.3, 0.5, 0.7, 0.9]
    positions = [(0, 0), (0, 1), (1, 0), (1, 1)]
    
    for threshold, (row, col) in zip(thresholds, positions):
        # Set threshold
        detector.set_confidence_threshold(threshold)
        
        # Detect faces
        faces = detector.detect_faces(image)
        
        # Draw results
        result = detector.draw_detections(image, faces)
        
        # Add threshold label
        label = f"Threshold: {threshold} - {len(faces)} faces"
        cv2.putText(result, label, (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        # Place in grid
        y_start = row * h
        x_start = col * w
        grid[y_start:y_start+h, x_start:x_start+w] = result
    
    # Reset to default
    detector.set_confidence_threshold(0.5)
    
    return grid


def main():
    """
    Main function to demonstrate DNN face detection.
    """
    print("\n" + "="*60)
    print("DNN (DEEP LEARNING) FACE DETECTION")
    print("="*60)
    
    try:
        # Initialize detector
        detector = DNNFaceDetector(confidence_threshold=0.5)
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    # Get image files
    resources_dir = Path(__file__).parent / "resources"
    image_files = sorted(resources_dir.glob("*.jpg"))
    
    if not image_files:
        print("Error: No images found in resources folder")
        return
    
    print(f"\nFound {len(image_files)} images")
    print("\nControls:")
    print("  - Press any key to see next image")
    print("  - Press 'q' to quit")
    print("  - Press 't' to see threshold comparison")
    print("  - Press '+' to increase threshold")
    print("  - Press '-' to decrease threshold")
    
    # Process each image
    for img_path in image_files:
        print(f"\nProcessing: {img_path.name}")
        
        # Load image
        image = cv2.imread(str(img_path))
        if image is None:
            print(f"  Error loading {img_path.name}, skipping...")
            continue
        
        # Detect faces
        print("  Detecting faces with DNN...")
        faces = detector.detect_faces(image)
        print(f"  Found {len(faces)} face(s)")
        
        if faces:
            print("  Confidence scores:", [f"{f[4]:.3f}" for f in faces])
        
        # Draw results
        result = detector.draw_detections(image, faces)
        
        # Display
        window_name = f"DNN Face Detection - {img_path.name}"
        cv2.imshow(window_name, result)
        
        # Interactive threshold adjustment
        while True:
            key = cv2.waitKey(0)
            
            if key == ord('+') or key == ord('='):
                # Increase threshold
                new_threshold = detector.confidence_threshold + 0.05
                detector.set_confidence_threshold(new_threshold)
                faces = detector.detect_faces(image)
                result = detector.draw_detections(image, faces)
                cv2.imshow(window_name, result)
                
            elif key == ord('-') or key == ord('_'):
                # Decrease threshold
                new_threshold = detector.confidence_threshold - 0.05
                detector.set_confidence_threshold(new_threshold)
                faces = detector.detect_faces(image)
                result = detector.draw_detections(image, faces)
                cv2.imshow(window_name, result)
                
            elif key == ord('t'):
                # Show threshold comparison
                print("  Showing threshold comparison...")
                grid = compare_thresholds(detector, image)
                cv2.imshow("Threshold Comparison", grid)
                cv2.waitKey(0)
                cv2.destroyWindow("Threshold Comparison")
                
            else:
                # Move to next image
                break
        
        # Quit if 'q' pressed
        if key == ord('q'):
            print("\nQuitting...")
            break
        
        cv2.destroyWindow(window_name)
    
    cv2.destroyAllWindows()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ DNN models are MORE ACCURATE than Haar Cascades")
    print("✓ Better with angles, occlusion, varied lighting")
    print("✓ Confidence scores help filter detections")
    print("✓ Fewer false positives")
    print("✗ Slower than Haar Cascades")
    print("✗ Requires model files (larger download)")
    print("\nWhen to use DNN:")
    print("  - Accuracy is priority")
    print("  - Processing pre-recorded video (not real-time)")
    print("  - Varied poses and lighting conditions")
    print("\nNext: Try 03_realtime_face_detection.py for webcam detection")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
