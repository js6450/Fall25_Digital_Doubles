"""
03: Real-time Face Detection with Webcam
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time face detection from webcam using both Haar Cascades and DNN.
Demonstrates performance differences and allows switching between methods.

Concepts:
- Real-time video processing
- FPS calculation and optimization
- Interactive mode switching
- Face counting and tracking

Usage:
    python 03_realtime_face_detection.py

Prerequisites:
    - Working webcam
    - Run utils/model_downloader.py for DNN mode

Controls:
    - 'h' - Switch to Haar Cascade mode (fast)
    - 'd' - Switch to DNN mode (accurate)
    - 's' - Save current frame
    - 'f' - Toggle FPS display
    - 'c' - Toggle face count
    - 'q' - Quit

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class RealtimeFaceDetector:
    """
    Real-time face detection with multiple detection methods.
    """
    
    def __init__(self):
        """Initialize face detector with both methods."""
        self.mode = "haar"  # Start with fast Haar mode
        self.show_fps = True
        self.show_count = True
        
        # Initialize FPS calculator
        self.fps = FPSCalculator(window_size=30)
        
        # Initialize visualizer
        self.viz = DetectionVisualizer()
        
        # Initialize Haar Cascade
        print("Loading Haar Cascade...")
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.haar_cascade = cv2.CascadeClassifier(cascade_path)
        
        # Try to load DNN model
        self.dnn_net = None
        try:
            models_dir = Path(__file__).parent / "models" / "face_detection"
            prototxt = models_dir / "deploy.prototxt"
            model = models_dir / "res10_300x300_ssd_iter_140000.caffemodel"
            
            if prototxt.exists() and model.exists():
                print("Loading DNN model...")
                self.dnn_net = cv2.dnn.readNetFromCaffe(str(prototxt), str(model))
                print("✓ DNN model loaded (press 'd' to use)")
            else:
                print("⚠ DNN model not found (run utils/model_downloader.py)")
                print("  Will use Haar Cascade only")
        except Exception as e:
            print(f"⚠ Could not load DNN model: {e}")
        
        print("\nReal-time Face Detector initialized")
        print(f"Starting mode: {self.mode.upper()}")
    
    def detect_haar(self, frame):
        """
        Detect faces using Haar Cascade.
        
        Returns:
            List of (x, y, w, h, confidence=None) tuples
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.haar_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )
        
        # Convert to consistent format (add None for confidence)
        return [(x, y, w, h, None) for (x, y, w, h) in faces]
    
    def detect_dnn(self, frame, confidence_threshold=0.5):
        """
        Detect faces using DNN model.
        
        Returns:
            List of (x, y, w, h, confidence) tuples
        """
        if self.dnn_net is None:
            return []
        
        h, w = frame.shape[:2]
        
        # Prepare blob
        blob = cv2.dnn.blobFromImage(
            frame, 1.0, (300, 300),
            (104.0, 177.0, 123.0),
            swapRB=False, crop=False
        )
        
        # Run inference
        self.dnn_net.setInput(blob)
        detections = self.dnn_net.forward()
        
        # Process detections
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > confidence_threshold:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                
                # Convert to (x, y, w, h) format
                face_w = x2 - x
                face_h = y2 - y
                
                # Clip to frame bounds
                x = max(0, x)
                y = max(0, y)
                face_w = min(face_w, w - x)
                face_h = min(face_h, h - y)
                
                faces.append((x, y, face_w, face_h, float(confidence)))
        
        return faces
    
    def detect_faces(self, frame):
        """
        Detect faces using current mode.
        
        Returns:
            List of (x, y, w, h, confidence) tuples
        """
        if self.mode == "haar":
            return self.detect_haar(frame)
        elif self.mode == "dnn":
            return self.detect_dnn(frame)
        return []
    
    def draw_faces(self, frame, faces):
        """Draw face detection results."""
        for i, face_data in enumerate(faces):
            if len(face_data) == 5:
                x, y, w, h, confidence = face_data
            else:
                x, y, w, h = face_data
                confidence = None
            
            # Draw face
            label = f"Face {i+1}"
            self.viz.draw_face(frame, x, y, w, h, confidence, label)
        
        return frame
    
    def draw_ui(self, frame, faces):
        """Draw user interface elements."""
        h, w = frame.shape[:2]
        
        # Build info panel
        info = {}
        
        if self.show_count:
            info['Faces'] = len(faces)
        
        info['Mode'] = self.mode.upper()
        
        if self.show_fps:
            info['FPS'] = f"{self.fps.get_fps():.1f}"
        
        # Draw info panel
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        # Draw controls at bottom
        controls = [
            "H: Haar | D: DNN | S: Save | F: FPS | C: Count | Q: Quit"
        ]
        
        y_pos = h - 30
        for text in controls:
            # Background
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame,
                         (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            
            # Text
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
        
        return frame
    
    def save_frame(self, frame):
        """Save current frame to file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"face_detection_{timestamp}.jpg"
        cv2.imwrite(filename, frame)
        print(f"✓ Saved: {filename}")
    
    def run(self):
        """Run real-time face detection."""
        # Open webcam
        print("\nOpening webcam...")
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            print("Make sure:")
            print("  - Your webcam is connected")
            print("  - No other app is using the camera")
            print("  - Camera permissions are granted")
            return
        
        # Set webcam properties (optional)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        
        print("✓ Webcam opened")
        print("\nStarting detection...")
        print("Press 'q' to quit\n")
        
        window_name = "Real-time Face Detection"
        
        try:
            while True:
                # Read frame
                ret, frame = cap.read()
                if not ret:
                    print("Error reading frame")
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect faces
                faces = self.detect_faces(frame)
                
                # Draw detections
                self.draw_faces(frame, faces)
                
                # Draw UI
                self.draw_ui(frame, faces)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, frame)
                
                # Handle keyboard input
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    print("Quitting...")
                    break
                    
                elif key == ord('h'):
                    self.mode = "haar"
                    print(f"Switched to: {self.mode.upper()}")
                    
                elif key == ord('d'):
                    if self.dnn_net is not None:
                        self.mode = "dnn"
                        print(f"Switched to: {self.mode.upper()}")
                    else:
                        print("DNN model not available")
                    
                elif key == ord('s'):
                    self.save_frame(frame)
                    
                elif key == ord('f'):
                    self.show_fps = not self.show_fps
                    print(f"FPS display: {'ON' if self.show_fps else 'OFF'}")
                    
                elif key == ord('c'):
                    self.show_count = not self.show_count
                    print(f"Face count: {'ON' if self.show_count else 'OFF'}")
        
        finally:
            # Cleanup
            cap.release()
            cv2.destroyAllWindows()
            
            # Print final stats
            print("\n" + "="*60)
            print("SESSION STATISTICS")
            print("="*60)
            print(f"Total frames processed: {self.fps.frame_count}")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")
            print(f"Final mode: {self.mode.upper()}")
            print("="*60 + "\n")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("REAL-TIME FACE DETECTION")
    print("="*60)
    print("\nThis demo shows face detection from your webcam.")
    print("\nFeatures:")
    print("  ✓ Switch between Haar Cascade (fast) and DNN (accurate)")
    print("  ✓ Real-time FPS display")
    print("  ✓ Face counting")
    print("  ✓ Save frames")
    print("\nControls:")
    print("  H - Haar Cascade mode (fast)")
    print("  D - DNN mode (accurate, if available)")
    print("  S - Save current frame")
    print("  F - Toggle FPS display")
    print("  C - Toggle face count")
    print("  Q - Quit")
    print("="*60)
    
    # Create and run detector
    detector = RealtimeFaceDetector()
    detector.run()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ Haar Cascades run at 30+ FPS (very fast)")
    print("✓ DNN is slower (~15-20 FPS) but more accurate")
    print("✓ Real-time detection is different from batch processing")
    print("✓ Mirror flip makes interaction more natural")
    print("\nTips for real-time detection:")
    print("  - Lower resolution = faster FPS")
    print("  - Process every Nth frame if too slow")
    print("  - Use Haar for speed, DNN for accuracy")
    print("  - Good lighting helps both methods")
    print("\nNext: Try 04_face_blur_privacy.py for privacy applications")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
