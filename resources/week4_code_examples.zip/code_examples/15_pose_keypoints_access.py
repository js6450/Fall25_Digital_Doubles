"""
Week 4 - Example 15: OpenPose Keypoint Access and Analysis
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Access specific body keypoints from OpenPose output and calculate
    useful metrics like joint distances and angles. Useful for pose
    analysis, exercise form checking, and gesture recognition.

Key Concepts:
    - Extracting specific keypoint coordinates
    - Calculating distances between joints
    - Calculating joint angles for pose analysis
    - Understanding confidence values

Controls:
    's' - Save current frame
    'q' - Quit

Usage:
    python 15_pose_keypoints_access.py
    python 15_pose_keypoints_access.py --webcam
"""

import cv2
import numpy as np
import math
import argparse
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))

class PoseAnalyzer:
    """Analyze body pose using OpenPose keypoints"""
    
    # Keypoint indices
    NOSE = 0
    NECK = 1
    R_SHOULDER = 2
    R_ELBOW = 3
    R_WRIST = 4
    L_SHOULDER = 5
    L_ELBOW = 6
    L_WRIST = 7
    R_HIP = 8
    R_KNEE = 9
    R_ANKLE = 10
    L_HIP = 11
    L_KNEE = 12
    L_ANKLE = 13
    R_EYE = 14
    L_EYE = 15
    R_EAR = 16
    L_EAR = 17
    
    # Skeleton pairs for drawing
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13),
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)
    ]
    
    def __init__(self, proto_file, weights_file, threshold=0.1):
        """Initialize pose analyzer with OpenPose model"""
        self.threshold = threshold
        self.inWidth = 368
        self.inHeight = 368
        
        # Load model
        try:
            self.net = cv2.dnn.readNetFromCaffe(proto_file, weights_file)
            print("✓ Loaded OpenPose model")
        except Exception as e:
            print(f"✗ Error loading model: {e}")
            sys.exit(1)
    
    def detect_keypoints(self, frame):
        """Detect all body keypoints"""
        frame_height, frame_width = frame.shape[:2]
        
        # Prepare input
        inpBlob = cv2.dnn.blobFromImage(
            frame, 1.0 / 255, (self.inWidth, self.inHeight),
            (0, 0, 0), swapRB=False, crop=False
        )
        
        # Run inference
        self.net.setInput(inpBlob)
        output = self.net.forward()
        
        H = output.shape[2]
        W = output.shape[3]
        
        # Extract keypoints
        points = []
        for i in range(18):
            probMap = output[0, i, :, :]
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            if prob > self.threshold:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        return points
    
    @staticmethod
    def calculate_distance(point1, point2):
        """
        Calculate Euclidean distance between two points
        
        Args:
            point1: (x, y) tuple or None
            point2: (x, y) tuple or None
        
        Returns:
            distance in pixels, or None if either point is None
        """
        if point1 is None or point2 is None:
            return None
        
        x1, y1 = point1
        x2, y2 = point2
        return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    
    @staticmethod
    def calculate_angle(point_a, point_b, point_c):
        """
        Calculate angle at point_b formed by point_a-point_b-point_c
        
        Args:
            point_a: First point (x, y) or None
            point_b: Middle point (vertex) (x, y) or None
            point_c: Last point (x, y) or None
        
        Returns:
            angle in degrees (0-180), or None if any point is None
        """
        if point_a is None or point_b is None or point_c is None:
            return None
        
        # Convert to numpy arrays
        a = np.array(point_a)
        b = np.array(point_b)
        c = np.array(point_c)
        
        # Calculate angle using arctangent
        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - \
                  np.arctan2(a[1] - b[1], a[0] - b[0])
        
        angle = np.abs(radians * 180.0 / np.pi)
        
        # Keep angle in 0-180 range
        if angle > 180.0:
            angle = 360 - angle
        
        return angle
    
    def get_body_measurements(self, points):
        """
        Calculate various body measurements from keypoints
        
        Returns dictionary of measurements
        """
        measurements = {}
        
        # Shoulder width
        measurements['shoulder_width'] = self.calculate_distance(
            points[self.L_SHOULDER], points[self.R_SHOULDER]
        )
        
        # Hip width
        measurements['hip_width'] = self.calculate_distance(
            points[self.L_HIP], points[self.R_HIP]
        )
        
        # Torso length (neck to average hip position)
        if (points[self.NECK] is not None and 
            points[self.L_HIP] is not None and 
            points[self.R_HIP] is not None):
            
            avg_hip_x = (points[self.L_HIP][0] + points[self.R_HIP][0]) / 2
            avg_hip_y = (points[self.L_HIP][1] + points[self.R_HIP][1]) / 2
            avg_hip = (int(avg_hip_x), int(avg_hip_y))
            measurements['torso_length'] = self.calculate_distance(
                points[self.NECK], avg_hip
            )
        else:
            measurements['torso_length'] = None
        
        # Arm lengths
        measurements['left_upper_arm'] = self.calculate_distance(
            points[self.L_SHOULDER], points[self.L_ELBOW]
        )
        measurements['left_forearm'] = self.calculate_distance(
            points[self.L_ELBOW], points[self.L_WRIST]
        )
        measurements['right_upper_arm'] = self.calculate_distance(
            points[self.R_SHOULDER], points[self.R_ELBOW]
        )
        measurements['right_forearm'] = self.calculate_distance(
            points[self.R_ELBOW], points[self.R_WRIST]
        )
        
        # Leg lengths
        measurements['left_thigh'] = self.calculate_distance(
            points[self.L_HIP], points[self.L_KNEE]
        )
        measurements['left_shin'] = self.calculate_distance(
            points[self.L_KNEE], points[self.L_ANKLE]
        )
        measurements['right_thigh'] = self.calculate_distance(
            points[self.R_HIP], points[self.R_KNEE]
        )
        measurements['right_shin'] = self.calculate_distance(
            points[self.R_KNEE], points[self.R_ANKLE]
        )
        
        return measurements
    
    def get_joint_angles(self, points):
        """Calculate angles at major joints"""
        angles = {}
        
        # Elbow angles
        angles['left_elbow'] = self.calculate_angle(
            points[self.L_SHOULDER],
            points[self.L_ELBOW],
            points[self.L_WRIST]
        )
        angles['right_elbow'] = self.calculate_angle(
            points[self.R_SHOULDER],
            points[self.R_ELBOW],
            points[self.R_WRIST]
        )
        
        # Knee angles
        angles['left_knee'] = self.calculate_angle(
            points[self.L_HIP],
            points[self.L_KNEE],
            points[self.L_ANKLE]
        )
        angles['right_knee'] = self.calculate_angle(
            points[self.R_HIP],
            points[self.R_KNEE],
            points[self.R_ANKLE]
        )
        
        # Shoulder angles (relative to vertical)
        # This is the angle between shoulder-elbow and vertical line
        if (points[self.L_SHOULDER] is not None and 
            points[self.L_ELBOW] is not None):
            # Create a point directly above the shoulder
            above_left_shoulder = (points[self.L_SHOULDER][0], 
                                  points[self.L_SHOULDER][1] - 100)
            angles['left_shoulder'] = self.calculate_angle(
                above_left_shoulder,
                points[self.L_SHOULDER],
                points[self.L_ELBOW]
            )
        else:
            angles['left_shoulder'] = None
        
        if (points[self.R_SHOULDER] is not None and 
            points[self.R_ELBOW] is not None):
            above_right_shoulder = (points[self.R_SHOULDER][0],
                                   points[self.R_SHOULDER][1] - 100)
            angles['right_shoulder'] = self.calculate_angle(
                above_right_shoulder,
                points[self.R_SHOULDER],
                points[self.R_ELBOW]
            )
        else:
            angles['right_shoulder'] = None
        
        # Hip angles
        angles['left_hip'] = self.calculate_angle(
            points[self.NECK],
            points[self.L_HIP],
            points[self.L_KNEE]
        )
        angles['right_hip'] = self.calculate_angle(
            points[self.NECK],
            points[self.R_HIP],
            points[self.R_KNEE]
        )
        
        return angles
    
    def draw_analysis(self, frame, points):
        """Draw skeleton and analysis overlays"""
        result = frame.copy()
        
        # Draw skeleton
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            if points[partA] is not None and points[partB] is not None:
                cv2.line(result, points[partA], points[partB],
                        (0, 255, 0), 2, lineType=cv2.LINE_AA)
        
        # Draw keypoints
        for i, point in enumerate(points):
            if point is not None:
                cv2.circle(result, point, 4, (0, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
        
        # Get measurements and angles
        measurements = self.get_body_measurements(points)
        angles = self.get_joint_angles(points)
        
        # Draw angle arcs for elbows and knees
        self._draw_angle_arc(result, points[self.L_SHOULDER],
                            points[self.L_ELBOW], points[self.L_WRIST],
                            angles['left_elbow'])
        self._draw_angle_arc(result, points[self.R_SHOULDER],
                            points[self.R_ELBOW], points[self.R_WRIST],
                            angles['right_elbow'])
        self._draw_angle_arc(result, points[self.L_HIP],
                            points[self.L_KNEE], points[self.L_ANKLE],
                            angles['left_knee'])
        self._draw_angle_arc(result, points[self.R_HIP],
                            points[self.R_KNEE], points[self.R_ANKLE],
                            angles['right_knee'])
        
        # Display measurements on frame
        y_offset = 30
        line_height = 25
        
        cv2.putText(result, "Body Measurements:", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        y_offset += line_height
        
        # Show key measurements
        if measurements['shoulder_width']:
            cv2.putText(result, 
                       f"Shoulder width: {measurements['shoulder_width']:.1f}px",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (0, 255, 0), 1)
            y_offset += line_height
        
        # Show key angles
        cv2.putText(result, "Joint Angles:", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        y_offset += line_height
        
        if angles['left_elbow']:
            cv2.putText(result, f"L Elbow: {angles['left_elbow']:.1f}°",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (0, 255, 255), 1)
            y_offset += line_height
        
        if angles['right_elbow']:
            cv2.putText(result, f"R Elbow: {angles['right_elbow']:.1f}°",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (0, 255, 255), 1)
            y_offset += line_height
        
        if angles['left_knee']:
            cv2.putText(result, f"L Knee: {angles['left_knee']:.1f}°",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 0, 255), 1)
            y_offset += line_height
        
        if angles['right_knee']:
            cv2.putText(result, f"R Knee: {angles['right_knee']:.1f}°",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 0, 255), 1)
        
        return result, measurements, angles
    
    def _draw_angle_arc(self, frame, point_a, point_b, point_c, angle):
        """Draw an arc showing the angle at point_b"""
        if point_a is None or point_b is None or point_c is None or angle is None:
            return
        
        # Draw a small arc at the joint
        radius = 30
        
        # Calculate angles for arc
        angle1 = math.degrees(math.atan2(point_a[1] - point_b[1],
                                         point_a[0] - point_b[0]))
        angle2 = math.degrees(math.atan2(point_c[1] - point_b[1],
                                         point_c[0] - point_b[0]))
        
        # Draw arc
        cv2.ellipse(frame, point_b, (radius, radius), 0,
                   angle1, angle2, (255, 255, 0), 2)
        
        # Draw angle text
        text_offset = (radius + 10, 0)
        text_pos = (point_b[0] + text_offset[0], point_b[1] + text_offset[1])
        cv2.putText(frame, f"{angle:.0f}°", text_pos,
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)


def webcam_mode(analyzer):
    """Run pose analysis on webcam feed"""
    print("\n=== Webcam Pose Analysis ===")
    print("Controls:")
    print("  's' - Save current frame")
    print("  'q' - Quit")
    print("\nStarting webcam...")
    
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ Webcam opened successfully\n")
    
    frame_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)  # Mirror for selfie view
        frame_count += 1
        
        # Detect keypoints
        points = analyzer.detect_keypoints(frame)
        
        # Draw analysis
        result, measurements, angles = analyzer.draw_analysis(frame, points)
        
        # Display FPS
        cv2.putText(result, f"Frame: {frame_count}", (10, frame.shape[0] - 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv2.imshow('Pose Keypoint Analysis', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            filename = f'pose_analysis_{frame_count}.jpg'
            cv2.imwrite(filename, result)
            print(f"✓ Saved: {filename}")
    
    cap.release()
    cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(
        description='Analyze pose keypoints and calculate angles/distances'
    )
    parser.add_argument(
        '--webcam', action='store_true',
        help='Run on webcam feed'
    )
    
    args = parser.parse_args()
    
    # Model paths
    models_dir = Path(__file__).parent / 'models' / 'pose_estimation'
    proto_file = models_dir / 'pose_deploy_linevec.prototxt'
    weights_file = models_dir / 'pose_iter_440000.caffemodel'
    
    # Check models
    if not proto_file.exists() or not weights_file.exists():
        print("✗ OpenPose models not found!")
        print(f"\nRequired:\n  {proto_file}\n  {weights_file}")
        return
    
    # Initialize analyzer
    analyzer = PoseAnalyzer(str(proto_file), str(weights_file))
    
    # Run webcam mode
    if args.webcam:
        webcam_mode(analyzer)
    else:
        print("Use --webcam to run on webcam feed")
        print("Example: python 15_pose_keypoints_access.py --webcam")


if __name__ == '__main__':
    main()
