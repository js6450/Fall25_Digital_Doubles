"""
Week 4 - Example 16: Pose-Triggered Interactive Effects
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Interactive visual effects triggered by specific body poses.
    Demonstrates using pose detection for creative installations
    and interactive art.

Key Concepts:
    - Detecting specific body poses
    - Triggering effects based on joint positions
    - Real-time pose-based interaction
    - Creative applications of pose estimation

Effects:
    - Arms raised → Grayscale
    - Squat detected → Blur
    - T-pose → Invert colors
    - Victory pose → Rainbow effect
    - One leg raised → Rotate frame

Controls:
    '1' - Show/hide skeleton
    '2' - Show/hide effect names
    'r' - Reset effects
    'q' - Quit

Usage:
    python 16_pose_interactive_effects.py
"""

import cv2
import numpy as np
import math
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))

class PoseEffects:
    """Apply visual effects based on detected poses"""
    
    # Keypoint indices
    NOSE = 0
    NECK = 1
    R_SHOULDER = 2
    R_ELBOW = 3
    R_WRIST = 4
    L_SHOULDER = 5
    L_ELBOW = 6
    L_WRIST = 7
    R_HIP = 8
    R_KNEE = 9
    R_ANKLE = 10
    L_HIP = 11
    L_KNEE = 12
    L_ANKLE = 13
    
    POSE_PAIRS = [
        (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
        (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13),
        (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)
    ]
    
    def __init__(self, proto_file, weights_file):
        """Initialize pose detector and effects"""
        self.threshold = 0.1
        self.inWidth = 368
        self.inHeight = 368
        
        # Load model
        try:
            self.net = cv2.dnn.readNetFromCaffe(proto_file, weights_file)
            print("✓ Loaded OpenPose model")
        except Exception as e:
            print(f"✗ Error loading model: {e}")
            sys.exit(1)
        
        # Effect settings
        self.show_skeleton = True
        self.show_effect_names = True
        
        # Effect history for smoothing
        self.effect_history = []
        self.history_size = 5
    
    def detect_keypoints(self, frame):
        """Detect body keypoints"""
        frame_height, frame_width = frame.shape[:2]
        
        inpBlob = cv2.dnn.blobFromImage(
            frame, 1.0 / 255, (self.inWidth, self.inHeight),
            (0, 0, 0), swapRB=False, crop=False
        )
        
        self.net.setInput(inpBlob)
        output = self.net.forward()
        
        H = output.shape[2]
        W = output.shape[3]
        
        points = []
        for i in range(18):
            probMap = output[0, i, :, :]
            minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
            
            x = (frame_width * point[0]) / W
            y = (frame_height * point[1]) / H
            
            if prob > self.threshold:
                points.append((int(x), int(y)))
            else:
                points.append(None)
        
        return points
    
    def calculate_angle(self, point_a, point_b, point_c):
        """Calculate angle at point_b"""
        if point_a is None or point_b is None or point_c is None:
            return None
        
        a = np.array(point_a)
        b = np.array(point_b)
        c = np.array(point_c)
        
        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - \
                  np.arctan2(a[1] - b[1], a[0] - b[0])
        angle = np.abs(radians * 180.0 / np.pi)
        
        if angle > 180.0:
            angle = 360 - angle
        
        return angle
    
    def detect_pose_type(self, points):
        """
        Detect specific pose types
        
        Returns: tuple (pose_name, confidence)
        """
        poses_detected = []
        
        # 1. Arms Raised (both wrists above shoulders)
        if self._arms_raised(points):
            poses_detected.append(("Arms Raised", 1.0))
        
        # 2. Squat (knees bent < 120 degrees)
        if self._squat_detected(points):
            poses_detected.append(("Squat", 1.0))
        
        # 3. T-Pose (arms out horizontally)
        if self._t_pose_detected(points):
            poses_detected.append(("T-Pose", 1.0))
        
        # 4. Victory Pose (arms in V shape above head)
        if self._victory_pose(points):
            poses_detected.append(("Victory", 1.0))
        
        # 5. One Leg Raised
        if self._one_leg_raised(points):
            poses_detected.append(("One Leg Up", 1.0))
        
        # 6. Leaning (body tilted)
        if self._leaning_detected(points):
            poses_detected.append(("Leaning", 0.8))
        
        if poses_detected:
            return poses_detected[0]  # Return first detected pose
        
        return ("Neutral", 0.0)
    
    def _arms_raised(self, points):
        """Check if both arms are raised above head"""
        l_wrist = points[self.L_WRIST]
        r_wrist = points[self.R_WRIST]
        l_shoulder = points[self.L_SHOULDER]
        r_shoulder = points[self.R_SHOULDER]
        
        if all(p is not None for p in [l_wrist, r_wrist, l_shoulder, r_shoulder]):
            left_raised = l_wrist[1] < l_shoulder[1] - 50
            right_raised = r_wrist[1] < r_shoulder[1] - 50
            return left_raised and right_raised
        
        return False
    
    def _squat_detected(self, points):
        """Check if person is squatting (knee angle < 120)"""
        l_knee_angle = self.calculate_angle(
            points[self.L_HIP], points[self.L_KNEE], points[self.L_ANKLE]
        )
        r_knee_angle = self.calculate_angle(
            points[self.R_HIP], points[self.R_KNEE], points[self.R_ANKLE]
        )
        
        if l_knee_angle and l_knee_angle < 120:
            return True
        if r_knee_angle and r_knee_angle < 120:
            return True
        
        return False
    
    def _t_pose_detected(self, points):
        """Check for T-pose (arms extended horizontally)"""
        l_shoulder = points[self.L_SHOULDER]
        r_shoulder = points[self.R_SHOULDER]
        l_elbow = points[self.L_ELBOW]
        r_elbow = points[self.R_ELBOW]
        l_wrist = points[self.L_WRIST]
        r_wrist = points[self.R_WRIST]
        
        if all(p is not None for p in [l_shoulder, r_shoulder, l_wrist, r_wrist]):
            # Check if arms are roughly horizontal
            l_arm_horizontal = abs(l_wrist[1] - l_shoulder[1]) < 50
            r_arm_horizontal = abs(r_wrist[1] - r_shoulder[1]) < 50
            
            # Check if arms are extended (elbows near shoulders height)
            if l_elbow and r_elbow:
                l_elbow_extended = abs(l_elbow[1] - l_shoulder[1]) < 50
                r_elbow_extended = abs(r_elbow[1] - r_shoulder[1]) < 50
                
                return (l_arm_horizontal and r_arm_horizontal and
                       l_elbow_extended and r_elbow_extended)
        
        return False
    
    def _victory_pose(self, points):
        """Check for victory pose (V shape with arms)"""
        l_wrist = points[self.L_WRIST]
        r_wrist = points[self.R_WRIST]
        neck = points[self.NECK]
        
        if all(p is not None for p in [l_wrist, r_wrist, neck]):
            # Both wrists above neck
            both_raised = l_wrist[1] < neck[1] and r_wrist[1] < neck[1]
            
            # Wrists separated (V shape)
            wrist_distance = abs(l_wrist[0] - r_wrist[0])
            
            return both_raised and wrist_distance > 100
        
        return False
    
    def _one_leg_raised(self, points):
        """Check if one leg is raised"""
        l_ankle = points[self.L_ANKLE]
        r_ankle = points[self.R_ANKLE]
        l_hip = points[self.L_HIP]
        r_hip = points[self.R_HIP]
        
        if all(p is not None for p in [l_ankle, r_ankle, l_hip, r_hip]):
            # Check if ankles are at different heights
            ankle_diff = abs(l_ankle[1] - r_ankle[1])
            
            # One ankle should be significantly higher
            return ankle_diff > 100
        
        return False
    
    def _leaning_detected(self, points):
        """Check if body is leaning to one side"""
        neck = points[self.NECK]
        l_hip = points[self.L_HIP]
        r_hip = points[self.R_HIP]
        
        if all(p is not None for p in [neck, l_hip, r_hip]):
            # Calculate average hip position
            avg_hip_x = (l_hip[0] + r_hip[0]) / 2
            
            # Check horizontal distance
            lean = abs(neck[0] - avg_hip_x)
            
            return lean > 50
        
        return False
    
    def apply_effect(self, frame, pose_name):
        """Apply visual effect based on detected pose"""
        result = frame.copy()
        
        if pose_name == "Arms Raised":
            # Grayscale effect
            result = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
        
        elif pose_name == "Squat":
            # Blur effect
            result = cv2.GaussianBlur(result, (51, 51), 0)
        
        elif pose_name == "T-Pose":
            # Invert colors
            result = cv2.bitwise_not(result)
        
        elif pose_name == "Victory":
            # Rainbow color shift
            hsv = cv2.cvtColor(result, cv2.COLOR_BGR2HSV)
            hsv[:, :, 0] = (hsv[:, :, 0] + 30) % 180
            result = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        
        elif pose_name == "One Leg Up":
            # Rotate frame
            h, w = result.shape[:2]
            center = (w // 2, h // 2)
            angle = 15
            matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            result = cv2.warpAffine(result, matrix, (w, h))
        
        elif pose_name == "Leaning":
            # Edge detection overlay
            gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            edges_colored = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
            result = cv2.addWeighted(result, 0.7, edges_colored, 0.3, 0)
        
        return result
    
    def draw_skeleton(self, frame, points):
        """Draw skeleton overlay"""
        for pair in self.POSE_PAIRS:
            partA, partB = pair
            if points[partA] is not None and points[partB] is not None:
                cv2.line(frame, points[partA], points[partB],
                        (0, 255, 0), 2, lineType=cv2.LINE_AA)
        
        for point in points:
            if point is not None:
                cv2.circle(frame, point, 4, (0, 255, 255),
                          thickness=-1, lineType=cv2.FILLED)
        
        return frame
    
    def process_frame(self, frame):
        """Process frame with pose detection and effects"""
        # Detect keypoints
        points = self.detect_keypoints(frame)
        
        # Detect pose type
        pose_name, confidence = self.detect_pose_type(points)
        
        # Apply effect
        result = self.apply_effect(frame, pose_name)
        
        # Draw skeleton if enabled
        if self.show_skeleton:
            result = self.draw_skeleton(result, points)
        
        # Show effect name if enabled
        if self.show_effect_names:
            if pose_name != "Neutral":
                cv2.rectangle(result, (10, 10), (400, 80), (0, 0, 0), -1)
                cv2.putText(result, f"Pose: {pose_name}", (20, 40),
                           cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
                cv2.putText(result, "Effect Active!", (20, 70),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            else:
                cv2.putText(result, "No special pose detected", (20, 40),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Show controls
        controls = [
            "'1' - Toggle skeleton",
            "'2' - Toggle effect names",
            "'q' - Quit"
        ]
        y_offset = result.shape[0] - 70
        for control in controls:
            cv2.putText(result, control, (10, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            y_offset += 20
        
        return result


def main():
    print("=== Pose-Triggered Interactive Effects ===\n")
    
    # Model paths
    models_dir = Path(__file__).parent / 'models' / 'pose_estimation'
    proto_file = models_dir / 'pose_deploy_linevec.prototxt'
    weights_file = models_dir / 'pose_iter_440000.caffemodel'
    
    # Check models
    if not proto_file.exists() or not weights_file.exists():
        print("✗ OpenPose models not found!")
        print(f"\nRequired:\n  {proto_file}\n  {weights_file}")
        return
    
    # Initialize
    effects = PoseEffects(str(proto_file), str(weights_file))
    
    print("\nPose Effects:")
    print("  • Arms Raised → Grayscale")
    print("  • Squat → Blur")
    print("  • T-Pose → Inverted Colors")
    print("  • Victory → Rainbow")
    print("  • One Leg Up → Rotate")
    print("  • Leaning → Edge Detection")
    
    print("\nControls:")
    print("  '1' - Toggle skeleton overlay")
    print("  '2' - Toggle effect names")
    print("  'q' - Quit")
    print("\nStarting webcam...\n")
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ Webcam ready! Try different poses to trigger effects.\n")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)  # Mirror
        
        # Process frame
        result = effects.process_frame(frame)
        
        cv2.imshow('Pose Interactive Effects', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('1'):
            effects.show_skeleton = not effects.show_skeleton
            print(f"Skeleton: {'ON' if effects.show_skeleton else 'OFF'}")
        elif key == ord('2'):
            effects.show_effect_names = not effects.show_effect_names
            print(f"Effect names: {'ON' if effects.show_effect_names else 'OFF'}")
    
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
