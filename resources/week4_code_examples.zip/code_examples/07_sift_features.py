"""
07: SIFT Feature Detection
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time SIFT (Scale-Invariant Feature Transform) feature detection.
Point your webcam at textured objects (books, products, patterned items)
to see distinctive keypoints detected with scale and orientation.

Concepts:
- SIFT algorithm fundamentals
- Scale-invariant keypoint detection
- Feature descriptors
- Orientation and scale visualization

Usage:
    python 07_sift_features.py

Controls:
    - 'k' - Toggle keypoint visualization style
    - 'd' - Toggle descriptor info display
    - '+' - Increase feature count
    - '-' - Decrease feature count
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Show textured objects (books with text, logos, patterns)
    - Rotate objects - see features stay stable
    - Change distance - features adapt to scale
    - Compare smooth vs textured surfaces

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class SIFTFeatureDetector:
    """
    Real-time SIFT feature detection and visualization.
    """
    
    def __init__(self):
        """Initialize SIFT detector."""
        # Check if SIFT is available
        try:
            self.sift = cv2.SIFT_create()
            print("✓ SIFT detector initialized")
        except AttributeError:
            print("Error: SIFT not available")
            print("Install opencv-contrib-python:")
            print("  pip install opencv-contrib-python")
            raise
        
        # Detection parameters
        self.max_features = 100
        
        # Visualization settings
        self.draw_style = "rich"  # "rich", "simple", "circles"
        self.show_descriptors = False
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        print(f"Max features: {self.max_features}")
        print(f"Draw style: {self.draw_style}")
    
    def detect_sift_features(self, frame):
        """
        Detect SIFT features in frame.
        
        Returns:
            keypoints: List of cv2.KeyPoint objects
            descriptors: Feature descriptors (128-dimensional vectors)
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect keypoints and compute descriptors
        keypoints, descriptors = self.sift.detectAndCompute(gray, None)
        
        # Limit number of features (take strongest)
        if len(keypoints) > self.max_features:
            # Sort by response (strength)
            keypoints = sorted(keypoints, key=lambda x: x.response, reverse=True)
            keypoints = keypoints[:self.max_features]
            if descriptors is not None:
                descriptors = descriptors[:self.max_features]
        
        return keypoints, descriptors
    
    def draw_keypoints_simple(self, frame, keypoints):
        """Draw keypoints as simple circles."""
        result = frame.copy()
        
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            cv2.circle(result, (x, y), 3, (0, 255, 255), -1)
            cv2.circle(result, (x, y), 5, (255, 255, 255), 1)
        
        return result
    
    def draw_keypoints_rich(self, frame, keypoints):
        """Draw keypoints with scale and orientation."""
        result = frame.copy()
        
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            size = int(kp.size)
            angle = kp.angle
            
            # Draw circle representing scale
            cv2.circle(result, (x, y), size, (0, 255, 255), 2)
            
            # Draw line representing orientation
            if angle >= 0:  # angle is -1 if not computed
                angle_rad = angle * np.pi / 180.0
                end_x = int(x + size * np.cos(angle_rad))
                end_y = int(y + size * np.sin(angle_rad))
                cv2.line(result, (x, y), (end_x, end_y), (255, 0, 255), 2)
            
            # Draw center point
            cv2.circle(result, (x, y), 2, (255, 255, 255), -1)
        
        return result
    
    def draw_keypoints_circles(self, frame, keypoints):
        """Draw keypoints as colored circles by response strength."""
        result = frame.copy()
        
        if not keypoints:
            return result
        
        # Get response range for coloring
        responses = [kp.response for kp in keypoints]
        min_resp = min(responses)
        max_resp = max(responses)
        resp_range = max_resp - min_resp if max_resp > min_resp else 1
        
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            
            # Color based on response strength (green = strong, red = weak)
            strength = (kp.response - min_resp) / resp_range
            color = (0, int(255 * strength), int(255 * (1 - strength)))
            
            # Draw
            radius = max(3, int(kp.size / 4))
            cv2.circle(result, (x, y), radius, color, -1)
            cv2.circle(result, (x, y), radius + 2, (255, 255, 255), 1)
        
        return result
    
    def draw_features(self, frame, keypoints):
        """Draw keypoints based on current style."""
        if self.draw_style == "simple":
            return self.draw_keypoints_simple(frame, keypoints)
        elif self.draw_style == "rich":
            return self.draw_keypoints_rich(frame, keypoints)
        elif self.draw_style == "circles":
            return self.draw_keypoints_circles(frame, keypoints)
        else:
            # Use OpenCV's built-in
            return cv2.drawKeypoints(frame, keypoints, None,
                                    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    
    def draw_info(self, frame, keypoints, descriptors):
        """Draw information panel."""
        info = {
            'Features': len(keypoints),
            'Max': self.max_features,
            'Style': self.draw_style,
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        # Show descriptor info if enabled
        if self.show_descriptors and keypoints and descriptors is not None:
            y_start = 150
            cv2.putText(frame, "Descriptor Info:", (10, y_start),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(frame, f"Dimensions: 128", (10, y_start + 25),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
            cv2.putText(frame, f"Total: {len(descriptors)}", (10, y_start + 50),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
            
            # Show strongest feature info
            if keypoints:
                strongest = max(keypoints, key=lambda x: x.response)
                cv2.putText(frame, f"Strongest:", (10, y_start + 80),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                cv2.putText(frame, f"  Response: {strongest.response:.2f}", 
                           (10, y_start + 100),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
                cv2.putText(frame, f"  Size: {strongest.size:.1f}", 
                           (10, y_start + 120),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
        
        return frame
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "K: Style | D: Descriptors | +/-: Count",
            "S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run real-time SIFT detection."""
        print("\n" + "="*60)
        print("REAL-TIME SIFT FEATURE DETECTION")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting SIFT detection...")
        print("\nTRY THESE:")
        print("  • Show books with text - lots of features!")
        print("  • Try product packaging with logos")
        print("  • Compare smooth objects vs textured ones")
        print("  • Rotate objects - features stay stable")
        print("  • Change distance - see scale adaptation")
        
        window_name = "SIFT Feature Detection"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect SIFT features
                keypoints, descriptors = self.detect_sift_features(frame)
                
                # Draw features
                result = self.draw_features(frame, keypoints)
                
                # Draw info
                result = self.draw_info(result, keypoints, descriptors)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('k'):
                    styles = ["simple", "rich", "circles"]
                    current = styles.index(self.draw_style)
                    self.draw_style = styles[(current + 1) % len(styles)]
                    print(f"Draw style: {self.draw_style.upper()}")
                    
                elif key == ord('d'):
                    self.show_descriptors = not self.show_descriptors
                    print(f"Descriptor info: {'ON' if self.show_descriptors else 'OFF'}")
                    
                elif key == ord('+') or key == ord('='):
                    self.max_features = min(500, self.max_features + 20)
                    print(f"Max features: {self.max_features}")
                    
                elif key == ord('-') or key == ord('_'):
                    self.max_features = max(20, self.max_features - 20)
                    print(f"Max features: {self.max_features}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"sift_features_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps.frame_count} frames")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("SIFT: SCALE-INVARIANT FEATURE TRANSFORM")
    print("="*60)
    print("\nSIFT is a powerful algorithm for detecting and describing")
    print("distinctive features that are invariant to:")
    print("  • Scale (zoom in/out)")
    print("  • Rotation")
    print("  • Illumination changes")
    print("  • Partial occlusion")
    print("\nHOW SIFT WORKS:")
    print("  1. Scale-space extrema detection")
    print("  2. Keypoint localization")
    print("  3. Orientation assignment")
    print("  4. Descriptor generation (128-dimensional)")
    print("\nVISUALIZATION:")
    print("  • Circle size = feature scale")
    print("  • Line = orientation direction")
    print("  • Color = feature strength")
    print("\nCONTROLS:")
    print("  K - Change visualization style")
    print("  D - Toggle descriptor information")
    print("  +/- - Adjust max feature count")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    try:
        detector = SIFTFeatureDetector()
        detector.run()
    except AttributeError:
        print("\nSIFT requires opencv-contrib-python")
        print("Install with: pip install opencv-contrib-python")
        return
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ SIFT finds distinctive, stable features")
    print("✓ Features include:")
    print("  • Position (x, y)")
    print("  • Scale (size)")
    print("  • Orientation (angle)")
    print("  • Descriptor (128-D vector)")
    print("\n✓ GOOD FOR:")
    print("  • Object recognition")
    print("  • Image matching")
    print("  • 3D reconstruction")
    print("  • Panorama stitching")
    print("\n✗ LIMITATIONS:")
    print("  • Slower than simpler methods")
    print("  • Patented (was - free since 2020)")
    print("  • Needs textured surfaces")
    print("  • Not great on smooth objects")
    print("\nOBSERVATIONS:")
    print("  • Textured objects = many features")
    print("  • Smooth surfaces = few features")
    print("  • Edges and corners = strong features")
    print("  • Features persist across transformations")
    print("\nNext: Try 08_orb_features.py for a faster alternative")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
