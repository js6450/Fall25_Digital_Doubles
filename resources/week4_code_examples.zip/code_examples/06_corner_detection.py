"""
06: Corner Detection - Harris and Shi-Tomasi
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time corner detection using Harris Corner Detector and Shi-Tomasi method.
Point your webcam at objects with corners (books, monitors, windows, boxes)
to see corners detected in real-time.

Concepts:
- Corner detection fundamentals
- Harris Corner Detector
- Shi-Tomasi (Good Features to Track)
- Feature quality and detection parameters

Usage:
    python 06_corner_detection.py

Controls:
    - '1' - Harris corner detection
    - '2' - Shi-Tomasi corner detection
    - '3' - Show both side-by-side
    - '+' - Increase corner count
    - '-' - Decrease corner count
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Point at corners of books, monitors, picture frames
    - Try textured surfaces vs smooth surfaces
    - See how lighting affects detection

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class CornerDetector:
    """
    Real-time corner detection with multiple methods.
    """
    
    def __init__(self):
        """Initialize corner detector."""
        self.mode = "harris"  # "harris", "shi-tomasi", or "both"
        self.max_corners = 100  # Maximum corners to detect
        self.quality_level = 0.01  # Shi-Tomasi quality threshold
        self.min_distance = 10  # Minimum distance between corners
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        print("Corner Detector initialized")
        print(f"Mode: {self.mode}")
        print(f"Max corners: {self.max_corners}")
    
    def detect_harris_corners(self, frame):
        """
        Detect corners using Harris Corner Detector.
        
        Returns:
            corners: List of (x, y) corner coordinates
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = np.float32(gray)
        
        # Harris corner detection
        # blockSize: neighborhood size
        # ksize: aperture parameter for Sobel
        # k: Harris detector free parameter
        harris_response = cv2.cornerHarris(gray, blockSize=2, ksize=3, k=0.04)
        
        # Dilate to mark corners
        harris_response = cv2.dilate(harris_response, None)
        
        # Threshold for corner detection
        threshold = 0.01 * harris_response.max()
        
        # Get corner coordinates
        corner_coords = np.where(harris_response > threshold)
        corners = list(zip(corner_coords[1], corner_coords[0]))  # (x, y) format
        
        # Limit number of corners
        if len(corners) > self.max_corners:
            # Sort by response strength and take top N
            responses = [harris_response[y, x] for x, y in corners]
            sorted_indices = np.argsort(responses)[::-1]
            corners = [corners[i] for i in sorted_indices[:self.max_corners]]
        
        return corners
    
    def detect_shi_tomasi_corners(self, frame):
        """
        Detect corners using Shi-Tomasi (Good Features to Track).
        
        Returns:
            corners: List of (x, y) corner coordinates
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Shi-Tomasi corner detection
        corners = cv2.goodFeaturesToTrack(
            gray,
            maxCorners=self.max_corners,
            qualityLevel=self.quality_level,
            minDistance=self.min_distance,
            blockSize=3
        )
        
        if corners is not None:
            # Convert to list of (x, y) tuples
            corners = [(int(x), int(y)) for [[x, y]] in corners]
        else:
            corners = []
        
        return corners
    
    def draw_corners(self, frame, corners, color=(0, 255, 255), label="Corners"):
        """
        Draw detected corners on frame.
        
        Args:
            frame: Image to draw on
            corners: List of (x, y) tuples
            color: BGR color for corners
            label: Label for this detection method
        """
        result = frame.copy()
        
        # Draw each corner
        for (x, y) in corners:
            cv2.circle(result, (int(x), int(y)), 3, color, -1)
            cv2.circle(result, (int(x), int(y)), 5, (255, 255, 255), 1)
        
        # Draw info
        info = {
            'Method': label,
            'Corners': len(corners),
            'Max': self.max_corners,
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        self.viz.draw_info_panel(result, info, position=(10, 30))
        
        return result
    
    def process_frame(self, frame):
        """
        Process frame based on current mode.
        
        Returns:
            result: Processed frame with corners drawn
        """
        if self.mode == "harris":
            corners = self.detect_harris_corners(frame)
            result = self.draw_corners(frame, corners, 
                                      color=(0, 255, 255), 
                                      label="Harris")
            
        elif self.mode == "shi-tomasi":
            corners = self.detect_shi_tomasi_corners(frame)
            result = self.draw_corners(frame, corners, 
                                      color=(255, 0, 255), 
                                      label="Shi-Tomasi")
            
        elif self.mode == "both":
            # Side-by-side comparison
            h, w = frame.shape[:2]
            result = np.zeros((h, w*2, 3), dtype=np.uint8)
            
            # Harris on left
            harris_corners = self.detect_harris_corners(frame)
            left = self.draw_corners(frame, harris_corners, 
                                    color=(0, 255, 255), 
                                    label="Harris")
            result[0:h, 0:w] = left
            
            # Shi-Tomasi on right
            st_corners = self.detect_shi_tomasi_corners(frame)
            right = self.draw_corners(frame, st_corners, 
                                     color=(255, 0, 255), 
                                     label="Shi-Tomasi")
            result[0:h, w:w*2] = right
            
        else:
            result = frame.copy()
        
        return result
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "1: Harris | 2: Shi-Tomasi | 3: Both",
            "+/-: Corners | S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run real-time corner detection."""
        print("\n" + "="*60)
        print("REAL-TIME CORNER DETECTION")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting corner detection...")
        print("\nTRY THESE:")
        print("  • Point at corners of books, monitors, picture frames")
        print("  • Try different textures - what has good corners?")
        print("  • Move closer/further - how does scale affect detection?")
        print("  • Compare Harris vs Shi-Tomasi methods")
        
        window_name = "Corner Detection"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Process frame
                result = self.process_frame(frame)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('1'):
                    self.mode = "harris"
                    print(f"Mode: {self.mode.upper()}")
                    
                elif key == ord('2'):
                    self.mode = "shi-tomasi"
                    print(f"Mode: {self.mode.upper()}")
                    
                elif key == ord('3'):
                    self.mode = "both"
                    print(f"Mode: COMPARISON")
                    
                elif key == ord('+') or key == ord('='):
                    self.max_corners = min(500, self.max_corners + 10)
                    print(f"Max corners: {self.max_corners}")
                    
                elif key == ord('-') or key == ord('_'):
                    self.max_corners = max(10, self.max_corners - 10)
                    print(f"Max corners: {self.max_corners}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"corners_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps.frame_count} frames")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("CORNER DETECTION")
    print("="*60)
    print("\nCorners are points where edges meet - they're stable")
    print("features that can be tracked and matched across images.")
    print("\nWHAT ARE CORNERS?")
    print("  • Points with high intensity variation in multiple directions")
    print("  • Stable under rotation and scale changes")
    print("  • Good for tracking and matching")
    print("\nTWO METHODS:")
    print("  1. Harris Corner Detector (1988)")
    print("     - Classic method using eigenvalues")
    print("     - Finds corners based on intensity changes")
    print("  2. Shi-Tomasi / Good Features to Track (1994)")
    print("     - Improved version of Harris")
    print("     - Better quality corner selection")
    print("\nCONTROLS:")
    print("  1 - Harris corner detection")
    print("  2 - Shi-Tomasi corner detection")
    print("  3 - Compare both methods side-by-side")
    print("  +/- - Adjust max number of corners")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    detector = CornerDetector()
    detector.run()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ Corners are distinctive, trackable features")
    print("✓ Harris: Classic, finds many corners")
    print("✓ Shi-Tomasi: Better quality selection")
    print("✓ Good corners have:")
    print("  • High contrast in multiple directions")
    print("  • Distinct local patterns")
    print("  • Stability under transformations")
    print("\nBAD CORNERS:")
    print("✗ On edges (only one direction of change)")
    print("✗ On flat regions (no change)")
    print("✗ On noisy or blurry areas")
    print("\nUSE CASES:")
    print("  • Object tracking")
    print("  • Camera pose estimation")
    print("  • 3D reconstruction")
    print("  • Image stabilization")
    print("\nNext: Try 07_sift_features.py for more advanced features")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
