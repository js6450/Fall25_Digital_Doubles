"""
04: Face Blur for Privacy
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Automatic face detection and blurring for privacy protection.
Demonstrates how to anonymize faces in images and video.

Concepts:
- Region of Interest (ROI) manipulation
- Gaussian blur for anonymization
- Pixelation as alternative
- Privacy-preserving video processing

Usage:
    python 04_face_blur_privacy.py

Controls (real-time mode):
    - 'b' - Toggle blur style (blur/pixelate/none)
    - 's' - Save anonymized frame
    - 'i' - Process static images
    - 'q' - Quit

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class FaceBlurPrivacy:
    """
    Anonymize faces in images and video for privacy protection.
    """
    
    def __init__(self):
        """Initialize face blur system."""
        # Load face detector (using Haar for speed)
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        
        # Blur settings
        self.blur_mode = "blur"  # "blur", "pixelate", or "none"
        self.blur_strength = 99  # Must be odd number
        self.pixelate_size = 10  # Pixel block size
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        print("Face Blur Privacy Tool initialized")
        print(f"Default mode: {self.blur_mode}")
    
    def detect_faces(self, image):
        """
        Detect faces in image.
        
        Returns:
            List of (x, y, w, h) tuples
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )
        return faces
    
    def blur_face(self, image, x, y, w, h):
        """
        Apply Gaussian blur to face region.
        
        Args:
            image: Image to modify (will be modified in place)
            x, y, w, h: Face bounding box
        """
        # Extract face ROI
        face_roi = image[y:y+h, x:x+w]
        
        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(face_roi, (self.blur_strength, self.blur_strength), 30)
        
        # Put blurred region back
        image[y:y+h, x:x+w] = blurred
        
        return image
    
    def pixelate_face(self, image, x, y, w, h):
        """
        Apply pixelation to face region.
        
        Args:
            image: Image to modify (will be modified in place)
            x, y, w, h: Face bounding box
        """
        # Extract face ROI
        face_roi = image[y:y+h, x:x+w]
        
        # Get dimensions
        roi_h, roi_w = face_roi.shape[:2]
        
        # Downscale
        small = cv2.resize(face_roi, 
                          (roi_w // self.pixelate_size, roi_h // self.pixelate_size),
                          interpolation=cv2.INTER_LINEAR)
        
        # Upscale back (creates pixelated effect)
        pixelated = cv2.resize(small, (roi_w, roi_h),
                              interpolation=cv2.INTER_NEAREST)
        
        # Put pixelated region back
        image[y:y+h, x:x+w] = pixelated
        
        return image
    
    def black_box_face(self, image, x, y, w, h):
        """
        Replace face with black box.
        
        Args:
            image: Image to modify (will be modified in place)
            x, y, w, h: Face bounding box
        """
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 0, 0), -1)
        return image
    
    def anonymize_faces(self, image, faces):
        """
        Anonymize all detected faces.
        
        Args:
            image: Image to anonymize
            faces: List of (x, y, w, h) tuples
        
        Returns:
            anonymized: Image with faces anonymized
        """
        # Make a copy to avoid modifying original
        result = image.copy()
        
        for (x, y, w, h) in faces:
            if self.blur_mode == "blur":
                result = self.blur_face(result, x, y, w, h)
            elif self.blur_mode == "pixelate":
                result = self.pixelate_face(result, x, y, w, h)
            # "none" mode shows original
        
        return result
    
    def draw_ui(self, frame, face_count):
        """Draw user interface."""
        # Info panel
        info = {
            'Faces': face_count,
            'Mode': self.blur_mode.upper(),
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        # Controls
        h = frame.shape[0]
        controls = "B: Blur mode | S: Save | I: Images | Q: Quit"
        
        (text_w, text_h), _ = cv2.getTextSize(
            controls, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
        )
        
        y_pos = h - 20
        cv2.rectangle(frame, (10, y_pos - text_h - 5),
                     (10 + text_w + 10, y_pos + 5),
                     (0, 0, 0), -1)
        cv2.putText(frame, controls, (15, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                   (255, 255, 255), 1)
        
        return frame
    
    def process_images(self):
        """Process static images from resources folder."""
        print("\n" + "="*60)
        print("PROCESSING STATIC IMAGES")
        print("="*60)
        
        resources_dir = Path(__file__).parent / "resources"
        image_files = sorted(resources_dir.glob("*.jpg"))
        
        if not image_files:
            print("No images found in resources folder")
            return
        
        print(f"Found {len(image_files)} images")
        print("\nProcessing with all blur modes...")
        
        for img_path in image_files:
            print(f"\n{img_path.name}:")
            
            # Load image
            image = cv2.imread(str(img_path))
            if image is None:
                print(f"  Error loading, skipping...")
                continue
            
            # Detect faces
            faces = self.detect_faces(image)
            print(f"  Detected {len(faces)} face(s)")
            
            if len(faces) == 0:
                print("  No faces detected, skipping...")
                continue
            
            # Show all blur modes side-by-side
            h, w = image.shape[:2]
            
            # Create comparison grid
            grid_width = w * 3
            grid = np.zeros((h, grid_width, 3), dtype=np.uint8)
            
            # Original
            grid[0:h, 0:w] = image
            cv2.putText(grid, "ORIGINAL", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # Blurred
            self.blur_mode = "blur"
            blurred = self.anonymize_faces(image, faces)
            grid[0:h, w:w*2] = blurred
            cv2.putText(grid, "BLUR", (w + 10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # Pixelated
            self.blur_mode = "pixelate"
            pixelated = self.anonymize_faces(image, faces)
            grid[0:h, w*2:w*3] = pixelated
            cv2.putText(grid, "PIXELATE", (w*2 + 10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # Display
            cv2.imshow(f"Privacy Modes - {img_path.name}", grid)
            
            key = cv2.waitKey(0)
            
            # Save if requested
            if key == ord('s'):
                output_name = f"anonymized_{img_path.name}"
                cv2.imwrite(output_name, grid)
                print(f"  ✓ Saved: {output_name}")
            
            cv2.destroyAllWindows()
            
            if key == ord('q'):
                break
        
        # Reset to default
        self.blur_mode = "blur"
    
    def run_realtime(self):
        """Run real-time face blurring on webcam."""
        print("\n" + "="*60)
        print("REAL-TIME FACE ANONYMIZATION")
        print("="*60)
        
        # Open webcam
        print("\nOpening webcam...")
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting anonymization...")
        print("Press 'q' to quit, 'b' to change blur mode\n")
        
        window_name = "Face Anonymization"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect faces
                faces = self.detect_faces(frame)
                
                # Anonymize faces
                if self.blur_mode != "none":
                    frame = self.anonymize_faces(frame, faces)
                
                # Draw UI
                self.draw_ui(frame, len(faces))
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, frame)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('b'):
                    # Cycle through blur modes
                    modes = ["blur", "pixelate", "none"]
                    current_idx = modes.index(self.blur_mode)
                    self.blur_mode = modes[(current_idx + 1) % len(modes)]
                    print(f"Blur mode: {self.blur_mode.upper()}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"anonymized_{timestamp}.jpg"
                    cv2.imwrite(filename, frame)
                    print(f"✓ Saved: {filename}")
                    
                elif key == ord('i'):
                    # Switch to image processing
                    cv2.destroyWindow(window_name)
                    self.process_images()
                    print("\nReturning to real-time mode...")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            print(f"\nProcessed {self.fps.frame_count} frames")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("FACE BLUR FOR PRIVACY")
    print("="*60)
    print("\nThis tool demonstrates privacy-preserving face anonymization.")
    print("\nBlur Methods:")
    print("  • Gaussian Blur - Smooth, natural-looking")
    print("  • Pixelation - Retro, video-game style")
    print("  • None - Original (for comparison)")
    print("\nUse Cases:")
    print("  • Privacy protection in public spaces")
    print("  • GDPR compliance in video footage")
    print("  • Consent-free documentation")
    print("  • Research data anonymization")
    print("\nControls:")
    print("  B - Cycle blur modes")
    print("  S - Save current frame")
    print("  I - Process static images")
    print("  Q - Quit")
    print("="*60)
    
    # Create privacy tool
    privacy = FaceBlurPrivacy()
    
    # Ask for mode
    print("\nChoose mode:")
    print("  1. Real-time webcam")
    print("  2. Process static images")
    choice = input("Enter choice (1 or 2): ").strip()
    
    if choice == "2":
        privacy.process_images()
    else:
        privacy.run_realtime()
    
    print("\n" + "="*60)
    print("ETHICAL CONSIDERATIONS:")
    print("="*60)
    print("⚠ Face blurring for privacy:")
    print("  ✓ Protects identity in public documentation")
    print("  ✓ Enables GDPR-compliant video recording")
    print("  ✓ Allows research without consent issues")
    print("  ✗ Not 100% foolproof (other identifying features remain)")
    print("  ✗ May fail to detect all faces (bias issues)")
    print("  ✗ Can be reversed with advanced techniques")
    print("\nBest Practices:")
    print("  • Always inform people they're being recorded")
    print("  • Provide opt-out mechanisms")
    print("  • Delete unblurred originals when possible")
    print("  • Test on diverse subjects")
    print("  • Consider additional privacy measures (blur hands, clothing, etc.)")
    print("\nNext: Try 05_face_comparison.py to compare Haar vs DNN")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
