"""
05: Face Detection Comparison - Haar vs DNN (Real-time)
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time side-by-side comparison of Haar Cascade and DNN face detection.
See both methods running simultaneously on your webcam to understand
the speed vs accuracy trade-offs.

Concepts:
- Performance benchmarking
- Real-time accuracy comparison
- Visual quality differences
- Speed vs accuracy trade-offs

Usage:
    python 05_face_comparison.py

Prerequisites:
    Run utils/model_downloader.py first to download DNN models

Controls:
    - 'b' - Run performance benchmark
    - 't' - Toggle time display
    - 's' - Save current frame
    - 'q' - Quit

What to observe:
    - Notice FPS difference between left (Haar) and right (DNN)
    - Try different angles - see which detects better
    - Move closer/further - test at various distances
    - Test with glasses, hats, different lighting

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
import time
from datetime import datetime
from collections import deque

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.detection_visualizer import DetectionVisualizer


class FaceDetectorComparison:
    """
    Real-time comparison of Haar Cascade and DNN face detection.
    """
    
    def __init__(self):
        """Initialize both detection methods."""
        self.viz = DetectionVisualizer()
        
        # Initialize Haar Cascade
        print("Loading Haar Cascade...")
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.haar_cascade = cv2.CascadeClassifier(cascade_path)
        print("✓ Haar Cascade loaded")
        
        # Initialize DNN
        print("Loading DNN model...")
        models_dir = Path(__file__).parent / "models" / "face_detection"
        prototxt = models_dir / "deploy.prototxt"
        model = models_dir / "res10_300x300_ssd_iter_140000.caffemodel"
        
        if not prototxt.exists() or not model.exists():
            raise FileNotFoundError(
                f"DNN model files not found!\n"
                f"Please run: python utils/model_downloader.py"
            )
        
        self.dnn_net = cv2.dnn.readNetFromCaffe(str(prototxt), str(model))
        print("✓ DNN model loaded")
        
        # Performance tracking
        self.haar_times = deque(maxlen=30)
        self.dnn_times = deque(maxlen=30)
        self.show_times = True
        
        # Statistics for benchmark
        self.benchmark_running = False
        self.benchmark_results = []
        
        print("\nBoth detectors initialized")
    
    def detect_haar(self, frame):
        """
        Detect faces using Haar Cascade.
        
        Returns:
            faces: List of (x, y, w, h) tuples
            time_taken: Processing time in seconds
        """
        start_time = time.time()
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.haar_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )
        
        time_taken = time.time() - start_time
        self.haar_times.append(time_taken)
        
        return list(faces), time_taken
    
    def detect_dnn(self, frame, confidence_threshold=0.5):
        """
        Detect faces using DNN.
        
        Returns:
            faces: List of (x, y, w, h, confidence) tuples
            time_taken: Processing time in seconds
        """
        start_time = time.time()
        
        h, w = frame.shape[:2]
        
        # Prepare blob
        blob = cv2.dnn.blobFromImage(
            frame, 1.0, (300, 300),
            (104.0, 177.0, 123.0),
            swapRB=False, crop=False
        )
        
        # Run inference
        self.dnn_net.setInput(blob)
        detections = self.dnn_net.forward()
        
        # Process detections
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > confidence_threshold:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                
                face_w = x2 - x
                face_h = y2 - y
                
                x = max(0, x)
                y = max(0, y)
                face_w = min(face_w, w - x)
                face_h = min(face_h, h - y)
                
                faces.append((x, y, face_w, face_h, float(confidence)))
        
        time_taken = time.time() - start_time
        self.dnn_times.append(time_taken)
        
        return faces, time_taken
    
    def draw_faces_haar(self, frame, faces, time_taken):
        """Draw Haar detection results."""
        result = frame.copy()
        
        # Draw each face
        for (x, y, w, h) in faces:
            self.viz.draw_face(result, x, y, w, h, confidence=None, label="Haar")
        
        # Title
        cv2.putText(result, "HAAR CASCADE", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        
        # Stats
        y_pos = 65
        cv2.putText(result, f"Faces: {len(faces)}", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        if self.show_times:
            y_pos += 30
            cv2.putText(result, f"Time: {time_taken*1000:.1f}ms", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            y_pos += 30
            avg_time = np.mean(self.haar_times) if self.haar_times else time_taken
            fps = 1.0 / avg_time if avg_time > 0 else 0
            cv2.putText(result, f"FPS: {fps:.1f}", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Characteristics
        y_pos = result.shape[0] - 80
        cv2.putText(result, "Fast & Lightweight", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        y_pos += 25
        cv2.putText(result, "Good for real-time", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        y_pos += 25
        cv2.putText(result, "May miss angled faces", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        
        return result
    
    def draw_faces_dnn(self, frame, faces, time_taken):
        """Draw DNN detection results."""
        result = frame.copy()
        
        # Draw each face
        for (x, y, w, h, conf) in faces:
            self.viz.draw_face(result, x, y, w, h, confidence=conf, label="DNN")
        
        # Title
        cv2.putText(result, "DNN (ResNet-SSD)", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 100, 255), 2)
        
        # Stats
        y_pos = 65
        cv2.putText(result, f"Faces: {len(faces)}", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        if self.show_times:
            y_pos += 30
            cv2.putText(result, f"Time: {time_taken*1000:.1f}ms", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            y_pos += 30
            avg_time = np.mean(self.dnn_times) if self.dnn_times else time_taken
            fps = 1.0 / avg_time if avg_time > 0 else 0
            cv2.putText(result, f"FPS: {fps:.1f}", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Characteristics
        y_pos = result.shape[0] - 80
        cv2.putText(result, "More Accurate", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 100, 255), 1)
        y_pos += 25
        cv2.putText(result, "Handles angles better", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 100, 255), 1)
        y_pos += 25
        cv2.putText(result, "Slower processing", (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 100, 255), 1)
        
        return result
    
    def create_comparison(self, frame):
        """
        Create side-by-side comparison.
        
        Returns:
            comparison: Combined image with both results
        """
        # Detect with both methods
        haar_faces, haar_time = self.detect_haar(frame)
        dnn_faces, dnn_time = self.detect_dnn(frame)
        
        # Draw results
        h, w = frame.shape[:2]
        
        left = self.draw_faces_haar(frame, haar_faces, haar_time)
        right = self.draw_faces_dnn(frame, dnn_faces, dnn_time)
        
        # Combine side-by-side
        comparison = np.zeros((h, w*2, 3), dtype=np.uint8)
        comparison[0:h, 0:w] = left
        comparison[0:h, w:w*2] = right
        
        # Draw dividing line
        cv2.line(comparison, (w, 0), (w, h), (255, 255, 255), 2)
        
        # Performance comparison at bottom
        if self.show_times and self.haar_times and self.dnn_times:
            avg_haar = np.mean(self.haar_times)
            avg_dnn = np.mean(self.dnn_times)
            speedup = avg_dnn / avg_haar if avg_haar > 0 else 0
            
            comparison_text = f"Haar is {speedup:.1f}x FASTER than DNN"
            text_size = cv2.getTextSize(comparison_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
            text_x = (w*2 - text_size[0]) // 2
            
            # Background
            cv2.rectangle(comparison, 
                         (text_x - 10, h - 40),
                         (text_x + text_size[0] + 10, h - 10),
                         (0, 0, 0), -1)
            
            # Text
            cv2.putText(comparison, comparison_text, (text_x, h - 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        return comparison
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "B: Benchmark | T: Toggle times | S: Save | Q: Quit"
        ]
        
        y_pos = h - 20
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2
            )
            
            # Center the text
            text_x = (frame.shape[1] - text_w) // 2
            
            # Background
            cv2.rectangle(frame, (text_x - 10, y_pos - text_h - 5),
                         (text_x + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            
            # Text
            cv2.putText(frame, text, (text_x, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                       (255, 255, 255), 2)
        
        return frame
    
    def run_benchmark(self, cap, num_frames=100):
        """
        Run performance benchmark.
        
        Args:
            cap: Video capture object
            num_frames: Number of frames to test
        """
        print("\n" + "="*60)
        print(f"RUNNING BENCHMARK ({num_frames} frames)...")
        print("="*60)
        
        haar_times = []
        dnn_times = []
        haar_detections = []
        dnn_detections = []
        
        for i in range(num_frames):
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.flip(frame, 1)
            
            # Haar
            haar_faces, haar_time = self.detect_haar(frame)
            haar_times.append(haar_time)
            haar_detections.append(len(haar_faces))
            
            # DNN
            dnn_faces, dnn_time = self.detect_dnn(frame)
            dnn_times.append(dnn_time)
            dnn_detections.append(len(dnn_faces))
            
            # Progress
            if (i + 1) % 20 == 0:
                print(f"  Progress: {i+1}/{num_frames}")
        
        # Calculate statistics
        print("\n" + "="*60)
        print("BENCHMARK RESULTS")
        print("="*60)
        
        print("\nHAAR CASCADE:")
        print(f"  Average time: {np.mean(haar_times)*1000:.2f} ± {np.std(haar_times)*1000:.2f} ms")
        print(f"  Average FPS:  {1/np.mean(haar_times):.1f}")
        print(f"  Avg faces detected: {np.mean(haar_detections):.1f}")
        
        print("\nDNN (ResNet-SSD):")
        print(f"  Average time: {np.mean(dnn_times)*1000:.2f} ± {np.std(dnn_times)*1000:.2f} ms")
        print(f"  Average FPS:  {1/np.mean(dnn_times):.1f}")
        print(f"  Avg faces detected: {np.mean(dnn_detections):.1f}")
        
        print("\nCOMPARISON:")
        speedup = np.mean(dnn_times) / np.mean(haar_times)
        print(f"  Haar is {speedup:.1f}x FASTER than DNN")
        print(f"  DNN is {1/speedup:.1f}x SLOWER than Haar")
        
        print("="*60)
        print("Press any key to continue...")
    
    def run(self):
        """Run real-time comparison."""
        print("\n" + "="*60)
        print("REAL-TIME FACE DETECTION COMPARISON")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting comparison...")
        print("\nOBSERVE:")
        print("  • FPS difference (Haar is faster)")
        print("  • Detection accuracy (DNN is better)")
        print("  • Try different angles and lighting")
        print("  • Test with accessories (glasses, hats)")
        print("  • Move closer/further from camera")
        
        window_name = "Face Detection Comparison"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Create comparison
                result = self.create_comparison(frame)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('t'):
                    self.show_times = not self.show_times
                    print(f"Time display: {'ON' if self.show_times else 'OFF'}")
                    
                elif key == ord('b'):
                    print("\nStarting benchmark...")
                    cv2.destroyWindow(window_name)
                    self.run_benchmark(cap, num_frames=100)
                    cv2.waitKey(0)
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"face_comparison_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()


def main():
    """
    Main function to compare face detection methods.
    """
    print("\n" + "="*60)
    print("FACE DETECTION COMPARISON: HAAR vs DNN")
    print("="*60)
    print("\nThis demo shows both methods running simultaneously")
    print("so you can directly compare their performance.")
    print("\nWHAT TO WATCH:")
    print("  • Left (Haar): Faster, but may miss angled faces")
    print("  • Right (DNN): Slower, but more accurate")
    print("  • FPS difference shows speed trade-off")
    print("  • Detection count may differ")
    print("\nTEST SCENARIOS:")
    print("  1. Face camera straight on")
    print("  2. Turn your head to the side")
    print("  3. Wear glasses or hat")
    print("  4. Change lighting (move closer to window)")
    print("  5. Move closer/further from camera")
    print("\nCONTROLS:")
    print("  B - Run 100-frame benchmark")
    print("  T - Toggle time/FPS display")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    try:
        # Initialize comparison
        comparator = FaceDetectorComparison()
        comparator.run()
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    print("\n" + "="*60)
    print("SUMMARY: WHEN TO USE EACH METHOD")
    print("="*60)
    
    print("\n📊 HAAR CASCADE:")
    print("  ✓ FAST - 30-60 FPS typical")
    print("  ✓ Lightweight - no model files needed")
    print("  ✓ Good for: Real-time applications, embedded systems")
    print("  ✗ Less accurate with angles, lighting, occlusion")
    print("  ✗ More false positives")
    
    print("\n🧠 DNN (ResNet-SSD):")
    print("  ✓ MORE ACCURATE - better with varied conditions")
    print("  ✓ Fewer false positives")
    print("  ✓ Better with angles, partial faces, accessories")
    print("  ✓ Good for: Pre-recorded video, accuracy-critical apps")
    print("  ✗ Slower - typically 15-25 FPS")
    print("  ✗ Requires model files (~2.5MB)")
    
    print("\n💡 RECOMMENDATIONS:")
    print("  • Real-time interactive installations → Haar")
    print("  • Archival video processing → DNN")
    print("  • Mobile/embedded devices → Haar")
    print("  • Critical accuracy needs → DNN")
    print("  • Varied lighting/angles → DNN")
    print("  • Need 30+ FPS → Haar")
    
    print("\n🎯 HYBRID APPROACH:")
    print("  Consider using BOTH:")
    print("  • Haar for initial fast detection")
    print("  • DNN for verification/refinement")
    print("  • Process every Nth frame with DNN")
    
    print("\n" + "="*60)
    print("This completes the face detection examples!")
    print("Next: Try feature detection (06-09) or object detection (10-13)")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
