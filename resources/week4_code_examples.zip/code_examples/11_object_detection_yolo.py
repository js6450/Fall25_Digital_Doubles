"""
11: Object Detection with YOLO
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time object detection using YOLO (You Only Look Once).
YOLO detects 80+ COCO classes and is one of the fastest
real-time object detection algorithms!

Concepts:
- YOLO algorithm and architecture
- 80-class COCO dataset
- Non-Maximum Suppression (NMS)
- Real-time multi-object detection
- Comparing YOLO with other detectors

Usage:
    python 11_object_detection_yolo.py

Prerequisites:
    Run: python utils/model_downloader.py --with-yolo
    Note: YOLO models are large files (~240MB for YOLOv3)

Controls:
    - '+' / '-' - Adjust confidence threshold
    - 'n' - Adjust NMS threshold
    - 'f' - Toggle class filter
    - 'l' - Toggle label display
    - 'c' - Toggle class list
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Point at various objects in your room
    - YOLO detects 80+ classes!
    - Try multiple objects at once
    - Compare detection with MobileNet-SSD

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class YOLOObjectDetector:
    """
    Real-time object detection using YOLO.
    """
    
    def __init__(self):
        """Initialize YOLO detector."""
        models_dir = Path(__file__).parent / "models" / "object_detection"
        
        # Try YOLOv4-tiny first (faster), fall back to YOLOv3
        configs = [
            ("yolov4-tiny.cfg", "yolov4-tiny.weights", "YOLOv4-tiny"),
            ("yolov3.cfg", "yolov3.weights", "YOLOv3")
        ]
        
        self.net = None
        self.model_name = None
        
        for cfg_name, weights_name, model_name in configs:
            cfg_path = models_dir / cfg_name
            weights_path = models_dir / weights_name
            
            if cfg_path.exists() and weights_path.exists():
                print(f"Loading {model_name}...")
                try:
                    self.net = cv2.dnn.readNetFromDarknet(str(cfg_path), str(weights_path))
                    self.model_name = model_name
                    print(f"✓ {model_name} loaded")
                    break
                except Exception as e:
                    print(f"✗ Failed to load {model_name}: {e}")
                    continue
        
        if self.net is None:
            raise FileNotFoundError(
                "YOLO model files not found!\n"
                "Please run: python utils/model_downloader.py --with-yolo\n"
                "Note: YOLO models are large (23-240MB depending on version)"
            )
        
        # Load COCO class labels
        classes_path = models_dir / "coco.names"
        if not classes_path.exists():
            raise FileNotFoundError(f"COCO class names not found: {classes_path}")
        
        with open(classes_path, 'r') as f:
            self.classes = [line.strip() for line in f.readlines()]
        
        print(f"Classes loaded: {len(self.classes)}")
        
        # Get output layer names
        layer_names = self.net.getLayerNames()
        self.output_layers = [layer_names[i - 1] for i in self.net.getUnconnectedOutLayers()]
        
        # Detection parameters
        self.confidence_threshold = 0.5
        self.nms_threshold = 0.4  # Non-maximum suppression
        self.filter_mode = False
        self.filter_classes = ["person", "laptop", "cell phone", "cup", "bottle", 
                              "book", "chair", "keyboard", "mouse"]
        self.show_labels = True
        self.show_class_list = False
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        # Colors for each class
        np.random.seed(42)
        self.colors = np.random.uniform(0, 255, size=(len(self.classes), 3))
        
        print(f"Confidence threshold: {self.confidence_threshold}")
        print(f"NMS threshold: {self.nms_threshold}")
    
    def detect_objects(self, frame):
        """
        Detect objects using YOLO.
        
        Returns:
            detections: List of (class_name, confidence, x, y, w, h) tuples
        """
        h, w = frame.shape[:2]
        
        # Create blob from image
        # YOLO expects 416x416 or 608x608 input (using 416 for speed)
        blob = cv2.dnn.blobFromImage(
            frame,
            scalefactor=1/255.0,
            size=(416, 416),
            swapRB=True,
            crop=False
        )
        
        # Run detection
        self.net.setInput(blob)
        outputs = self.net.forward(self.output_layers)
        
        # Process outputs
        class_ids = []
        confidences = []
        boxes = []
        
        for output in outputs:
            for detection in output:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                
                if confidence > self.confidence_threshold:
                    # YOLO returns center_x, center_y, width, height (normalized)
                    center_x = int(detection[0] * w)
                    center_y = int(detection[1] * h)
                    box_w = int(detection[2] * w)
                    box_h = int(detection[3] * h)
                    
                    # Convert to top-left corner
                    x = int(center_x - box_w / 2)
                    y = int(center_y - box_h / 2)
                    
                    class_ids.append(class_id)
                    confidences.append(float(confidence))
                    boxes.append([x, y, box_w, box_h])
        
        # Apply Non-Maximum Suppression
        indices = cv2.dnn.NMSBoxes(
            boxes, confidences,
            self.confidence_threshold,
            self.nms_threshold
        )
        
        # Format results
        results = []
        if len(indices) > 0:
            for i in indices.flatten():
                class_id = class_ids[i]
                class_name = self.classes[class_id]
                confidence = confidences[i]
                x, y, box_w, box_h = boxes[i]
                
                # Apply filter if enabled
                if self.filter_mode and class_name not in self.filter_classes:
                    continue
                
                # Clip to frame bounds
                x = max(0, x)
                y = max(0, y)
                box_w = min(box_w, w - x)
                box_h = min(box_h, h - y)
                
                results.append((class_name, confidence, x, y, box_w, box_h))
        
        return results
    
    def draw_detections(self, frame, detections):
        """Draw detection results."""
        result = frame.copy()
        
        for class_name, confidence, x, y, w, h in detections:
            # Get color for this class
            class_id = self.classes.index(class_name)
            color = tuple(map(int, self.colors[class_id]))
            
            # Draw using visualizer
            if self.show_labels:
                self.viz.draw_object(result, x, y, w, h, class_name, confidence, color)
            else:
                cv2.rectangle(result, (x, y), (x+w, y+h), color, 2)
        
        return result
    
    def draw_info(self, frame, detections):
        """Draw information panel."""
        # Count objects by class
        class_counts = {}
        for class_name, _, _, _, _, _ in detections:
            class_counts[class_name] = class_counts.get(class_name, 0) + 1
        
        # Info panel
        info = {
            'Model': self.model_name,
            'Objects': len(detections),
            'Conf': f"{self.confidence_threshold:.2f}",
            'NMS': f"{self.nms_threshold:.2f}",
            'Filter': 'ON' if self.filter_mode else 'OFF',
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        # Class counts (show top 5)
        if class_counts:
            y_pos = 200
            cv2.putText(frame, "Detected:", (10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            y_pos += 25
            
            # Sort by count
            sorted_classes = sorted(class_counts.items(), key=lambda x: x[1], reverse=True)
            
            for class_name, count in sorted_classes[:5]:  # Top 5
                text = f"  {class_name}: {count}"
                cv2.putText(frame, text, (10, y_pos),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
                y_pos += 20
        
        return frame
    
    def draw_class_list(self, frame):
        """Draw available classes list (scrollable)."""
        h, w = frame.shape[:2]
        
        # Create semi-transparent overlay
        overlay = frame.copy()
        overlay_width = 200
        cv2.rectangle(overlay, (w - overlay_width, 0), (w, h), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Title
        cv2.putText(frame, f"Classes ({len(self.classes)}):", 
                   (w - overlay_width + 10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # List first 30 classes
        y_pos = 60
        for i, class_name in enumerate(self.classes[:30], 1):
            color = (0, 255, 0) if class_name in self.filter_classes else (255, 255, 255)
            text = f"{class_name}"
            cv2.putText(frame, text, (w - overlay_width + 10, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.35, color, 1)
            y_pos += 18
            if y_pos > h - 40:
                cv2.putText(frame, "...and more", (w - overlay_width + 10, y_pos),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.35, (128, 128, 128), 1)
                break
        
        return frame
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "+/-: Conf | N: NMS | F: Filter | L: Labels | C: Classes",
            "S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run real-time YOLO detection."""
        print("\n" + "="*60)
        print(f"REAL-TIME OBJECT DETECTION - {self.model_name}")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting detection...")
        print(f"\nYOLO can detect {len(self.classes)} different classes!")
        print("\nCOMMON OBJECTS TO TRY:")
        print("  • person, laptop, cell phone, keyboard, mouse")
        print("  • cup, bottle, book, chair, backpack")
        print("  • And 70+ more classes!")
        print("\nPress 'c' to see all classes")
        
        window_name = f"YOLO Object Detection - {self.model_name}"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect objects
                detections = self.detect_objects(frame)
                
                # Draw results
                result = self.draw_detections(frame, detections)
                result = self.draw_info(result, detections)
                
                # Show class list if enabled
                if self.show_class_list:
                    result = self.draw_class_list(result)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('+') or key == ord('='):
                    self.confidence_threshold = min(0.95, self.confidence_threshold + 0.05)
                    print(f"Confidence threshold: {self.confidence_threshold:.2f}")
                    
                elif key == ord('-') or key == ord('_'):
                    self.confidence_threshold = max(0.1, self.confidence_threshold - 0.05)
                    print(f"Confidence threshold: {self.confidence_threshold:.2f}")
                    
                elif key == ord('n'):
                    self.nms_threshold = min(0.9, self.nms_threshold + 0.1)
                    print(f"NMS threshold: {self.nms_threshold:.2f}")
                    
                elif key == ord('f'):
                    self.filter_mode = not self.filter_mode
                    print(f"Filter mode: {'ON' if self.filter_mode else 'OFF'}")
                    
                elif key == ord('l'):
                    self.show_labels = not self.show_labels
                    print(f"Labels: {'ON' if self.show_labels else 'OFF'}")
                    
                elif key == ord('c'):
                    self.show_class_list = not self.show_class_list
                    print(f"Class list: {'ON' if self.show_class_list else 'OFF'}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"yolo_detection_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps.frame_count} frames")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("YOLO: YOU ONLY LOOK ONCE")
    print("="*60)
    print("\nYOLO is one of the fastest real-time object detection")
    print("algorithms, processing images in a single forward pass.")
    print("\nWHAT IS YOLO?")
    print("  • Single-pass detection (very fast)")
    print("  • Detects 80 classes from COCO dataset")
    print("  • Multiple versions (v3, v4, v5, v8)")
    print("  • Excellent for real-time applications")
    print("\nHOW YOLO WORKS:")
    print("  1. Divides image into grid")
    print("  2. Each cell predicts bounding boxes")
    print("  3. Uses NMS to remove duplicates")
    print("  4. All in one network pass!")
    print("\nCOCO CLASSES (80 total):")
    print("  • People & animals")
    print("  • Vehicles")
    print("  • Indoor objects (furniture, electronics)")
    print("  • Food & kitchen items")
    print("  • Sports equipment")
    print("  • And much more!")
    print("\nCONTROLS:")
    print("  +/- - Adjust confidence threshold")
    print("  N - Adjust NMS threshold")
    print("  F - Toggle filter mode")
    print("  L - Toggle label display")
    print("  C - Show/hide class list")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    try:
        detector = YOLOObjectDetector()
        detector.run()
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ YOLO is FAST - single-pass detection")
    print("✓ Detects 80 COCO classes (vs 20 for MobileNet)")
    print("✓ Excellent real-time performance")
    print("✓ NMS removes duplicate detections")
    print("\n📊 YOLO VERSIONS:")
    print("  • YOLOv3: ~240MB, very accurate")
    print("  • YOLOv4-tiny: ~23MB, faster, less accurate")
    print("  • YOLOv5/v8: Even faster (PyTorch)")
    print("\n🎯 WHEN TO USE:")
    print("  • Need many object classes (80+)")
    print("  • Real-time applications")
    print("  • When speed AND accuracy both matter")
    print("  • Multiple object detection")
    print("\n💡 NMS (Non-Maximum Suppression):")
    print("  • Removes overlapping duplicate boxes")
    print("  • Lower NMS threshold = fewer boxes kept")
    print("  • Higher NMS threshold = more boxes kept")
    print("  • Typical value: 0.4")
    print("\nNext: Try 12_realtime_object_detection.py to compare methods")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
