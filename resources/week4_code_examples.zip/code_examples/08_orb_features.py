"""
08: ORB Feature Detection
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Real-time ORB (Oriented FAST and Rotated BRIEF) feature detection.
ORB is a fast, free alternative to SIFT - better for real-time applications.

Concepts:
- ORB algorithm (FAST + BRIEF)
- Real-time feature detection
- Binary descriptors
- Comparison with SIFT

Usage:
    python 08_orb_features.py

Controls:
    - 'c' - Toggle comparison mode (ORB vs SIFT)
    - 'k' - Toggle keypoint visualization style
    - '+' - Increase feature count
    - '-' - Decrease feature count
    - 's' - Save current frame
    - 'q' - Quit

What to try:
    - Compare ORB vs SIFT performance (FPS)
    - Test on same objects as SIFT
    - Notice speed difference in real-time

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class ORBFeatureDetector:
    """
    Real-time ORB feature detection with SIFT comparison.
    """
    
    def __init__(self):
        """Initialize ORB detector."""
        # Initialize ORB
        self.orb = cv2.ORB_create()
        print("✓ ORB detector initialized")
        
        # Try to initialize SIFT for comparison
        self.sift = None
        try:
            self.sift = cv2.SIFT_create()
            print("✓ SIFT available for comparison")
        except AttributeError:
            print("⚠ SIFT not available (install opencv-contrib-python)")
        
        # Detection parameters
        self.max_features = 100
        
        # Visualization settings
        self.comparison_mode = False  # Compare ORB vs SIFT
        self.draw_style = "rich"  # "rich", "simple", "circles"
        
        # Utilities
        self.fps_orb = FPSCalculator()
        self.fps_sift = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        print(f"Max features: {self.max_features}")
    
    def detect_orb_features(self, frame):
        """
        Detect ORB features.
        
        Returns:
            keypoints: List of cv2.KeyPoint objects
            descriptors: Binary descriptors
            time_taken: Processing time
        """
        import time
        start = time.time()
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Set ORB parameters
        self.orb.setMaxFeatures(self.max_features)
        
        # Detect and compute
        keypoints, descriptors = self.orb.detectAndCompute(gray, None)
        
        time_taken = time.time() - start
        
        return keypoints, descriptors, time_taken
    
    def detect_sift_features(self, frame):
        """
        Detect SIFT features for comparison.
        
        Returns:
            keypoints: List of cv2.KeyPoint objects
            descriptors: SIFT descriptors
            time_taken: Processing time
        """
        import time
        start = time.time()
        
        if self.sift is None:
            return [], None, 0
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        keypoints, descriptors = self.sift.detectAndCompute(gray, None)
        
        # Limit to max features
        if len(keypoints) > self.max_features:
            keypoints = sorted(keypoints, key=lambda x: x.response, reverse=True)
            keypoints = keypoints[:self.max_features]
            if descriptors is not None:
                descriptors = descriptors[:self.max_features]
        
        time_taken = time.time() - start
        
        return keypoints, descriptors, time_taken
    
    def draw_keypoints_simple(self, frame, keypoints):
        """Draw keypoints as simple circles."""
        result = frame.copy()
        
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            cv2.circle(result, (x, y), 3, (0, 255, 0), -1)
            cv2.circle(result, (x, y), 5, (255, 255, 255), 1)
        
        return result
    
    def draw_keypoints_rich(self, frame, keypoints, color=(0, 255, 0)):
        """Draw keypoints with orientation."""
        result = frame.copy()
        
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            size = int(kp.size)
            angle = kp.angle
            
            # Draw circle
            cv2.circle(result, (x, y), size, color, 2)
            
            # Draw orientation line
            if angle >= 0:
                angle_rad = angle * np.pi / 180.0
                end_x = int(x + size * np.cos(angle_rad))
                end_y = int(y + size * np.sin(angle_rad))
                cv2.line(result, (x, y), (end_x, end_y), color, 2)
            
            # Center point
            cv2.circle(result, (x, y), 2, (255, 255, 255), -1)
        
        return result
    
    def draw_features(self, frame, keypoints, color=(0, 255, 0)):
        """Draw keypoints based on current style."""
        if self.draw_style == "simple":
            return self.draw_keypoints_simple(frame, keypoints)
        elif self.draw_style == "rich":
            return self.draw_keypoints_rich(frame, keypoints, color)
        else:
            return cv2.drawKeypoints(frame, keypoints, None, color=color,
                                    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    
    def create_comparison(self, frame):
        """Create side-by-side comparison of ORB vs SIFT."""
        h, w = frame.shape[:2]
        comparison = np.zeros((h, w*2, 3), dtype=np.uint8)
        
        # ORB on left
        orb_kp, orb_desc, orb_time = self.detect_orb_features(frame)
        left = self.draw_features(frame, orb_kp, color=(0, 255, 0))
        
        # Info
        cv2.putText(left, "ORB (FAST)", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(left, f"Features: {len(orb_kp)}", (10, 65),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(left, f"Time: {orb_time*1000:.1f}ms", (10, 95),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(left, f"FPS: {1/orb_time:.1f}" if orb_time > 0 else "FPS: -", 
                   (10, 125),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        comparison[0:h, 0:w] = left
        
        # SIFT on right (if available)
        if self.sift is not None:
            sift_kp, sift_desc, sift_time = self.detect_sift_features(frame)
            right = self.draw_features(frame, sift_kp, color=(255, 0, 255))
            
            # Info
            cv2.putText(right, "SIFT", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 255), 2)
            cv2.putText(right, f"Features: {len(sift_kp)}", (10, 65),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(right, f"Time: {sift_time*1000:.1f}ms", (10, 95),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(right, f"FPS: {1/sift_time:.1f}" if sift_time > 0 else "FPS: -",
                       (10, 125),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Speedup
            if sift_time > 0 and orb_time > 0:
                speedup = sift_time / orb_time
                cv2.putText(right, f"ORB is {speedup:.1f}x faster", 
                           (10, h - 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            comparison[0:h, w:w*2] = right
        else:
            # SIFT not available
            cv2.putText(comparison, "SIFT not available", (w + 10, h//2),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            cv2.putText(comparison, "Install opencv-contrib-python", (w + 10, h//2 + 40),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        return comparison
    
    def draw_info(self, frame, keypoints, time_taken):
        """Draw information panel."""
        info = {
            'Features': len(keypoints),
            'Max': self.max_features,
            'Time': f"{time_taken*1000:.1f}ms",
            'FPS': f"{self.fps_orb.get_fps():.1f}"
        }
        
        self.viz.draw_info_panel(frame, info, position=(10, 30))
        
        return frame
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "C: Compare ORB/SIFT | K: Style | +/-: Count",
            "S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run real-time ORB detection."""
        print("\n" + "="*60)
        print("REAL-TIME ORB FEATURE DETECTION")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nStarting ORB detection...")
        print("\nWATCH THE FPS:")
        print("  • ORB is typically 2-3x faster than SIFT")
        print("  • Better for real-time applications")
        print("  • Press 'c' to compare side-by-side")
        
        window_name = "ORB Feature Detection"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                if self.comparison_mode and self.sift is not None:
                    # Show comparison
                    result = self.create_comparison(frame)
                else:
                    # Just ORB
                    keypoints, descriptors, time_taken = self.detect_orb_features(frame)
                    result = self.draw_features(frame, keypoints)
                    result = self.draw_info(result, keypoints, time_taken)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps_orb.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('c'):
                    if self.sift is not None:
                        self.comparison_mode = not self.comparison_mode
                        print(f"Comparison mode: {'ON' if self.comparison_mode else 'OFF'}")
                    else:
                        print("SIFT not available for comparison")
                    
                elif key == ord('k'):
                    styles = ["simple", "rich"]
                    current = styles.index(self.draw_style) if self.draw_style in styles else 0
                    self.draw_style = styles[(current + 1) % len(styles)]
                    print(f"Draw style: {self.draw_style.upper()}")
                    
                elif key == ord('+') or key == ord('='):
                    self.max_features = min(500, self.max_features + 20)
                    print(f"Max features: {self.max_features}")
                    
                elif key == ord('-') or key == ord('_'):
                    self.max_features = max(20, self.max_features - 20)
                    print(f"Max features: {self.max_features}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"orb_features_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps_orb.frame_count} frames")
            print(f"Average FPS: {self.fps_orb.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("ORB: ORIENTED FAST AND ROTATED BRIEF")
    print("="*60)
    print("\nORB is a fast, free alternative to SIFT designed for")
    print("real-time applications.")
    print("\nWHAT IS ORB?")
    print("  • Combines FAST keypoint detector")
    print("  • With BRIEF descriptor")
    print("  • Adds orientation for rotation invariance")
    print("  • Binary descriptors (faster matching)")
    print("\nORB vs SIFT:")
    print("  ✓ 2-3x FASTER")
    print("  ✓ Always free (no patent)")
    print("  ✓ Binary descriptors (efficient)")
    print("  ✗ Slightly less accurate than SIFT")
    print("  ✗ Not scale-invariant (but good enough)")
    print("\nCONTROLS:")
    print("  C - Compare ORB vs SIFT side-by-side")
    print("  K - Change visualization style")
    print("  +/- - Adjust max feature count")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    detector = ORBFeatureDetector()
    detector.run()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ ORB is FAST - great for real-time")
    print("✓ Binary descriptors = efficient matching")
    print("✓ Good enough accuracy for most tasks")
    print("✓ Free and open-source")
    print("\n📊 PERFORMANCE:")
    print("  • ORB: 30-60 FPS typical")
    print("  • SIFT: 10-20 FPS typical")
    print("  • 2-3x speedup with ORB")
    print("\n🎯 WHEN TO USE:")
    print("  • ORB: Real-time applications, embedded systems")
    print("  • SIFT: Offline processing, need max accuracy")
    print("\n💡 DESCRIPTOR COMPARISON:")
    print("  • SIFT: 128-dimensional float vector")
    print("  • ORB: 256-bit binary descriptor")
    print("  • Binary = faster to compute and match")
    print("\nUSE CASES:")
    print("  • Real-time object tracking")
    print("  • Mobile AR applications")
    print("  • Visual SLAM")
    print("  • Video stabilization")
    print("\nNext: Try 09_feature_matching.py for object recognition")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
