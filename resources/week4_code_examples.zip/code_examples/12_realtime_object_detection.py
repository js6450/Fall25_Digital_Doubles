"""
12: Real-time Object Detection Comparison
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Compare MobileNet-SSD and YOLO side-by-side or switch between them
in real-time to understand their performance differences.

Concepts:
- Comparing different object detectors
- Performance vs accuracy trade-offs
- Model selection for different use cases
- Real-time detection optimization

Usage:
    python 12_realtime_object_detection.py

Prerequisites:
    Run: python utils/model_downloader.py
    Optional: --with-yolo for YOLO comparison

Controls:
    - '1' - MobileNet-SSD mode
    - '2' - YOLO mode  
    - '3' - Side-by-side comparison
    - '+' / '-' - Adjust confidence threshold
    - 'f' - Toggle class filter
    - 's' - Save current frame
    - 'q' - Quit

What to observe:
    - FPS differences between methods
    - Detection accuracy differences
    - Number of classes detected
    - Which works better for your use case

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime
from collections import deque

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class ObjectDetectionComparison:
    """
    Compare MobileNet-SSD and YOLO object detection.
    """
    
    def __init__(self):
        """Initialize both detectors."""
        self.viz = DetectionVisualizer()
        models_dir = Path(__file__).parent / "models" / "object_detection"
        
        # Load MobileNet-SSD
        print("Loading MobileNet-SSD...")
        mobilenet_proto = models_dir / "MobileNetSSD_deploy.prototxt"
        mobilenet_model = models_dir / "MobileNetSSD_deploy.caffemodel"
        
        if not mobilenet_proto.exists() or not mobilenet_model.exists():
            raise FileNotFoundError(
                "MobileNet-SSD files not found!\n"
                "Run: python utils/model_downloader.py"
            )
        
        self.mobilenet_net = cv2.dnn.readNetFromCaffe(
            str(mobilenet_proto), str(mobilenet_model)
        )
        self.mobilenet_classes = [
            "background", "aeroplane", "bicycle", "bird", "boat",
            "bottle", "bus", "car", "cat", "chair", "cow",
            "diningtable", "dog", "horse", "motorbike", "person",
            "pottedplant", "sheep", "sofa", "train", "tvmonitor"
        ]
        print("✓ MobileNet-SSD loaded")
        
        # Try to load YOLO
        self.yolo_net = None
        self.yolo_classes = []
        self.yolo_output_layers = []
        
        for cfg_name, weights_name in [("yolov4-tiny.cfg", "yolov4-tiny.weights"),
                                        ("yolov3.cfg", "yolov3.weights")]:
            cfg_path = models_dir / cfg_name
            weights_path = models_dir / weights_name
            
            if cfg_path.exists() and weights_path.exists():
                print(f"Loading YOLO ({cfg_name})...")
                try:
                    self.yolo_net = cv2.dnn.readNetFromDarknet(str(cfg_path), str(weights_path))
                    
                    # Load COCO classes
                    classes_path = models_dir / "coco.names"
                    with open(classes_path, 'r') as f:
                        self.yolo_classes = [line.strip() for line in f.readlines()]
                    
                    # Get output layers
                    layer_names = self.yolo_net.getLayerNames()
                    self.yolo_output_layers = [layer_names[i - 1] 
                                               for i in self.yolo_net.getUnconnectedOutLayers()]
                    
                    print(f"✓ YOLO loaded ({cfg_name})")
                    break
                except Exception as e:
                    print(f"✗ Failed to load YOLO: {e}")
                    continue
        
        if self.yolo_net is None:
            print("⚠ YOLO not available")
            print("  Run: python utils/model_downloader.py --with-yolo")
            print("  Will only use MobileNet-SSD")
        
        # Settings
        self.mode = "mobilenet"  # "mobilenet", "yolo", or "both"
        self.confidence_threshold = 0.5
        self.nms_threshold = 0.4
        self.filter_mode = False
        self.filter_classes = ["person", "laptop", "cell phone", "cup", "bottle"]
        
        # FPS trackers
        self.mobilenet_fps = FPSCalculator()
        self.yolo_fps = FPSCalculator()
        
        # Performance tracking
        self.mobilenet_times = deque(maxlen=30)
        self.yolo_times = deque(maxlen=30)
        
        print("\nDetection Comparison initialized")
        print(f"Mode: {self.mode.upper()}")
    
    def detect_mobilenet(self, frame):
        """Detect using MobileNet-SSD."""
        import time
        start = time.time()
        
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 0.007843, (300, 300), (127.5, 127.5, 127.5))
        
        self.mobilenet_net.setInput(blob)
        detections = self.mobilenet_net.forward()
        
        results = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.confidence_threshold:
                class_id = int(detections[0, 0, i, 1])
                if class_id >= len(self.mobilenet_classes):
                    continue
                
                class_name = self.mobilenet_classes[class_id]
                if class_name == "background":
                    continue
                
                if self.filter_mode and class_name not in self.filter_classes:
                    continue
                
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                box_w, box_h = x2 - x, y2 - y
                
                x, y = max(0, x), max(0, y)
                box_w = min(box_w, w - x)
                box_h = min(box_h, h - y)
                
                results.append((class_name, float(confidence), x, y, box_w, box_h))
        
        time_taken = time.time() - start
        self.mobilenet_times.append(time_taken)
        
        return results, time_taken
    
    def detect_yolo(self, frame):
        """Detect using YOLO."""
        if self.yolo_net is None:
            return [], 0
        
        import time
        start = time.time()
        
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
        
        self.yolo_net.setInput(blob)
        outputs = self.yolo_net.forward(self.yolo_output_layers)
        
        class_ids, confidences, boxes = [], [], []
        
        for output in outputs:
            for detection in output:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                
                if confidence > self.confidence_threshold:
                    center_x = int(detection[0] * w)
                    center_y = int(detection[1] * h)
                    box_w = int(detection[2] * w)
                    box_h = int(detection[3] * h)
                    
                    x = int(center_x - box_w / 2)
                    y = int(center_y - box_h / 2)
                    
                    class_ids.append(class_id)
                    confidences.append(float(confidence))
                    boxes.append([x, y, box_w, box_h])
        
        indices = cv2.dnn.NMSBoxes(boxes, confidences, 
                                   self.confidence_threshold, self.nms_threshold)
        
        results = []
        if len(indices) > 0:
            for i in indices.flatten():
                class_name = self.yolo_classes[class_ids[i]]
                confidence = confidences[i]
                x, y, box_w, box_h = boxes[i]
                
                if self.filter_mode and class_name not in self.filter_classes:
                    continue
                
                x, y = max(0, x), max(0, y)
                box_w = min(box_w, w - x)
                box_h = min(box_h, h - y)
                
                results.append((class_name, confidence, x, y, box_w, box_h))
        
        time_taken = time.time() - start
        self.yolo_times.append(time_taken)
        
        return results, time_taken
    
    def draw_detections(self, frame, detections, title, time_taken, fps_tracker):
        """Draw detections with info."""
        result = frame.copy()
        
        # Draw boxes
        for class_name, conf, x, y, w, h in detections:
            self.viz.draw_object(result, x, y, w, h, class_name, conf)
        
        # Title
        cv2.putText(result, title, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        
        # Stats
        cv2.putText(result, f"Objects: {len(detections)}", (10, 65),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(result, f"Time: {time_taken*1000:.1f}ms", (10, 95),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        avg_fps = fps_tracker.get_fps()
        cv2.putText(result, f"FPS: {avg_fps:.1f}", (10, 125),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        return result
    
    def create_comparison(self, frame):
        """Create side-by-side comparison."""
        h, w = frame.shape[:2]
        
        # Detect with both
        mob_det, mob_time = self.detect_mobilenet(frame)
        yolo_det, yolo_time = self.detect_yolo(frame)
        
        # Draw results
        left = self.draw_detections(frame, mob_det, "MobileNet-SSD", 
                                    mob_time, self.mobilenet_fps)
        
        if self.yolo_net is not None:
            right = self.draw_detections(frame, yolo_det, "YOLO", 
                                        yolo_time, self.yolo_fps)
        else:
            right = frame.copy()
            cv2.putText(right, "YOLO not available", (10, h//2),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        
        # Combine
        comparison = np.zeros((h, w*2, 3), dtype=np.uint8)
        comparison[0:h, 0:w] = left
        comparison[0:h, w:w*2] = right
        
        # Divider
        cv2.line(comparison, (w, 0), (w, h), (255, 255, 255), 2)
        
        # Speed comparison
        if self.yolo_net and self.mobilenet_times and self.yolo_times:
            avg_mob = np.mean(self.mobilenet_times)
            avg_yolo = np.mean(self.yolo_times)
            if avg_mob > 0:
                speedup = avg_yolo / avg_mob
                text = f"MobileNet is {speedup:.1f}x faster" if speedup > 1 else f"YOLO is {1/speedup:.1f}x faster"
                cv2.putText(comparison, text, (w - 200, h - 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        return comparison
    
    def draw_ui(self, frame):
        """Draw UI controls."""
        h = frame.shape[0]
        
        controls = [
            "1: MobileNet | 2: YOLO | 3: Compare | F: Filter",
            "+/-: Threshold | S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            y_pos += 25
        
        return frame
    
    def run(self):
        """Run comparison."""
        print("\n" + "="*60)
        print("OBJECT DETECTION COMPARISON")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nControls:")
        print("  1 - MobileNet-SSD (20 classes, fast)")
        print("  2 - YOLO (80 classes, slower but accurate)")
        print("  3 - Side-by-side comparison")
        
        window_name = "Object Detection Comparison"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                frame = cv2.flip(frame, 1)
                
                if self.mode == "both" and self.yolo_net:
                    result = self.create_comparison(frame)
                elif self.mode == "mobilenet":
                    detections, time_taken = self.detect_mobilenet(frame)
                    result = self.draw_detections(frame, detections, "MobileNet-SSD",
                                                 time_taken, self.mobilenet_fps)
                    self.mobilenet_fps.update()
                elif self.mode == "yolo" and self.yolo_net:
                    detections, time_taken = self.detect_yolo(frame)
                    result = self.draw_detections(frame, detections, "YOLO",
                                                 time_taken, self.yolo_fps)
                    self.yolo_fps.update()
                else:
                    result = frame
                
                result = self.draw_ui(result)
                cv2.imshow(window_name, result)
                
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                elif key == ord('1'):
                    self.mode = "mobilenet"
                    print("Mode: MobileNet-SSD")
                elif key == ord('2'):
                    if self.yolo_net:
                        self.mode = "yolo"
                        print("Mode: YOLO")
                    else:
                        print("YOLO not available")
                elif key == ord('3'):
                    if self.yolo_net:
                        self.mode = "both"
                        print("Mode: Comparison")
                    else:
                        print("YOLO not available for comparison")
                elif key == ord('+'):
                    self.confidence_threshold = min(0.95, self.confidence_threshold + 0.05)
                    print(f"Confidence: {self.confidence_threshold:.2f}")
                elif key == ord('-'):
                    self.confidence_threshold = max(0.1, self.confidence_threshold - 0.05)
                    print(f"Confidence: {self.confidence_threshold:.2f}")
                elif key == ord('f'):
                    self.filter_mode = not self.filter_mode
                    print(f"Filter: {'ON' if self.filter_mode else 'OFF'}")
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    cv2.imwrite(f"detection_comparison_{timestamp}.jpg", result)
                    print(f"✓ Saved")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()


def main():
    """Main function."""
    print("\n" + "="*60)
    print("OBJECT DETECTION COMPARISON")
    print("="*60)
    
    try:
        comparator = ObjectDetectionComparison()
        comparator.run()
    except FileNotFoundError as e:
        print(f"\n{e}")
        return
    
    print("\n" + "="*60)
    print("COMPARISON SUMMARY")
    print("="*60)
    print("\n📊 MobileNet-SSD vs YOLO:")
    print("\nMobileNet-SSD:")
    print("  ✓ Faster (20-30 FPS typical)")
    print("  ✓ Lighter weight (~23MB)")
    print("  ✗ Only 20 classes")
    print("  ✗ Less accurate")
    print("\nYOLO:")
    print("  ✓ 80 classes detected")
    print("  ✓ More accurate")
    print("  ✗ Slower (10-20 FPS)")
    print("  ✗ Larger model (~23-240MB)")
    print("\n💡 Choose based on your needs!")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
