"""
Week 4 - Example 19: Combined Object and Face Detection
DM-GY 9201 B Digital Doubles
Professor: Jiwon Shin

Description:
    Combine object detection with face detection for context-aware analysis.
    Detect what people are holding, where they are, and what's around them.

Key Concepts:
    - Multi-modal object and face detection
    - Context-aware analysis
    - Coordinating multiple detection streams
    - Object-person interaction detection

Example uses:
    - "Person holding phone" detection
    - Counting people vs. objects
    - Scene understanding

Controls:
    '1' - Toggle face detection
    '2' - Toggle object detection
    '3' - Toggle people-only mode
    '4' - Toggle interaction detection
    'q' - Quit

Usage:
    python 19_object_and_face.py
"""

import cv2
import numpy as np
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator

class ObjectAndFaceDetector:
    """Combined object and face detection with interaction analysis"""
    
    # MobileNet-SSD classes
    CLASSES = [
        "background", "aeroplane", "bicycle", "bird", "boat",
        "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
        "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
        "sofa", "train", "tvmonitor"
    ]
    
    # Colors for object detection
    COLORS = np.random.uniform(0, 255, size=(len(CLASSES), 3))
    
    def __init__(self, face_proto, face_model, object_proto, object_model):
        """Initialize both detectors"""
        # Load face detector
        try:
            self.face_net = cv2.dnn.readNetFromCaffe(face_proto, face_model)
            print("✓ Loaded face detection model")
        except Exception as e:
            print(f"✗ Error loading face model: {e}")
            sys.exit(1)
        
        # Load object detector
        try:
            self.object_net = cv2.dnn.readNetFromCaffe(object_proto, object_model)
            print("✓ Loaded object detection model")
        except Exception as e:
            print(f"✗ Error loading object model: {e}")
            sys.exit(1)
        
        # Settings
        self.show_faces = True
        self.show_objects = True
        self.people_only_mode = False
        self.detect_interactions = False
        self.face_confidence = 0.5
        self.object_confidence = 0.5
        
        # FPS tracker
        self.fps_calc = FPSCalculator()
    
    def detect_faces(self, frame):
        """Detect faces"""
        h, w = frame.shape[:2]
        
        blob = cv2.dnn.blobFromImage(
            frame, 1.0, (300, 300),
            (104.0, 177.0, 123.0), swapRB=False
        )
        
        self.face_net.setInput(blob)
        detections = self.face_net.forward()
        
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.face_confidence:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x1, y1, x2, y2) = box.astype("int")
                faces.append({
                    'box': (x1, y1, x2, y2),
                    'confidence': confidence,
                    'center': ((x1 + x2) // 2, (y1 + y2) // 2)
                })
        
        return faces
    
    def detect_objects(self, frame):
        """Detect objects"""
        h, w = frame.shape[:2]
        
        blob = cv2.dnn.blobFromImage(
            cv2.resize(frame, (300, 300)),
            0.007843, (300, 300),
            (127.5, 127.5, 127.5), swapRB=False
        )
        
        self.object_net.setInput(blob)
        detections = self.object_net.forward()
        
        objects = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > self.object_confidence:
                class_id = int(detections[0, 0, i, 1])
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x1, y1, x2, y2) = box.astype("int")
                
                objects.append({
                    'class_id': class_id,
                    'class_name': self.CLASSES[class_id],
                    'box': (x1, y1, x2, y2),
                    'confidence': confidence,
                    'center': ((x1 + x2) // 2, (y1 + y2) // 2)
                })
        
        return objects
    
    def detect_interactions(self, faces, objects):
        """Detect interactions between faces and nearby objects"""
        interactions = []
        
        for face in faces:
            face_center = face['center']
            nearby_objects = []
            
            for obj in objects:
                if obj['class_name'] == 'person':
                    continue  # Skip person detections
                
                # Calculate distance between face and object
                obj_center = obj['center']
                distance = np.sqrt(
                    (face_center[0] - obj_center[0])**2 +
                    (face_center[1] - obj_center[1])**2
                )
                
                # If object is close to face (within 200 pixels)
                if distance < 200:
                    nearby_objects.append((obj, distance))
            
            if nearby_objects:
                # Sort by distance
                nearby_objects.sort(key=lambda x: x[1])
                closest = nearby_objects[0][0]
                
                interactions.append({
                    'face': face,
                    'object': closest,
                    'description': f"Person with {closest['class_name']}"
                })
        
        return interactions
    
    def draw_faces(self, frame, faces):
        """Draw face detections"""
        for face in faces:
            x1, y1, x2, y2 = face['box']
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"Face: {face['confidence']*100:.1f}%"
            cv2.putText(frame, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        return frame
    
    def draw_objects(self, frame, objects):
        """Draw object detections"""
        for obj in objects:
            # Skip person class if in people-only mode
            if self.people_only_mode and obj['class_name'] == 'person':
                continue
            
            x1, y1, x2, y2 = obj['box']
            class_id = obj['class_id']
            color = self.COLORS[class_id]
            
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            label = f"{obj['class_name']}: {obj['confidence']*100:.1f}%"
            cv2.putText(frame, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return frame
    
    def draw_interactions(self, frame, interactions):
        """Draw detected interactions"""
        for interaction in interactions:
            face = interaction['face']
            obj = interaction['object']
            
            # Draw line connecting face to object
            cv2.line(frame, face['center'], obj['center'],
                    (255, 255, 0), 2, lineType=cv2.LINE_AA)
            
            # Draw interaction label
            mid_point = (
                (face['center'][0] + obj['center'][0]) // 2,
                (face['center'][1] + obj['center'][1]) // 2
            )
            
            cv2.putText(frame, interaction['description'],
                       mid_point, cv2.FONT_HERSHEY_SIMPLEX,
                       0.6, (255, 255, 0), 2)
        
        return frame
    
    def process_frame(self, frame):
        """Process frame with both detectors"""
        result = frame.copy()
        
        # Detect faces
        faces = []
        if self.show_faces:
            faces = self.detect_faces(frame)
        
        # Detect objects
        objects = []
        if self.show_objects:
            objects = self.detect_objects(frame)
        
        # Detect interactions
        interactions = []
        if self.detect_interactions and faces and objects:
            interactions = self.detect_interactions(faces, objects)
        
        # Draw detections
        if self.show_objects and not self.detect_interactions:
            result = self.draw_objects(result, objects)
        
        if self.show_faces and not self.detect_interactions:
            result = self.draw_faces(result, faces)
        
        if self.detect_interactions:
            result = self.draw_interactions(result, interactions)
        
        # Add status info
        self.fps_calc.update()
        result = self.fps_calc.draw_fps(result)
        
        # Add counts
        y_offset = 60
        cv2.putText(result, f"Faces: {len(faces)}", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        y_offset += 30
        
        # Count objects by type
        object_counts = {}
        for obj in objects:
            name = obj['class_name']
            object_counts[name] = object_counts.get(name, 0) + 1
        
        cv2.putText(result, f"Objects: {len(objects)}", (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        y_offset += 30
        
        if self.detect_interactions:
            cv2.putText(result, f"Interactions: {len(interactions)}",
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX,
                       0.6, (255, 0, 255), 2)
        
        # Show object breakdown
        if object_counts:
            y_offset = result.shape[0] - 150
            cv2.putText(result, "Detected:", (10, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            y_offset += 20
            
            for name, count in list(object_counts.items())[:4]:  # Show top 4
                cv2.putText(result, f"  {name}: {count}", (10, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
                y_offset += 18
        
        # Controls
        controls = [
            "1: Faces", "2: Objects", "3: People-only", "4: Interactions", "q: Quit"
        ]
        y_offset = result.shape[0] - 10
        cv2.putText(result, " | ".join(controls), (10, y_offset),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        return result


def main():
    print("=== Object + Face Detection ===\n")
    
    # Model paths
    models_dir = Path(__file__).parent / 'models'
    
    face_proto = models_dir / 'face_detection' / 'deploy.prototxt'
    face_model = models_dir / 'face_detection' / 'res10_300x300_ssd_iter_140000.caffemodel'
    object_proto = models_dir / 'object_detection' / 'MobileNetSSD_deploy.prototxt'
    object_model = models_dir / 'object_detection' / 'MobileNetSSD_deploy.caffemodel'
    
    # Check models
    if not all([face_proto.exists(), face_model.exists(),
                object_proto.exists(), object_model.exists()]):
        print("✗ Required models not found!")
        print("\nNeed:")
        print(f"  {face_proto}")
        print(f"  {face_model}")
        print(f"  {object_proto}")
        print(f"  {object_model}")
        return
    
    # Initialize detector
    detector = ObjectAndFaceDetector(
        str(face_proto), str(face_model),
        str(object_proto), str(object_model)
    )
    
    print("Controls:")
    print("  '1' - Toggle face detection")
    print("  '2' - Toggle object detection")
    print("  '3' - Toggle people-only mode")
    print("  '4' - Toggle interaction detection")
    print("  'q' - Quit")
    print("\nStarting webcam...\n")
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("✗ Could not open webcam")
        return
    
    print("✓ Ready! Try holding an object near your face\n")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        
        # Process with both detectors
        result = detector.process_frame(frame)
        
        cv2.imshow('Object + Face Detection', result)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('1'):
            detector.show_faces = not detector.show_faces
            print(f"Face detection: {'ON' if detector.show_faces else 'OFF'}")
        elif key == ord('2'):
            detector.show_objects = not detector.show_objects
            print(f"Object detection: {'ON' if detector.show_objects else 'OFF'}")
        elif key == ord('3'):
            detector.people_only_mode = not detector.people_only_mode
            print(f"People-only mode: {'ON' if detector.people_only_mode else 'OFF'}")
        elif key == ord('4'):
            detector.detect_interactions = not detector.detect_interactions
            print(f"Interaction detection: {'ON' if detector.detect_interactions else 'OFF'}")
    
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
