"""
09: Feature Matching - Interactive Object Recognition
Week 4: Computer Vision - Detection & Feature Recognition
Digital Doubles - Fall 2025

Interactive feature matching for real-time object recognition.
Capture a reference object, then watch as the system finds and
tracks it as you move the camera!

Concepts:
- Feature matching with BFMatcher and FLANN
- Object recognition by features
- Homography for object localization
- Real-time tracking

Usage:
    python 09_feature_matching.py

Controls:
    - 'c' - Capture reference object from current frame
    - 'r' - Reset (clear reference)
    - 'm' - Toggle matcher (BFMatcher / FLANN)
    - 'f' - Toggle feature detector (SIFT / ORB)
    - 'd' - Toggle match drawing
    - 's' - Save current frame
    - 'q' - Quit

How to use:
    1. Hold an object (book, product, mug) in front of camera
    2. Press 'c' to capture it as reference
    3. Move the object around, rotate it
    4. Watch the system find and track it!

Author: Jiwon Shin
Date: November 2025
"""

import cv2
import numpy as np
from pathlib import Path
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))
from utils.fps_calculator import FPSCalculator
from utils.detection_visualizer import DetectionVisualizer


class FeatureMatcher:
    """
    Real-time feature matching for object recognition.
    """
    
    def __init__(self):
        """Initialize feature matcher."""
        # Feature detector
        self.detector_type = "orb"  # "orb" or "sift"
        self.init_detector()
        
        # Matcher type
        self.matcher_type = "bf"  # "bf" (BFMatcher) or "flann"
        self.init_matcher()
        
        # Reference object
        self.ref_frame = None
        self.ref_keypoints = None
        self.ref_descriptors = None
        self.ref_gray = None
        
        # Visualization
        self.draw_matches_viz = True
        self.min_match_count = 10  # Minimum matches for valid detection
        
        # Utilities
        self.fps = FPSCalculator()
        self.viz = DetectionVisualizer()
        
        print("Feature Matcher initialized")
        print(f"Detector: {self.detector_type.upper()}")
        print(f"Matcher: {self.matcher_type.upper()}")
    
    def init_detector(self):
        """Initialize feature detector based on type."""
        if self.detector_type == "sift":
            try:
                self.detector = cv2.SIFT_create()
                print("✓ SIFT detector ready")
            except AttributeError:
                print("⚠ SIFT not available, using ORB")
                self.detector_type = "orb"
                self.detector = cv2.ORB_create(nfeatures=500)
        else:
            self.detector = cv2.ORB_create(nfeatures=500)
            print("✓ ORB detector ready")
    
    def init_matcher(self):
        """Initialize feature matcher based on type."""
        if self.matcher_type == "bf":
            # Brute Force matcher
            if self.detector_type == "sift":
                self.matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
            else:  # ORB uses Hamming distance
                self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
            print("✓ BFMatcher ready")
        else:
            # FLANN matcher
            if self.detector_type == "sift":
                FLANN_INDEX_KDTREE = 1
                index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
            else:  # ORB
                FLANN_INDEX_LSH = 6
                index_params = dict(algorithm=FLANN_INDEX_LSH,
                                   table_number=6,
                                   key_size=12,
                                   multi_probe_level=1)
            search_params = dict(checks=50)
            self.matcher = cv2.FlannBasedMatcher(index_params, search_params)
            print("✓ FLANN matcher ready")
    
    def capture_reference(self, frame):
        """
        Capture a reference object from the frame center.
        
        Args:
            frame: Current video frame
        """
        print("\n" + "="*50)
        print("CAPTURING REFERENCE OBJECT...")
        
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect features
        keypoints, descriptors = self.detector.detectAndCompute(gray, None)
        
        if descriptors is None or len(keypoints) < self.min_match_count:
            print(f"✗ Not enough features detected ({len(keypoints) if keypoints else 0})")
            print(f"  Need at least {self.min_match_count} features")
            print("  Try a more textured object (book, product packaging)")
            return False
        
        # Store reference
        self.ref_frame = frame.copy()
        self.ref_gray = gray.copy()
        self.ref_keypoints = keypoints
        self.ref_descriptors = descriptors
        
        print(f"✓ Reference captured!")
        print(f"  Features detected: {len(keypoints)}")
        print(f"  Descriptor type: {descriptors.dtype}")
        print(f"  Descriptor shape: {descriptors.shape}")
        print("="*50 + "\n")
        
        return True
    
    def match_features(self, descriptors1, descriptors2):
        """
        Match features between two descriptor sets.
        
        Returns:
            good_matches: List of good matches
        """
        # Match descriptors
        if self.matcher_type == "bf":
            # BFMatcher with KNN
            matches = self.matcher.knnMatch(descriptors1, descriptors2, k=2)
        else:
            # FLANN
            try:
                matches = self.matcher.knnMatch(descriptors1, descriptors2, k=2)
            except cv2.error:
                return []
        
        # Apply ratio test (Lowe's ratio test)
        good_matches = []
        for match_pair in matches:
            if len(match_pair) == 2:
                m, n = match_pair
                if m.distance < 0.75 * n.distance:
                    good_matches.append(m)
        
        return good_matches
    
    def find_object(self, frame):
        """
        Find reference object in current frame.
        
        Returns:
            found: Whether object was found
            matches: Good matches
            homography: Transformation matrix (if found)
            box_points: Corner points of detected object (if found)
        """
        if self.ref_descriptors is None:
            return False, [], None, None
        
        # Detect features in current frame
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        keypoints, descriptors = self.detector.detectAndCompute(gray, None)
        
        if descriptors is None or len(keypoints) < self.min_match_count:
            return False, [], None, None
        
        # Match features
        matches = self.match_features(self.ref_descriptors, descriptors)
        
        if len(matches) < self.min_match_count:
            return False, matches, None, None
        
        # Extract matched keypoint locations
        src_pts = np.float32([self.ref_keypoints[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
        dst_pts = np.float32([keypoints[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
        
        # Find homography
        try:
            M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
            
            if M is None:
                return False, matches, None, None
            
            # Get corners of reference image
            h, w = self.ref_gray.shape
            corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2)
            
            # Transform corners to current frame
            transformed_corners = cv2.perspectiveTransform(corners, M)
            
            return True, matches, M, transformed_corners
            
        except cv2.error:
            return False, matches, None, None
    
    def draw_detection(self, frame, matches, box_points):
        """
        Draw detection results on frame.
        
        Args:
            frame: Current frame
            matches: Good matches
            box_points: Corner points of detected object
        """
        result = frame.copy()
        
        # Draw bounding box
        if box_points is not None:
            box_points = np.int32(box_points)
            cv2.polylines(result, [box_points], True, (0, 255, 0), 3)
            
            # Label
            cv2.putText(result, "OBJECT FOUND", 
                       tuple(box_points[0][0] - np.array([0, 20])),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Draw match count
        info = {
            'Matches': len(matches),
            'Min Required': self.min_match_count,
            'Status': 'FOUND' if box_points is not None else 'SEARCHING',
            'Detector': self.detector_type.upper(),
            'Matcher': self.matcher_type.upper(),
            'FPS': f"{self.fps.get_fps():.1f}"
        }
        
        self.viz.draw_info_panel(result, info, position=(10, 30))
        
        return result
    
    def draw_matches_visualization(self, frame, keypoints, matches):
        """Draw top matches between reference and current frame."""
        if self.ref_frame is None or not matches:
            return frame
        
        # Draw only top 20 matches for clarity
        top_matches = sorted(matches, key=lambda x: x.distance)[:20]
        
        # Create match visualization
        match_img = cv2.drawMatches(
            self.ref_frame, self.ref_keypoints,
            frame, keypoints,
            top_matches, None,
            matchColor=(0, 255, 0),
            singlePointColor=(255, 0, 0),
            flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
        )
        
        return match_img
    
    def draw_ui(self, frame):
        """Draw user interface controls."""
        h = frame.shape[0]
        
        controls = [
            "C: Capture | R: Reset | M: Matcher | F: Detector",
            "D: Draw matches | S: Save | Q: Quit"
        ]
        
        y_pos = h - 50
        for text in controls:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            cv2.rectangle(frame, (10, y_pos - text_h - 5),
                         (10 + text_w + 10, y_pos + 5),
                         (0, 0, 0), -1)
            cv2.putText(frame, text, (15, y_pos),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (255, 255, 255), 1)
            y_pos += 25
        
        # Reference status
        if self.ref_frame is not None:
            cv2.rectangle(frame, (frame.shape[1] - 180, 10),
                         (frame.shape[1] - 10, 50),
                         (0, 255, 0), 2)
            cv2.putText(frame, "REF CAPTURED", 
                       (frame.shape[1] - 170, 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (0, 255, 0), 2)
        else:
            cv2.rectangle(frame, (frame.shape[1] - 180, 10),
                         (frame.shape[1] - 10, 50),
                         (0, 0, 255), 2)
            cv2.putText(frame, "NO REFERENCE", 
                       (frame.shape[1] - 170, 35),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                       (0, 0, 255), 2)
        
        return frame
    
    def run(self):
        """Run real-time feature matching."""
        print("\n" + "="*60)
        print("INTERACTIVE FEATURE MATCHING & OBJECT RECOGNITION")
        print("="*60)
        print("\nOpening webcam...")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return
        
        print("✓ Webcam opened")
        print("\nHOW TO USE:")
        print("  1. Hold an object in front of camera (book, product, mug)")
        print("  2. Press 'C' to capture it as reference")
        print("  3. Move the object around, rotate it")
        print("  4. Watch the system find and track it!")
        print("\nBEST OBJECTS:")
        print("  ✓ Books with text")
        print("  ✓ Product packaging with logos")
        print("  ✓ Posters or printed images")
        print("  ✓ Textured objects")
        print("  ✗ Smooth, featureless objects")
        
        window_name = "Feature Matching"
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Flip for mirror effect
                frame = cv2.flip(frame, 1)
                
                if self.ref_frame is not None:
                    # Try to find object
                    found, matches, homography, box_points = self.find_object(frame)
                    
                    if self.draw_matches_viz and matches:
                        # Show match lines
                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                        kp, _ = self.detector.detectAndCompute(gray, None)
                        result = self.draw_matches_visualization(frame, kp, matches)
                    else:
                        # Just show detection
                        result = self.draw_detection(frame, matches, box_points)
                else:
                    # No reference yet
                    result = frame.copy()
                    
                    # Draw capture hint
                    h, w = frame.shape[:2]
                    cv2.rectangle(result, (w//4, h//4), (3*w//4, 3*h//4),
                                 (0, 255, 255), 2)
                    cv2.putText(result, "Position object here", 
                               (w//4 + 10, h//4 - 10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                               (0, 255, 255), 2)
                    cv2.putText(result, "Press 'C' to capture", 
                               (w//4 + 10, 3*h//4 + 30),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                               (0, 255, 255), 2)
                
                # Draw UI
                result = self.draw_ui(result)
                
                # Update FPS
                self.fps.update()
                
                # Display
                cv2.imshow(window_name, result)
                
                # Handle keys
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                    
                elif key == ord('c'):
                    self.capture_reference(frame)
                    
                elif key == ord('r'):
                    self.ref_frame = None
                    self.ref_keypoints = None
                    self.ref_descriptors = None
                    print("Reference cleared")
                    
                elif key == ord('m'):
                    self.matcher_type = "flann" if self.matcher_type == "bf" else "bf"
                    self.init_matcher()
                    print(f"Matcher: {self.matcher_type.upper()}")
                    
                elif key == ord('f'):
                    self.detector_type = "sift" if self.detector_type == "orb" else "orb"
                    self.init_detector()
                    self.init_matcher()  # Matcher depends on detector
                    # Clear reference (incompatible descriptors)
                    self.ref_frame = None
                    self.ref_keypoints = None
                    self.ref_descriptors = None
                    print(f"Detector: {self.detector_type.upper()}")
                    print("Reference cleared (incompatible descriptors)")
                    
                elif key == ord('d'):
                    self.draw_matches_viz = not self.draw_matches_viz
                    print(f"Match visualization: {'ON' if self.draw_matches_viz else 'OFF'}")
                    
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"feature_match_{timestamp}.jpg"
                    cv2.imwrite(filename, result)
                    print(f"✓ Saved: {filename}")
        
        finally:
            cap.release()
            cv2.destroyAllWindows()
            
            print(f"\nProcessed {self.fps.frame_count} frames")
            print(f"Average FPS: {self.fps.get_average_fps():.2f}")


def main():
    """Main function."""
    print("\n" + "="*60)
    print("FEATURE MATCHING FOR OBJECT RECOGNITION")
    print("="*60)
    print("\nFeature matching allows us to recognize objects even when")
    print("they're rotated, scaled, or partially occluded!")
    print("\nHOW IT WORKS:")
    print("  1. Detect features in reference image")
    print("  2. Detect features in current frame")
    print("  3. Match descriptors between them")
    print("  4. Use matches to find object location")
    print("  5. Compute homography (transformation)")
    print("\nMATCHING ALGORITHMS:")
    print("  • BFMatcher - Brute force, accurate")
    print("  • FLANN - Fast approximate, good for large sets")
    print("\nLOWE'S RATIO TEST:")
    print("  • Keep match only if best match is significantly")
    print("    better than second-best match")
    print("  • Ratio threshold: typically 0.75")
    print("  • Reduces false matches")
    print("\nCONTROLS:")
    print("  C - Capture reference object")
    print("  R - Reset (clear reference)")
    print("  M - Toggle matcher (BF / FLANN)")
    print("  F - Toggle detector (ORB / SIFT)")
    print("  D - Toggle match line visualization")
    print("  S - Save current frame")
    print("  Q - Quit")
    print("="*60)
    
    matcher = FeatureMatcher()
    matcher.run()
    
    print("\n" + "="*60)
    print("KEY TAKEAWAYS:")
    print("="*60)
    print("✓ Feature matching enables object recognition")
    print("✓ Works despite rotation, scale, lighting changes")
    print("✓ Lowe's ratio test filters bad matches")
    print("✓ Homography localizes object position")
    print("\n📊 PERFORMANCE:")
    print("  • BFMatcher: More accurate, slower")
    print("  • FLANN: Faster, approximate")
    print("  • ORB: Faster features, binary descriptors")
    print("  • SIFT: Slower features, better accuracy")
    print("\n🎯 APPLICATIONS:")
    print("  • Object recognition and tracking")
    print("  • Augmented reality markers")
    print("  • Image stitching (panoramas)")
    print("  • Visual search engines")
    print("  • Product recognition")
    print("  • Document scanning")
    print("\n💡 TIPS:")
    print("  • More features = better matching")
    print("  • Textured objects work best")
    print("  • Partial occlusion is OK")
    print("  • Extreme angles may fail")
    print("  • Need ~10+ good matches minimum")
    print("\nThis completes the feature detection examples!")
    print("Next: Try object detection (10-13) or pose estimation (14-17)")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
