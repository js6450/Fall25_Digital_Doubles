"""
Trackbar Controls Demo - Blur Effect
Simple demonstration of using a slider (trackbar) to control video effects in real-time

Key Concepts:
- Creating a trackbar control
- Reading trackbar values in real-time
- Applying blur effect based on slider position
- Displaying parameter feedback on video

Trackbar Usage:
- cv2.createTrackbar() - Creates a slider control
- cv2.getTrackbarPos() - Reads current slider value
- cv2.GaussianBlur() - Applies blur effect
"""

import cv2

def main():
    """
    Simple blur control demo using a trackbar
    """
    # Open the camera
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    # Create window
    window_name = 'Blur Control Demo'
    cv2.namedWindow(window_name)

    # Create trackbar
    # Parameters: trackbar name, window name, initial value, max value, callback function
    cv2.createTrackbar('Blur Amount', window_name, 1, 25, lambda x: None)

    print("\n" + "=" * 60)
    print("BLUR CONTROL DEMO")
    print("=" * 60)
    print("Move the slider to adjust the blur amount")
    print("Press 'q' to quit")
    print("=" * 60 + "\n")

    while True:
        # Capture frame
        ret, frame = cap.read()

        if not ret:
            print("Error: Failed to capture frame")
            break

        # Get current trackbar position
        blur_amount = cv2.getTrackbarPos('Blur Amount', window_name)

        # Ensure blur kernel is odd and at least 1
        # (Gaussian blur requires odd kernel size)
        if blur_amount < 1:
            blur_amount = 1
        if blur_amount % 2 == 0:
            blur_amount += 1

        # Apply blur effect
        if blur_amount > 1:
            result = cv2.GaussianBlur(frame, (blur_amount, blur_amount), 0)
        else:
            result = frame.copy()

        # Display current blur amount on video
        text = f"Blur Kernel Size: {blur_amount}x{blur_amount}"
        cv2.putText(result, text, (10, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Show result
        cv2.imshow(window_name, result)

        # Exit on 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Cleanup
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
