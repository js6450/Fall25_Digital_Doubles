"""
Video Processing Effects - Spacebar Switcher
Cycling through effects using the spacebar

This example demonstrates how to cycle through multiple video effects
using a single key (spacebar). Students will learn to:
- Cycle through a list of effects sequentially
- Use index-based effect selection
- Handle spacebar input for effect switching
- Display current effect information

Key Concepts:
- Sequential effect cycling
- Index-based effect selection
- Simplified user interaction
- State management with counters

Usage:
- Press SPACE to cycle through effects
- Press 'q' to quit

Effects cycle: Original -> Gray -> Blur -> Edges -> Original...
"""

import cv2
import numpy as np

def main():
    # Try to open webcam first (index 0)
    cap = cv2.VideoCapture(0)

    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        # Use relative path to Resources folder
        cap = cv2.VideoCapture('../Resources/ocean_waves.mp4')

    if not cap.isOpened():
        print("Error: Could not open video source")
        return

    # List of effect names
    effects = ['Original', 'Gray', 'Blur', 'Edges']
    current = 0

    print("Video Effect Switcher")
    print("=" * 50)
    print("Controls:")
    print("  SPACE - Cycle through effects")
    print("  'q'   - Quit")
    print("=" * 50)
    print(f"Starting effect: {effects[current]}")

    while True:
        # Read frame from video
        ret, frame = cap.read()

        # If frame is not read successfully (end of video), loop back
        if not ret:
            # Reset video to beginning
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        # Resize frame for better display while maintaining aspect ratio
        height, width = frame.shape[:2]
        max_width = 640
        aspect_ratio = width / height
        new_width = max_width
        new_height = int(new_width / aspect_ratio)
        frame = cv2.resize(frame, (new_width, new_height))

        # Apply effect based on current index
        if current == 0:
            # Original - no processing
            result = frame
        elif current == 1:
            # Grayscale
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Convert back to BGR for display
            result = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        elif current == 2:
            # Blur
            result = cv2.GaussianBlur(frame, (15, 15), 0)
        elif current == 3:
            # Edges (Canny edge detection)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 100, 200)
            # Convert back to BGR for display
            result = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

        # Add text overlay showing current effect
        cv2.putText(result, f"Effect: {effects[current]}",
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                   1, (0, 255, 0), 2)

        # Add instruction text
        cv2.putText(result, "SPACE: Next Effect | Q: Quit",
                   (10, result.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX,
                   0.5, (255, 255, 255), 1)

        # Display the processed frame
        cv2.imshow('Video Effect Switcher', result)

        # Wait for key press (1ms)
        key = cv2.waitKey(1) & 0xFF

        # Press SPACE to cycle effects
        if key == ord(' '):
            current = (current + 1) % len(effects)
            print(f"Switched to: {effects[current]}")

        # Quit if 'q' is pressed
        elif key == ord('q'):
            break

    # Release video capture and close windows
    cap.release()
    cv2.destroyAllWindows()
    print("Video processing stopped.")

if __name__ == "__main__":
    main()
