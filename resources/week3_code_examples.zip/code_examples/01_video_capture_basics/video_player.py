import cv2

def display_video_info(video_path):
    """Display information about the video file."""
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print(f"Error: Could not open video file: {video_path}")
        return

    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / fps if fps > 0 else 0

    print("=" * 50)
    print("VIDEO INFORMATION")
    print("=" * 50)
    print(f"Video Path: {video_path}")
    print(f"Resolution: {width}x{height}")
    print(f"FPS: {fps:.2f}")
    print(f"Total Frames: {frame_count}")
    print(f"Duration: {duration:.2f} seconds")
    print("=" * 50)
    print()

    cap.release()

def play_video_file(video_path):
    """Play the video file."""
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print(f"Error: Could not open video file: {video_path}")
        return

    print("Playing video... Press 'q' to quit")
    print()

    while True:
        ret, frame = cap.read()

        if not ret:
            print("End of video")
            break

        cv2.imshow('Video Player', frame)

        # Wait 25ms and check if 'q' is pressed
        if cv2.waitKey(25) & 0xFF == ord('q'):
            print("Video playback stopped by user")
            break

    cap.release()
    cv2.destroyAllWindows()

def main():
    video_path = '../Resources/ocean_waves.mp4'

    # Display video information
    display_video_info(video_path)

    # Play the video
    play_video_file(video_path)

if __name__ == "__main__":
    main()
