import cv2

def display_webcam_info(camera_index=0):
    """Display information about the webcam."""
    cap = cv2.VideoCapture(camera_index)

    if not cap.isOpened():
        print(f"Error: Could not open webcam at index {camera_index}")
        return

    # Get webcam properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    print("=" * 50)
    print("WEBCAM INFORMATION")
    print("=" * 50)
    print(f"Camera Index: {camera_index}")
    print(f"Resolution: {width}x{height}")
    print(f"FPS: {fps:.2f}")
    print("=" * 50)
    print()

    cap.release()

def capture_webcam(camera_index=0):
    """Start and display the webcam feed."""
    cap = cv2.VideoCapture(camera_index)

    if not cap.isOpened():
        print(f"Error: Could not open webcam at index {camera_index}")
        return

    print("Webcam started... Press 'q' to quit")
    print()

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Error: Failed to capture frame")
            break

        cv2.imshow('Webcam Player', frame)

        # Wait 1ms and check if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("Webcam capture stopped by user")
            break

    cap.release()
    cv2.destroyAllWindows()

def main():
    camera_index = 0

    # Display webcam information
    display_webcam_info(camera_index)

    # Capture and display webcam
    capture_webcam(camera_index)

if __name__ == "__main__":
    main()
