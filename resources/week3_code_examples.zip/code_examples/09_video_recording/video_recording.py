"""
Video Recording Example
Saving processed video to file

This bonus example teaches students how to save their processed video
to a file. This is essential for:
- Creating video documentation of their work
- Sharing results with others
- Building video processing applications
- Generating content for presentations

Students will learn:
- VideoWriter setup and configuration
- Codec selection (MJPEG, MP4V, etc.)
- Frame rate and resolution management
- Recording controls (start/stop/pause)
- Multiple output formats

Key Concepts:
- VideoWriter class usage
- FourCC codec codes
- Frame rate synchronization
- File output management
- Recording state management

Common Codecs:
- MJPEG ('MJPG'): Good quality, larger files, widely compatible
- MP4V ('mp4v'): Good compression, smaller files
- XVID ('XVID'): Good compression, may need codec installed
- H264 ('H264'): Best compression, not always available

Usage:
- SPACE: Start/stop recording
- 'r': Start new recording
- 'f': Apply filter (cycles through filters)
- 's': Save screenshot
- 'q': Quit
"""

import cv2
import numpy as np
from datetime import datetime
import os

class VideoRecorder:
    """
    Video recording manager with various effects
    """
    
    def __init__(self, output_dir='recordings'):
        """
        Initialize video recorder
        
        Args:
            output_dir: Directory to save recordings
        """
        self.output_dir = output_dir
        self.recording = False
        self.video_writer = None
        self.current_filename = None
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Recording settings
        self.fps = 20.0
        self.frame_size = (640, 480)
        self.codec = 'MJPG'  # MJPEG codec (widely compatible)
        
        # Frame counter
        self.frame_count = 0
        
        # Filters
        self.filters = {
            'original': self.apply_original,
            'blur': self.apply_blur,
            'edge': self.apply_edge,
            'grayscale': self.apply_grayscale,
            'sepia': self.apply_sepia,
            'cartoon': self.apply_cartoon
        }
        self.filter_names = list(self.filters.keys())
        self.current_filter_idx = 0
    
    # ==================== FILTER METHODS ====================
    
    def apply_original(self, frame):
        """No filter"""
        return frame
    
    def apply_blur(self, frame):
        """Blur filter"""
        return cv2.GaussianBlur(frame, (15, 15), 0)
    
    def apply_edge(self, frame):
        """Edge detection"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
    
    def apply_grayscale(self, frame):
        """Grayscale"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    
    def apply_sepia(self, frame):
        """Sepia tone effect"""
        kernel = np.array([[0.272, 0.534, 0.131],
                          [0.349, 0.686, 0.168],
                          [0.393, 0.769, 0.189]])
        return cv2.transform(frame, kernel)
    
    def apply_cartoon(self, frame):
        """Cartoon effect"""
        # Bilateral filter for smoothing while preserving edges
        smooth = cv2.bilateralFilter(frame, 9, 75, 75)
        
        # Edge detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.adaptiveThreshold(gray, 255, 
                                      cv2.ADAPTIVE_THRESH_MEAN_C,
                                      cv2.THRESH_BINARY, 9, 9)
        edges = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        
        # Combine
        return cv2.bitwise_and(smooth, edges)
    
    # ==================== RECORDING METHODS ====================
    
    def start_recording(self):
        """Start video recording"""
        if self.recording:
            return False
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filter_name = self.filter_names[self.current_filter_idx]
        self.current_filename = f"{self.output_dir}/recording_{filter_name}_{timestamp}.avi"
        
        # Create VideoWriter
        fourcc = cv2.VideoWriter_fourcc(*self.codec)
        self.video_writer = cv2.VideoWriter(
            self.current_filename,
            fourcc,
            self.fps,
            self.frame_size
        )
        
        if self.video_writer.isOpened():
            self.recording = True
            self.frame_count = 0
            print(f"Started recording: {self.current_filename}")
            return True
        else:
            print("Error: Could not start recording")
            return False
    
    def stop_recording(self):
        """Stop video recording"""
        if not self.recording:
            return False
        
        self.recording = False
        if self.video_writer:
            self.video_writer.release()
            self.video_writer = None
        
        duration = self.frame_count / self.fps
        print(f"Stopped recording: {self.current_filename}")
        print(f"Duration: {duration:.1f}s ({self.frame_count} frames)")
        return True
    
    def write_frame(self, frame):
        """Write frame to video file"""
        if self.recording and self.video_writer:
            self.video_writer.write(frame)
            self.frame_count += 1
            return True
        return False
    
    def toggle_recording(self):
        """Toggle recording on/off"""
        if self.recording:
            return self.stop_recording()
        else:
            return self.start_recording()
    
    def save_screenshot(self, frame):
        """Save current frame as screenshot"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filter_name = self.filter_names[self.current_filter_idx]
        filename = f"{self.output_dir}/screenshot_{filter_name}_{timestamp}.jpg"
        cv2.imwrite(filename, frame)
        print(f"Screenshot saved: {filename}")
    
    def cycle_filter(self):
        """Cycle to next filter"""
        self.current_filter_idx = (self.current_filter_idx + 1) % len(self.filter_names)
        filter_name = self.filter_names[self.current_filter_idx]
        print(f"Filter: {filter_name}")
        return filter_name
    
    def get_current_filter(self):
        """Get current filter function"""
        filter_name = self.filter_names[self.current_filter_idx]
        return self.filters[filter_name], filter_name
    
    def cleanup(self):
        """Cleanup resources"""
        if self.recording:
            self.stop_recording()

def draw_ui(frame, recorder, filter_name):
    """
    Draw UI overlay on frame
    
    Args:
        frame: Frame to draw on
        recorder: VideoRecorder instance
        filter_name: Current filter name
    
    Returns:
        Frame with UI overlay
    """
    result = frame.copy()
    
    # Recording indicator
    if recorder.recording:
        # Red recording dot
        cv2.circle(result, (30, 30), 15, (0, 0, 255), -1)
        cv2.putText(result, "REC", (55, 40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        # Frame count and time
        duration = recorder.frame_count / recorder.fps
        time_str = f"{duration:.1f}s ({recorder.frame_count} frames)"
        cv2.putText(result, time_str, (55, 70), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    else:
        # Ready indicator
        cv2.putText(result, "Ready - Press SPACE to record", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    # Current filter
    cv2.putText(result, f"Filter: {filter_name}", (10, result.shape[0] - 20), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    
    # Controls help
    help_text = [
        "SPACE: Start/Stop Recording",
        "F: Change Filter",
        "S: Screenshot",
        "Q: Quit"
    ]
    
    y_pos = result.shape[0] - 140
    for text in help_text:
        cv2.putText(result, text, (result.shape[1] - 300, y_pos), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
        y_pos += 30
    
    return result

def main():
    # Try to open webcam
    cap = cv2.VideoCapture(0)
    
    # If webcam fails, use video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/ocean_waves.mp4')
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    # Initialize recorder
    recorder = VideoRecorder(output_dir='recordings')
    
    print("=" * 60)
    print("Video Recording Example")
    print("=" * 60)
    print("This example shows how to record processed video to file.")
    print(f"\nRecordings will be saved to: {recorder.output_dir}/")
    print(f"Codec: {recorder.codec}")
    print(f"Frame rate: {recorder.fps} fps")
    print(f"Resolution: {recorder.frame_size[0]}x{recorder.frame_size[1]}")
    print("\nControls:")
    print("  SPACE - Start/stop recording")
    print("  F     - Cycle through filters")
    print("  S     - Save screenshot")
    print("  Q     - Quit")
    print("=" * 60)
    
    while True:
        ret, frame = cap.read()
        
        if not ret:
            # Loop video
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue
        
        # Resize frame
        frame = cv2.resize(frame, recorder.frame_size)
        
        # Apply current filter
        filter_func, filter_name = recorder.get_current_filter()
        processed = filter_func(frame)
        
        # Draw UI
        display = draw_ui(processed, recorder, filter_name)
        
        # Write frame if recording
        if recorder.recording:
            recorder.write_frame(processed)
        
        # Show display
        cv2.imshow('Video Recording', display)
        
        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord(' '):  # Space bar
            recorder.toggle_recording()
        elif key == ord('f'):
            recorder.cycle_filter()
        elif key == ord('s'):
            recorder.save_screenshot(processed)
        elif key == ord('r'):
            # Stop current recording and start new one
            if recorder.recording:
                recorder.stop_recording()
            recorder.start_recording()
    
    # Cleanup
    recorder.cleanup()
    cap.release()
    cv2.destroyAllWindows()
    
    print("\n" + "=" * 60)
    print("Recording session complete!")
    print(f"Check the '{recorder.output_dir}' folder for your recordings.")
    print("=" * 60)

if __name__ == "__main__":
    main()
