"""
Color Object Tracker
Track colored objects and draw bounding boxes around them

This example demonstrates how to detect and track colored objects.
Students will learn to:
- Create color masks in HSV color space
- Find contours in the mask
- Filter contours by area
- Draw bounding boxes around detected objects
- Calculate and display object centroids

Key Concepts:
- cv2.findContours() finds shapes in binary images
- cv2.contourArea() measures the size of detected objects
- cv2.boundingRect() gets the bounding box coordinates
- cv2.moments() calculates the center point (centroid)

Usage:
- Show blue objects to the camera to track them
- Press 'q' to quit
"""

import cv2
import numpy as np

def color_object_tracker():
    """Track colored objects and draw bounding boxes"""

    # Open webcam
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    print("\nCOLOR OBJECT TRACKER")
    print("=" * 50)
    print("Tracking blue objects")
    print("Press 'q' to quit")
    print("=" * 50 + "\n")

    # Define blue color range in HSV
    lower_blue = np.array([100, 50, 50])
    upper_blue = np.array([130, 255, 255])

    while True:
        # Read frame
        ret, frame = cap.read()

        if not ret:
            break

        # Flip frame horizontally for mirror effect
        frame = cv2.flip(frame, 1)

        # Convert to HSV color space
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Create color mask
        mask = cv2.inRange(hsv, lower_blue, upper_blue)

        # Clean up mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kernel)

        # Find contours (shapes) in the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Track how many objects we found
        object_count = 0

        # Process each contour
        for contour in contours:
            # Calculate area of the contour
            area = cv2.contourArea(contour)

            # Filter out small contours (noise)
            if area < 500:
                continue

            object_count += 1

            # Get bounding box coordinates
            x, y, w, h = cv2.boundingRect(contour)

            # Calculate centroid (center point)
            M = cv2.moments(contour)
            if M["m00"] != 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
            else:
                cx, cy = x + w // 2, y + h // 2

            # Draw bounding box (green rectangle)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            # Draw centroid (blue circle)
            cv2.circle(frame, (cx, cy), 7, (255, 0, 0), -1)

            # Show area above bounding box
            cv2.putText(frame, f"Area: {int(area)}", (x, y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Show object count
        cv2.putText(frame, f"Objects: {object_count}", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Display
        cv2.imshow('Color Object Tracker', frame)

        # Quit on 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Clean up
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    color_object_tracker()
