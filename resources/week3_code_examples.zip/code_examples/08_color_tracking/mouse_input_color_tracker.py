"""
Simple Color Tracker
Track and highlight a specific color in the webcam feed

This example demonstrates basic color tracking using HSV color space.
Students will learn to:
- Convert BGR to HSV color space
- Select colors by clicking on the webcam feed
- Create color masks with tolerance ranges
- Apply masks to isolate specific colors

Key Concepts:
- HSV (Hue, Saturation, Value) is better for color tracking than BGR
- Mouse click interaction to pick colors
- cv2.inRange() creates a binary mask for colors in a range
- Morphological operations clean up the mask
- cv2.bitwise_and() applies the mask to show only the tracked color

Usage:
- Click on the webcam feed to select a color to track
- The program will track similar colors within a tolerance range
- Press 'q' to quit
"""

import cv2
import numpy as np

# Global variables for mouse callback
selected_color = None
selected_hsv = None
click_position = None

def mouse_callback(event, x, y, flags, param):
    """
    Handle mouse click events to select color

    Args:
        event: Type of mouse event
        x, y: Mouse position
        flags: Additional flags
        param: Additional parameters (hsv frame in this case)
    """
    global selected_color, selected_hsv, click_position

    if event == cv2.EVENT_LBUTTONDOWN:
        # Get the HSV frame from param
        hsv_frame = param['hsv']
        bgr_frame = param['bgr']

        # Get the HSV value at the clicked position (convert to proper numpy array)
        selected_hsv = np.array(hsv_frame[y, x], dtype=np.uint8)
        selected_color = np.array(bgr_frame[y, x], dtype=np.uint8)
        click_position = (x, y)

        print(f"Selected color - HSV: {selected_hsv}, BGR: {selected_color}")

def simple_color_tracker():
    """Track a specific color selected by mouse click"""

    global selected_color, selected_hsv

    # Open webcam
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    # Create window
    window_name = 'Simple Color Tracker'
    cv2.namedWindow(window_name)

    # Default to blue color
    selected_hsv = np.array([110, 150, 150], dtype=np.uint8)
    selected_color = np.array([255, 0, 0], dtype=np.uint8)  # BGR

    print("\nSIMPLE COLOR TRACKER")
    print("=" * 50)
    print("Click on the webcam feed to select a color to track")
    print("The program will track similar colors")
    print("Press 'q' to quit")
    print("=" * 50 + "\n")

    # Color tolerance (how much variation to accept)
    h_tolerance = 10
    s_tolerance = 50
    v_tolerance = 50

    while True:
        # Read frame
        ret, frame = cap.read()

        if not ret:
            break

        # Flip frame horizontally for mirror effect
        frame = cv2.flip(frame, 1)

        # Convert frame to HSV color space
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Set mouse callback with current HSV frame
        cv2.setMouseCallback(window_name, mouse_callback,
                            {'hsv': hsv, 'bgr': frame})

        # Create color mask based on selected color
        if selected_hsv is not None:
            # Calculate lower and upper bounds with tolerance
            lower = np.array([
                max(0, int(selected_hsv[0]) - h_tolerance),
                max(0, int(selected_hsv[1]) - s_tolerance),
                max(0, int(selected_hsv[2]) - v_tolerance)
            ], dtype=np.uint8)
            upper = np.array([
                min(179, int(selected_hsv[0]) + h_tolerance),
                min(255, int(selected_hsv[1]) + s_tolerance),
                min(255, int(selected_hsv[2]) + v_tolerance)
            ], dtype=np.uint8)

            mask = cv2.inRange(hsv, lower, upper)

            # Clean up mask with morphological operations
            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)   # Remove noise
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)  # Fill holes

            # Apply mask to original frame
            result = cv2.bitwise_and(frame, frame, mask=mask)
        else:
            mask = np.zeros(frame.shape[:2], dtype=np.uint8)
            result = frame.copy()

        # Show all three views side-by-side
        mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        combined = cv2.hconcat([frame, mask_bgr, result])

        # Add labels
        cv2.putText(combined, "Original - Click to Select", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(combined, "Mask", (frame.shape[1] + 10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(combined, "Result", (frame.shape[1] * 2 + 10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # Draw a color indicator square showing the selected color
        if selected_color is not None:
            # Draw a square in the top-right corner
            square_size = 80
            square_x = frame.shape[1] - square_size - 10
            square_y = 50

            # Draw on the combined image (adjusted x position)
            color_bgr = (int(selected_color[0]), int(selected_color[1]), int(selected_color[2]))
            cv2.rectangle(combined, (square_x, square_y),
                         (square_x + square_size, square_y + square_size),
                         color_bgr, -1)

            # Draw border around the square
            cv2.rectangle(combined, (square_x, square_y),
                         (square_x + square_size, square_y + square_size),
                         (255, 255, 255), 2)

            # Add label
            cv2.putText(combined, "Tracking", (square_x, square_y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Display
        cv2.imshow(window_name, combined)

        # Quit on 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Clean up
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    simple_color_tracker()
