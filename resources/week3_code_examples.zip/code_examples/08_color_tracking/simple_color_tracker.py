"""
Simple Color Tracker
Basic demonstration of color tracking using HSV color space

This example demonstrates the fundamentals of color tracking.
Students will learn to:
- Convert BGR to HSV color space
- Define color ranges with lower and upper bounds
- Create binary masks to isolate colors
- Apply masks to show only the tracked color

Key Concepts:
- HSV (Hue, Saturation, Value) is better for color tracking than BGR
- cv2.inRange() creates a mask for colors within a range
- Lower and upper bounds define what colors to track
- White pixels in mask = color found, black = color not found

Usage:
- The program tracks blue colors by default
- Modify lower_color and upper_color to track different colors
- Press 'q' to quit
"""

import cv2
import numpy as np

# Open webcam
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera")
    exit()

# Define color to track (HSV values)
# These values will track blue colors
lower_color = np.array([100, 50, 50])   # Lower bound: dark blue
upper_color = np.array([130, 255, 255])  # Upper bound: bright blue

print("Simple Color Tracker - Tracking Blue")
print("Press 'q' to quit")

while True:
    # Read frame from webcam
    ret, frame = cap.read()

    if not ret:
        break

    # Flip frame horizontally for mirror effect
    frame = cv2.flip(frame, 1)

    # Convert from BGR to HSV color space
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Create mask: white where color is found, black elsewhere
    mask = cv2.inRange(hsv, lower_color, upper_color)

    # Apply mask to original frame to show only the tracked color
    result = cv2.bitwise_and(frame, frame, mask=mask)

    # Display in separate windows
    cv2.imshow('Original', frame)
    cv2.imshow('Tracked Color', result)

    # Quit on 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Clean up
cap.release()
cv2.destroyAllWindows()
