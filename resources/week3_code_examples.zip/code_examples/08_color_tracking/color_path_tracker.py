"""
Color Path Tracker
Track the motion path of a colored object

This example demonstrates how to track and visualize an object's path.
Students will learn to:
- Track a colored object over time
- Store position history using deque
- Draw motion trails
- Visualize object movement paths

Key Concepts:
- deque (double-ended queue) efficiently stores recent positions
- maxlen parameter automatically limits history size
- Drawing lines between consecutive points creates a trail
- Trail thickness can vary to show time (older = thinner)

Usage:
- Move a blue object in front of the camera
- The program will draw its motion path
- Press 'r' to reset the path
- Press 'q' to quit
"""

import cv2
import numpy as np
from collections import deque

def color_path_tracker():
    """Track colored object and draw motion path"""

    # Open webcam
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    print("\nCOLOR PATH TRACKER")
    print("=" * 50)
    print("Track motion path of blue object")
    print("Press 'r' to reset path")
    print("Press 'q' to quit")
    print("=" * 50 + "\n")

    # Define blue color range in HSV
    lower_blue = np.array([100, 50, 50])
    upper_blue = np.array([130, 255, 255])

    # Store path points (keep last 100 positions)
    path_points = deque(maxlen=100)

    while True:
        # Read frame
        ret, frame = cap.read()

        if not ret:
            break

        # Flip frame horizontally for mirror effect
        frame = cv2.flip(frame, 1)

        # Convert to HSV color space
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Create color mask
        mask = cv2.inRange(hsv, lower_blue, upper_blue)

        # Clean up mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kernel)

        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Find the largest contour (main object)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)

            # Only track if object is big enough
            if area > 500:
                # Calculate centroid (center point)
                M = cv2.moments(largest_contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])

                    # Add current position to path
                    path_points.append((cx, cy))

                    # Draw current position (red circle)
                    cv2.circle(frame, (cx, cy), 10, (0, 0, 255), -1)

        # Draw the motion path
        for i in range(1, len(path_points)):
            # Calculate line thickness (older points = thinner)
            thickness = int(np.sqrt(100 / float(i + 1)) * 2.5)

            # Draw line from previous point to current point
            cv2.line(frame, path_points[i - 1], path_points[i], (255, 0, 0), thickness)

        # Show instructions and info
        cv2.putText(frame, "Press 'r' to reset path", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, f"Path points: {len(path_points)}", (10, 60),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # Display
        cv2.imshow('Color Path Tracker', frame)

        # Handle keyboard input
        key = cv2.waitKey(1) & 0xFF

        if key == ord('q'):
            break
        elif key == ord('r'):
            # Clear the path
            path_points.clear()
            print("Path reset")

    # Clean up
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    color_path_tracker()
