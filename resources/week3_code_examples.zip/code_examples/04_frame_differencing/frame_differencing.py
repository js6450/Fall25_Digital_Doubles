"""
Frame Differencing
Basic motion detection using frame differencing

This example demonstrates the fundamental concept of motion detection
by comparing consecutive frames. Students will learn:
- How to calculate differences between frames
- Thresholding to identify significant changes
- Basic motion visualization
- Understanding temporal information in video

Key Concepts:
- Frame differencing algorithm
- Temporal analysis
- Threshold selection
- Motion visualization techniques

The method works by:
1. Converting frames to grayscale
2. Computing absolute difference between consecutive frames
3. Applying threshold to identify significant changes
4. Visualizing motion regions

Usage:
- 't' to adjust threshold (cycles through preset values)
- 'r' to reset to original video
- 'q' to quit
"""

import cv2
import numpy as np

def detect_motion_simple(frame1, frame2, threshold=25):
    """
    Simple motion detection using frame differencing
    
    Args:
        frame1: First frame (previous frame)
        frame2: Second frame (current frame)
        threshold: Threshold value for detecting motion (default: 25)
    
    Returns:
        diff: Binary image showing motion regions
    """
    # Convert both frames to grayscale
    gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    
    # Compute absolute difference
    frame_diff = cv2.absdiff(gray1, gray2)
    
    # Apply threshold to get binary image
    _, thresh = cv2.threshold(frame_diff, threshold, 255, cv2.THRESH_BINARY)
    
    return frame_diff, thresh

def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)
    
    # If webcam fails, use a video file with motion
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        # Use video with clear motion
        cap = cv2.VideoCapture('../Resources/walking_on_the_beach.mp4')
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    # Read first frame
    ret, prev_frame = cap.read()
    if not ret:
        print("Error: Could not read first frame")
        return
    
    # Resize for consistent display
    prev_frame = cv2.resize(prev_frame, (640, 480))
    
    # Threshold values to cycle through
    thresholds = [15, 25, 40, 60]
    threshold_index = 1  # Start with 25
    current_threshold = thresholds[threshold_index]
    
    print("Frame Differencing - Basic Motion Detection")
    print("=" * 50)
    print("This example shows motion by comparing consecutive frames")
    print("\nControls:")
    print("  't' - Cycle through threshold values")
    print("  'q' - Quit")
    print(f"\nCurrent threshold: {current_threshold}")
    print("=" * 50)
    
    while True:
        # Read current frame
        ret, current_frame = cap.read()
        
        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret, prev_frame = cap.read()
            prev_frame = cv2.resize(prev_frame, (640, 480))
            continue
        
        # Resize frame
        current_frame = cv2.resize(current_frame, (640, 480))
        
        # Detect motion
        frame_diff, motion_mask = detect_motion_simple(
            prev_frame, current_frame, current_threshold
        )
        
        # Create visualization
        # Convert grayscale difference to BGR for display
        diff_colored = cv2.cvtColor(frame_diff, cv2.COLOR_GRAY2BGR)
        motion_colored = cv2.cvtColor(motion_mask, cv2.COLOR_GRAY2BGR)
        
        # Create motion overlay (show motion in red on original frame)
        motion_overlay = current_frame.copy()
        motion_overlay[motion_mask > 0] = [0, 0, 255]  # Red for motion
        
        # Blend original with motion overlay
        result = cv2.addWeighted(current_frame, 0.7, motion_overlay, 0.3, 0)
        
        # Add text information
        cv2.putText(result, f"Threshold: {current_threshold}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        # Calculate motion percentage
        motion_pixels = np.sum(motion_mask > 0)
        total_pixels = motion_mask.shape[0] * motion_mask.shape[1]
        motion_percent = (motion_pixels / total_pixels) * 100
        
        cv2.putText(result, f"Motion: {motion_percent:.1f}%", 
                   (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        # Create a 2x2 grid showing different views
        # Row 1: Original current frame | Frame difference
        # Row 2: Motion mask | Motion overlay
        top_row = np.hstack([current_frame, diff_colored])
        bottom_row = np.hstack([motion_colored, result])
        display = np.vstack([top_row, bottom_row])
        
        # Add labels to each quadrant
        cv2.putText(display, "Original", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(display, "Frame Difference", (650, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(display, "Motion Mask", (10, 510), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(display, "Motion Overlay", (650, 510), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Show the display
        cv2.imshow('Frame Differencing', display)
        
        # Update previous frame
        prev_frame = current_frame.copy()
        
        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('t'):
            # Cycle through thresholds
            threshold_index = (threshold_index + 1) % len(thresholds)
            current_threshold = thresholds[threshold_index]
            print(f"Threshold changed to: {current_threshold}")
    
    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nMotion detection stopped.")

if __name__ == "__main__":
    main()
