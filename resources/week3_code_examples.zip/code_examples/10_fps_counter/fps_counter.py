"""
FPS Counter Example
Simple demonstration of calculating and displaying FPS (frames per second) on video

Key Concepts:
- Measuring time between frames
- Calculating FPS from frame time
- Displaying FPS on video frame
- Using time.time() for performance measurement

FPS Calculation:
- Track time of each frame
- Calculate time difference between frames
- FPS = 1 / time_per_frame
- Average over multiple frames for stability
"""

import cv2
import time

def display_fps(frame, fps, position='top_right'):
    """
    Display FPS counter on a video frame

    Args:
        frame: The video frame to draw on
        fps: The FPS value to display
        position: Where to display ('top_right', 'top_left', 'bottom_right', 'bottom_left')

    Returns:
        frame: The frame with FPS text drawn on it
    """
    height, width = frame.shape[:2]
    text = f"FPS: {fps:.1f}"
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    thickness = 2
    color = (0, 255, 0)  # Green

    # Get text size for positioning
    (text_width, text_height), baseline = cv2.getTextSize(text, font, font_scale, thickness)

    # Calculate position based on parameter
    if position == 'top_right':
        x = width - text_width - 10
        y = text_height + 10
    elif position == 'top_left':
        x = 10
        y = text_height + 10
    elif position == 'bottom_right':
        x = width - text_width - 10
        y = height - 10
    elif position == 'bottom_left':
        x = 10
        y = height - 10
    else:
        x = width - text_width - 10
        y = text_height + 10

    # Draw text on frame
    cv2.putText(frame, text, (x, y), font, font_scale, color, thickness)

    return frame

def capture_webcam(camera_index=0):
    """
    Capture webcam feed and display FPS counter

    Args:
        camera_index: Index of the camera to use (default 0)
    """
    cap = cv2.VideoCapture(camera_index)

    if not cap.isOpened():
        print(f"Error: Could not open webcam at index {camera_index}")
        return

    print("=" * 50)
    print("FPS COUNTER DEMO")
    print("=" * 50)
    print("Webcam started... Press 'q' to quit")
    print("=" * 50)
    print()

    # Variables for FPS calculation
    prev_time = time.time()
    fps = 0

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Error: Failed to capture frame")
            break

        # Calculate FPS
        current_time = time.time()
        time_diff = current_time - prev_time
        prev_time = current_time

        # Calculate FPS (frames per second)
        if time_diff > 0:
            fps = 1.0 / time_diff

        # Display FPS on the frame
        frame = display_fps(frame, fps, position='top_right')

        # Show the frame
        cv2.imshow('Webcam with FPS Counter', frame)

        # Exit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("Webcam capture stopped by user")
            break

    cap.release()
    cv2.destroyAllWindows()

def main():
    """Main function to run the webcam with FPS display"""
    camera_index = 0
    capture_webcam(camera_index)

if __name__ == "__main__":
    main()
