# Week 3 Code Examples
## Video Processing & Live Video Capture

This folder contains 10 comprehensive code examples for Week 3, covering video capture fundamentals, real-time effects, motion detection, and interactive controls.

---

## Table of Contents

### **Fundamentals (Examples 01-03)**
- [01 - Video Capture Basics](#01-video-capture-basics)
- [02 - Video Keyboard Effects](#02-video-keyboard-effects)
- [03 - Trackbar Controls](#03-trackbar-controls)

### **Motion Detection (Examples 04-06)**
- [04 - Frame Differencing](#04-frame-differencing)
- [05 - Motion Detection Complete](#05-motion-detection-complete)
- [06 - Background Subtraction](#06-background-subtraction)

### **Effects & Tracking (Examples 07-08)**
- [07 - Mirror and Flip Effects](#07-mirror-and-flip-effects)
- [08 - Color Tracking](#08-color-tracking)

### **Recording & Performance (Examples 09-10)**
- [09 - Video Recording](#09-video-recording)
- [10 - FPS Counter](#10-fps-counter)

---

## Example Descriptions

### 01: Video Capture Basics
**Files:**
- `01_video_capture_basics/webcam_player.py`
- `01_video_capture_basics/video_player.py`

**Topics:**
- Reading video from webcam
- Playing video files
- Getting video properties
- Basic video playback controls

**Features:**
- Simple webcam capture and display
- Video file playback
- Display webcam information (resolution, FPS)
- Clean, foundational examples

**Key Functions:**
- `cv2.VideoCapture()` - Open camera or video file
- `cap.read()` - Read frames
- `cap.get(cv2.CAP_PROP_*)` - Get video properties

---

### 02: Video Keyboard Effects
**Files:**
- `02_video_keyboard_effects/video_keyboard_effects.py` - Original version with multiple effects
- `02_video_keyboard_effects/video_keyboard_effect_switcher.py` - Simplified spacebar switcher

**Topics:**
- Applying filters to video in real-time
- Keyboard controls for effect switching
- Multiple filter implementations
- Real-time video processing pipeline

**Features (video_keyboard_effects.py):**
- Press 'b' for blur effect
- Press 'e' for edge detection
- Press 'g' for grayscale
- Press 's' for sharpening
- Press 'n' for negative
- Press 'o' for original
- Press 'q' to quit

**Features (video_keyboard_effect_switcher.py):**
- Press SPACE to cycle through effects: Original → Gray → Blur → Edges
- Simplified interface with single key control
- Great for beginners learning effect switching

**Key Concepts:**
- Frame-by-frame filter application
- User interaction for effect switching
- Performance considerations in real-time processing

---

### 03: Trackbar Controls
**File:** `03_trackbar_controls/trackbar_controls.py`

**Topics:**
- Creating trackbars (sliders) for parameter control
- Reading trackbar values in real-time
- Applying effects based on slider position
- Simple interactive video control

**Features:**
- Single blur effect demonstration
- Slider to control blur amount (kernel size)
- Real-time parameter feedback on video
- Clean, focused example for learning trackbar basics

**Key Functions:**
- `cv2.createTrackbar()` - Create a slider control
- `cv2.getTrackbarPos()` - Read current slider value
- `cv2.GaussianBlur()` - Apply blur effect

---

### 04: Frame Differencing
**File:** `04_frame_differencing/frame_differencing.py`

**Topics:**
- Frame-by-frame comparison
- Temporal differencing
- Basic motion detection
- Threshold adjustment

**Features:**
- Simple frame differencing algorithm
- Adjustable threshold for sensitivity
- Motion visualization
- Real-time processing from webcam

**Key Concepts:**
- Comparing consecutive frames
- Detecting changes over time
- Foundation for motion detection

---

### 05: Motion Detection Complete
**Files:**
- `05_motion_detection_complete/motion_detection_complete.py` - Full-featured motion detection
- `05_motion_detection_complete/motion_detection_template.py` - Template for practice
- `05_motion_detection_complete/motion_particle.py` - Creative particle effect based on motion

**Topics:**
- Advanced motion detection
- Contour detection
- Bounding boxes around moving objects
- Motion region tracking
- Particle systems triggered by motion

**Features:**
- Detect moving objects in video
- Draw bounding boxes around motion
- Count detected objects
- Filter by minimum area
- Template file for practice
- **NEW: motion_particle.py** - Spawns randomly sized, colored particles where motion is detected with fade-out effects

**Key Functions:**
- `cv2.absdiff()` - Calculate frame difference
- `cv2.threshold()` - Apply threshold
- `cv2.findContours()` - Find object contours
- `cv2.boundingRect()` - Get bounding box coordinates
- Particle class with lifespan and physics

---

### 06: Background Subtraction
**Files:**
- `06_background_subtraction/background_subtraction.py`
- `06_background_subtraction/background_subtraction_template.py`

**Topics:**
- Background modeling
- Foreground extraction
- MOG2 and KNN algorithms
- Adaptive learning

**Features:**
- Adaptive background learning
- Multiple algorithms (MOG2, KNN)
- Morphological operations for noise reduction
- Real-time foreground extraction
- Template file for practice

**Key Functions:**
- `cv2.createBackgroundSubtractorMOG2()` - MOG2 algorithm
- `cv2.createBackgroundSubtractorKNN()` - KNN algorithm
- `apply()` - Extract foreground mask

---

### 07: Mirror and Flip Effects
**Files:**
- `07_mirror_and_flip_effects/mirror_and_flip_effects.py` - Original comprehensive version
- `07_mirror_and_flip_effects/flip_webcam.py` - Simple flip controls
- `07_mirror_and_flip_effects/kaleidoscope.py` - Kaleidoscope effect only

**Topics:**
- Horizontal flip (mirror)
- Vertical flip
- Combined flips
- Creative symmetry effects

**Features (mirror_and_flip_effects.py):**
- All flip modes in one program
- Kaleidoscope, mirror splits, multi-mirror effects
- Press 1-9 to switch between modes

**Features (flip_webcam.py):**
- Simplified version focusing on basic flips
- Press '1' for Original
- Press '2' for Horizontal Flip (mirror)
- Press '3' for Vertical Flip (upside down)
- Press '4' for Both Axes (rotate 180°)

**Features (kaleidoscope.py):**
- Dedicated kaleidoscope effect program
- Creates 4-way symmetrical patterns
- Great for understanding geometric transformations

**Key Functions:**
- `cv2.flip()` - Flip frames horizontally or vertically
- `cv2.hconcat()`, `cv2.vconcat()` - Concatenate images

---

### 08: Color Tracking
**Files:**
- `08_color_tracking/color_tracking.py` - Original comprehensive version with menu
- `08_color_tracking/simple_color_tracker.py` - **NEW:** Minimal demonstration (no UI)
- `08_color_tracking/mouse_input_color_tracker.py` - **NEW:** Click-to-select color tracker
- `08_color_tracking/color_object_tracker.py` - **NEW:** Tracks objects with bounding boxes
- `08_color_tracking/color_path_tracker.py` - **NEW:** Tracks and visualizes motion paths

**Topics:**
- HSV color space
- Color range detection
- Object tracking by color
- Movement trail visualization
- Mouse input for color selection

**Features by File:**

**simple_color_tracker.py** (Best for beginners):
- Minimal, clean code (~50 lines)
- Two variables to modify: lower_color and upper_color
- Shows original and tracked color in separate windows
- Default tracks blue colors

**mouse_input_color_tracker.py**:
- Click on webcam feed to select any color
- Shows selected color in indicator square
- Automatic tolerance ranges
- Three views: Original, Mask, Result

**color_object_tracker.py**:
- Detects and tracks multiple colored objects
- Draws green bounding boxes around objects
- Shows blue centroids (center points)
- Displays object count and area

**color_path_tracker.py**:
- Tracks motion path of colored objects
- Draws blue motion trail with varying thickness
- Stores last 100 positions
- Press 'r' to reset path

**Key Functions:**
- `cv2.cvtColor()` - Convert BGR to HSV
- `cv2.inRange()` - Create color mask
- `cv2.moments()` - Find object center
- `cv2.findContours()` - Find object shapes
- `cv2.setMouseCallback()` - Handle mouse clicks

---

### 09: Video Recording
**File:** `09_video_recording/video_recording.py`

**Topics:**
- Recording from webcam
- VideoWriter usage
- Codec selection
- Start/stop recording controls

**Features:**
- Toggle recording with keyboard (press 'r')
- Display recording indicator on screen
- Frame counter
- Timestamped output files
- Save videos in MP4 format

**Key Functions:**
- `cv2.VideoWriter()` - Create video writer
- `cv2.VideoWriter_fourcc()` - Specify video codec
- `out.write()` - Write frame to video file

---

### 10: FPS Counter
**File:** `10_fps_counter/fps_counter.py`

**Topics:**
- Calculating FPS (frames per second)
- Measuring time between frames
- Displaying performance metrics on video
- Using `time.time()` for performance measurement

**Features:**
- Simple FPS calculation and display
- Reusable `display_fps()` function
- Flexible positioning (top_right, top_left, bottom_right, bottom_left)
- Real-time FPS counter on webcam feed
- Clean, focused example for learning FPS basics

**Key Concepts:**
- FPS = 1 / time_per_frame
- Time measurement using `time.time()`
- Text positioning with `cv2.getTextSize()`

---

## Running the Examples

### Prerequisites
```bash
pip install opencv-python numpy
```

### Running an Example
```bash
cd Week3/code_examples/01_video_capture_basics
python webcam_player.py
```

### Using Sample Videos
Sample videos are provided in the `Resources/` folder:
- `ocean_waves.mp4`
- `walking_on_the_beach.mp4`
- `soccer.mp4`
- `ice_hockey.mp4`
- And more...

---

## Example Progression

### Recommended Learning Order:

**Beginner (Start Here):**
1. **01 - Video Capture Basics** - Learn to capture and display video
2. **02 - Video Keyboard Effects** - Apply filters with keyboard controls
3. **07 - Mirror and Flip Effects** - Simple geometric transformations

**Intermediate:**
4. **03 - Trackbar Controls** - Interactive parameter adjustment
5. **04 - Frame Differencing** - Introduction to motion detection
6. **05 - Motion Detection Complete** - Full motion detection pipeline
7. **09 - Video Recording** - Save video to files
8. **10 - FPS Counter** - Measure performance

**Advanced:**
9. **06 - Background Subtraction** - Advanced motion detection
10. **08 - Color Tracking** - Track objects by color

---

## Key Concepts by Example

### Video I/O Fundamentals
- Examples: 01, 09

### Real-time Filters & Effects
- Examples: 02, 03, 07

### Motion Analysis
- Examples: 04, 05, 06

### User Interaction
- Examples: 02, 03, 07, 08

### Color Spaces
- Examples: 02, 08

### Performance Monitoring
- Examples: 10

---

## Common Issues & Solutions

### Camera Not Opening
```python
# Try different camera indices
cap = cv2.VideoCapture(0)  # Default camera
cap = cv2.VideoCapture(1)  # External camera
```

### Video File Not Found
- Check file path is correct
- Use absolute paths or relative to script location
- Ensure video format is supported (mp4, avi, mov)

### Slow Performance
- Reduce video resolution
- Simplify processing effects
- See Example 10 for FPS monitoring

### Codec Issues (Recording)
```python
# Try different FourCC codes
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # MPEG-4
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Xvid
fourcc = cv2.VideoWriter_fourcc(*'MJPG')  # Motion JPEG
```

---

## Template Files

Some examples include template files for practice:
- `05_motion_detection_complete/motion_detection_template.py`
- `06_background_subtraction/background_subtraction_template.py`

These templates have sections for you to complete, helping you learn by doing!

## New Simplified Examples

Several examples now have simplified versions for easier learning:

**Beginner-Friendly Files:**
- `02_video_keyboard_effects/video_keyboard_effect_switcher.py` - Simple spacebar effect switcher
- `07_mirror_and_flip_effects/flip_webcam.py` - Basic flip controls only
- `07_mirror_and_flip_effects/kaleidoscope.py` - Standalone kaleidoscope effect
- `08_color_tracking/simple_color_tracker.py` - Minimal color tracking demonstration

**Specialized Features:**
- `05_motion_detection_complete/motion_particle.py` - Creative particle system
- `08_color_tracking/mouse_input_color_tracker.py` - Interactive color selection
- `08_color_tracking/color_object_tracker.py` - Object detection focus
- `08_color_tracking/color_path_tracker.py` - Path visualization focus

---

## Lab Assignment Support

These examples directly support **Lab Assignment 2: Video Processing Pipeline**.

**Recommended examples for Lab 2:**
- **Video basics:** 01
- **Effects:** 02, 03
- **Motion detection:** 04, 05
- **Recording:** 09
- **Interactive controls:** 02, 03, 07

---

## Additional Resources

- [OpenCV Video I/O Documentation](https://docs.opencv.org/master/dd/d00/tutorial_table_of_content_video_io.html)
- [Week 3 Lecture Notes](../Week3_Lecture_Notes.md)
- [Course Google Drive](https://drive.google.com/drive/folders/1QBC_GxFM-6KoTL7bqZjC76_r6MVasSG8)

---

## Credits

Examples created for **DM-GY 9201 B: Digital Doubles**
NYU Tandon School of Engineering
Instructor: Jiwon Shin
Fall 2025

---

**Last Updated:** November 6, 2025
