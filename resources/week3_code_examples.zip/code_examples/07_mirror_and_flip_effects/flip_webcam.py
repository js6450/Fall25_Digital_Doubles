"""
Flip Webcam
Simple webcam flip effects controlled by number keys

This example demonstrates basic image flipping operations.
Students will learn to:
- Apply horizontal, vertical, and both axis flips
- Switch between flip modes using keyboard input
- Understand cv2.flip() flipCode parameter values

Key Concepts:
- cv2.flip(frame, flipCode):
  - flipCode = 1: Horizontal flip (mirror)
  - flipCode = 0: Vertical flip (upside down)
  - flipCode = -1: Both axes (rotate 180°)
- Real-time video manipulation
- Keyboard event handling

Usage:
- Press '1' for Original (no flip)
- Press '2' for Horizontal Flip (mirror)
- Press '3' for Vertical Flip (upside down)
- Press '4' for Both Axes (rotate 180°)
- Press 'q' to quit
"""

import cv2

def main():
    """Main function for flip webcam demo"""

    # Try to open webcam
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    # Flip modes: (name, flipCode)
    # flipCode: 1=horizontal, 0=vertical, -1=both, None=original
    modes = {
        '1': ('Original', None),
        '2': ('Horizontal Flip', 1),
        '3': ('Vertical Flip', 0),
        '4': ('Both Axes', -1)
    }

    current_mode = '1'

    print("\n" + "=" * 60)
    print("FLIP WEBCAM")
    print("=" * 60)
    print("\nControls:")
    print("  1 - Original (no flip)")
    print("  2 - Horizontal Flip (mirror)")
    print("  3 - Vertical Flip (upside down)")
    print("  4 - Both Axes (rotate 180°)")
    print("  Q - Quit")
    print("=" * 60 + "\n")

    while True:
        # Read frame from webcam
        ret, frame = cap.read()

        if not ret:
            print("Error reading frame")
            break

        # Get current mode settings
        mode_name, flip_code = modes[current_mode]

        # Apply flip effect
        if flip_code is None:
            # Original - no flip
            result = frame.copy()
        else:
            # Apply flip using cv2.flip()
            result = cv2.flip(frame, flip_code)

        # Add mode indicator text
        cv2.putText(result, f"Mode: {mode_name}", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Add instruction text
        cv2.putText(result, "Press 1-4 to change modes, Q to quit",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        # Display the result
        cv2.imshow('Flip Webcam', result)

        # Handle keyboard input
        key = cv2.waitKey(1) & 0xFF

        # Quit on 'q'
        if key == ord('q'):
            break

        # Switch modes on number keys 1-4
        elif chr(key) in modes:
            current_mode = chr(key)
            mode_name, _ = modes[current_mode]
            print(f"Switched to: {mode_name}")

    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nFlip webcam stopped.")


if __name__ == "__main__":
    main()
