"""
Kaleidoscope Effect
Creates a kaleidoscope pattern using image flipping

This example demonstrates how to create a kaleidoscope effect by:
- Extracting a quadrant from the video feed
- Flipping it in different directions
- Combining the flipped quadrants into a symmetrical pattern

Key Concepts:
- Image quadrant extraction using array slicing
- Multiple flip operations (horizontal, vertical, both)
- Image concatenation (hconcat and vconcat)
- Creating symmetrical patterns from video

Understanding the kaleidoscope effect:
- Top-left quadrant: Original
- Top-right quadrant: Horizontal flip of top-left
- Bottom-left quadrant: Vertical flip of top-left
- Bottom-right quadrant: Both flips of top-left

Usage:
- Press 'q' to quit
"""

import cv2

def create_kaleidoscope(frame):
    """
    Create a kaleidoscope effect using flipping

    Args:
        frame: Input frame

    Returns:
        Kaleidoscope frame with 4-way symmetry
    """
    h, w = frame.shape[:2]

    # Take top-left quadrant (1/4 of the frame)
    quadrant = frame[:h//2, :w//2]

    # Create four quadrants with different flips
    top_left = quadrant                      # Original
    top_right = cv2.flip(quadrant, 1)        # Horizontal flip
    bottom_left = cv2.flip(quadrant, 0)      # Vertical flip
    bottom_right = cv2.flip(quadrant, -1)    # Both flips

    # Combine horizontally: top row and bottom row
    top_half = cv2.hconcat([top_left, top_right])
    bottom_half = cv2.hconcat([bottom_left, bottom_right])

    # Combine vertically: top half and bottom half
    result = cv2.vconcat([top_half, bottom_half])

    return result


def main():
    """Main function for kaleidoscope effect"""

    # Try to open webcam
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    print("\n" + "=" * 60)
    print("KALEIDOSCOPE EFFECT")
    print("=" * 60)
    print("\nThe video feed is divided into quadrants and flipped")
    print("to create a symmetrical kaleidoscope pattern.")
    print("\nControls:")
    print("  Q - Quit")
    print("=" * 60 + "\n")

    while True:
        # Read frame from webcam
        ret, frame = cap.read()

        if not ret:
            print("Error reading frame")
            break

        # Apply kaleidoscope effect
        result = create_kaleidoscope(frame)

        # Add title text
        cv2.putText(result, "Kaleidoscope Effect", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Add instruction text
        cv2.putText(result, "Press Q to quit",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        # Display the result
        cv2.imshow('Kaleidoscope', result)

        # Handle keyboard input
        key = cv2.waitKey(1) & 0xFF

        # Quit on 'q'
        if key == ord('q'):
            break

    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nKaleidoscope effect stopped.")


if __name__ == "__main__":
    main()
