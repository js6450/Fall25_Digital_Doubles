"""
Motion Detection Template
A simplified motion detection system for applying visual effects

This template provides a clean starting point for creating motion-based
visual effects. Students can modify the apply_effect() function to create
custom effects that respond to detected motion.

Usage:
- Modify apply_effect() to create your own motion-based effects
- Press 'q' to quit
"""

import cv2
import numpy as np

class MotionDetector:
    """Simple motion detection system"""

    def __init__(self, threshold=25, min_area=500):
        """
        Initialize motion detector

        Args:
            threshold: Threshold for binary motion mask
            min_area: Minimum contour area to be considered motion
        """
        self.threshold = threshold
        self.min_area = min_area
        self.prev_frame = None

    def detect(self, frame):
        """
        Detect motion in current frame

        Args:
            frame: Current video frame (BGR)

        Returns:
            motion_mask: Binary mask of motion regions
            has_motion: Boolean indicating if motion was detected
            motion_amount: Percentage of frame with motion (0-100)
        """
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        # If this is the first frame, store it and return
        if self.prev_frame is None:
            self.prev_frame = gray
            return None, False, 0

        # Compute absolute difference
        frame_diff = cv2.absdiff(self.prev_frame, gray)

        # Apply threshold
        _, motion_mask = cv2.threshold(frame_diff, self.threshold, 255, cv2.THRESH_BINARY)

        # Apply morphological operations to reduce noise
        kernel_erode = np.ones((3, 3), np.uint8)
        motion_mask = cv2.erode(motion_mask, kernel_erode, iterations=1)

        kernel_dilate = np.ones((5, 5), np.uint8)
        motion_mask = cv2.dilate(motion_mask, kernel_dilate, iterations=2)

        # Calculate motion amount (percentage of pixels with motion)
        motion_pixels = cv2.countNonZero(motion_mask)
        total_pixels = motion_mask.shape[0] * motion_mask.shape[1]
        motion_amount = (motion_pixels / total_pixels) * 100

        # Check if significant motion detected
        has_motion = motion_amount > 0.5  # More than 0.5% of frame

        # Update previous frame
        self.prev_frame = gray

        return motion_mask, has_motion, motion_amount


def apply_effect(frame, motion_mask, has_motion, motion_amount):
    """
    Apply visual effects based on motion detection

    MODIFY THIS FUNCTION to create your own motion-based effects!

    Args:
        frame: Original video frame
        motion_mask: Binary mask showing where motion occurred
        has_motion: Boolean - True if motion was detected
        motion_amount: Float - Percentage of frame with motion (0-100)

    Returns:
        Modified frame with effects applied
    """
    result = frame.copy()

    # Example Effect 1: Highlight motion areas in red
    if has_motion:
        # Create red overlay where motion is detected
        red_overlay = np.zeros_like(frame)
        red_overlay[:, :, 2] = motion_mask  # Red channel

        # Blend the red overlay with the original frame
        result = cv2.addWeighted(result, 1.0, red_overlay, 0.3, 0)

    # Example Effect 2: Add motion intensity indicator
    intensity_color = (0, 255, 0) if has_motion else (100, 100, 100)
    cv2.putText(result, f"Motion: {motion_amount:.1f}%", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, intensity_color, 2)

    # Example Effect 3: Draw motion intensity bar
    bar_width = int((motion_amount / 100) * 300)
    cv2.rectangle(result, (10, 50), (310, 70), (50, 50, 50), -1)  # Background
    cv2.rectangle(result, (10, 50), (10 + bar_width, 70), (0, 255, 0), -1)  # Bar

    return result


def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)

    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/soccer.mp4')

    if not cap.isOpened():
        print("Error: Could not open video source")
        return

    # Initialize motion detector
    detector = MotionDetector(threshold=25, min_area=500)

    print("Motion Detection Template")
    print("=" * 50)
    print("Modify the apply_effect() function to create")
    print("your own motion-based visual effects!")
    print("\nControls:")
    print("  'q' - Quit")
    print("=" * 50)

    while True:
        # Read frame
        ret, frame = cap.read()

        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            detector.prev_frame = None  # Reset detector
            continue

        # Resize frame while maintaining aspect ratio
        height, width = frame.shape[:2]
        max_width = 800
        aspect_ratio = width / height
        main_width = max_width
        main_height = int(main_width / aspect_ratio)
        frame = cv2.resize(frame, (main_width, main_height))

        # Detect motion
        motion_mask, has_motion, motion_amount = detector.detect(frame)

        # Skip first frame (no previous frame to compare)
        if motion_mask is None:
            continue

        # Apply custom effects based on motion
        result = apply_effect(frame, motion_mask, has_motion, motion_amount)

        # Display result
        cv2.imshow('Motion Detection Template', result)

        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF

        if key == ord('q'):
            break

    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nMotion detection stopped.")


if __name__ == "__main__":
    main()
