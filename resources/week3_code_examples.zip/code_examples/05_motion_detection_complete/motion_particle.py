"""
Motion Particle Effect
Displays particles as randomly sized circles where motion is detected

This example demonstrates how to create a particle system that responds
to motion detection. Students will learn to:
- Create a Particle class with random properties
- Spawn particles at motion detection locations
- Manage a collection of particles with lifespans
- Combine motion detection with creative visual effects

Key Concepts:
- Object-oriented particle systems
- Random particle generation
- Lifespan-based particle management
- Motion-triggered visual effects

Usage:
- Move in front of the camera to generate particles
- Press 'q' to quit
"""

import cv2
import numpy as np
import random

class Particle:
    """Particle class that displays a randomly sized circle"""

    def __init__(self, x, y):
        """
        Initialize a particle at the given position

        Args:
            x: X-coordinate of the particle
            y: Y-coordinate of the particle
        """
        self.x = x
        self.y = y
        # Random radius between 5 and 30 pixels
        self.radius = random.randint(5, 30)
        # Random color (BGR format)
        self.color = (
            random.randint(100, 255),  # Blue
            random.randint(100, 255),  # Green
            random.randint(100, 255)   # Red
        )
        # Random velocity for movement
        self.vx = random.uniform(-2, 2)
        self.vy = random.uniform(-2, 2)
        # Lifespan (frames)
        self.lifespan = random.randint(30, 90)
        self.age = 0

    def update(self):
        """Update particle position and age"""
        self.x += self.vx
        self.y += self.vy
        self.age += 1

    def is_alive(self):
        """Check if particle is still alive"""
        return self.age < self.lifespan

    def get_alpha(self):
        """Calculate alpha value based on age (fade out over time)"""
        return 1.0 - (self.age / self.lifespan)

    def draw(self, frame):
        """
        Draw the particle on the frame

        Args:
            frame: The frame to draw on
        """
        if self.is_alive():
            # Calculate alpha for fading effect
            alpha = self.get_alpha()

            # Create a copy for blending
            overlay = frame.copy()

            # Draw circle on overlay
            cv2.circle(overlay, (int(self.x), int(self.y)),
                      self.radius, self.color, -1)

            # Blend with original frame
            cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)


class MotionDetector:
    """Simple motion detection system"""

    def __init__(self, threshold=25, min_area=500):
        """
        Initialize motion detector

        Args:
            threshold: Threshold for binary motion mask
            min_area: Minimum contour area to be considered motion
        """
        self.threshold = threshold
        self.min_area = min_area
        self.prev_frame = None

    def detect(self, frame):
        """
        Detect motion in current frame

        Args:
            frame: Current video frame (BGR)

        Returns:
            motion_mask: Binary mask of motion regions
            has_motion: Boolean indicating if motion was detected
            motion_amount: Percentage of frame with motion (0-100)
        """
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        # If this is the first frame, store it and return
        if self.prev_frame is None:
            self.prev_frame = gray
            return None, False, 0

        # Compute absolute difference
        frame_diff = cv2.absdiff(self.prev_frame, gray)

        # Apply threshold
        _, motion_mask = cv2.threshold(frame_diff, self.threshold, 255, cv2.THRESH_BINARY)

        # Apply morphological operations to reduce noise
        kernel_erode = np.ones((3, 3), np.uint8)
        motion_mask = cv2.erode(motion_mask, kernel_erode, iterations=1)

        kernel_dilate = np.ones((5, 5), np.uint8)
        motion_mask = cv2.dilate(motion_mask, kernel_dilate, iterations=2)

        # Calculate motion amount (percentage of pixels with motion)
        motion_pixels = cv2.countNonZero(motion_mask)
        total_pixels = motion_mask.shape[0] * motion_mask.shape[1]
        motion_amount = (motion_pixels / total_pixels) * 100

        # Check if significant motion detected
        has_motion = motion_amount > 0.5  # More than 0.5% of frame

        # Update previous frame
        self.prev_frame = gray

        return motion_mask, has_motion, motion_amount


def apply_particle_effect(frame, motion_mask, particles):
    """
    Apply particle effects based on motion detection

    Args:
        frame: Original video frame
        motion_mask: Binary mask showing where motion occurred
        particles: List of active particles

    Returns:
        Modified frame with particles drawn
    """
    result = frame.copy()

    # Spawn new particles at motion locations
    if motion_mask is not None:
        # Find coordinates where motion is detected
        motion_points = np.column_stack(np.where(motion_mask > 0))

        # Spawn particles at random motion locations (limit spawn rate)
        if len(motion_points) > 0:
            num_new_particles = min(5, len(motion_points) // 100)  # Spawn rate
            for _ in range(num_new_particles):
                # Pick random motion point
                idx = random.randint(0, len(motion_points) - 1)
                y, x = motion_points[idx]
                # Create new particle
                particles.append(Particle(x, y))

    # Update and draw all particles
    for particle in particles:
        particle.update()
        particle.draw(result)

    # Remove dead particles
    particles[:] = [p for p in particles if p.is_alive()]

    # Display particle count
    cv2.putText(result, f"Particles: {len(particles)}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    return result


def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)

    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/soccer.mp4')

    if not cap.isOpened():
        print("Error: Could not open video source")
        return

    # Initialize motion detector
    detector = MotionDetector(threshold=25, min_area=500)

    # Initialize particle list
    particles = []

    print("Motion Particle Effect")
    print("=" * 50)
    print("Particles will appear where motion is detected!")
    print("\nControls:")
    print("  'q' - Quit")
    print("=" * 50)

    while True:
        # Read frame
        ret, frame = cap.read()

        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            detector.prev_frame = None  # Reset detector
            particles.clear()  # Clear particles
            continue

        # Resize frame while maintaining aspect ratio
        height, width = frame.shape[:2]
        max_width = 800
        aspect_ratio = width / height
        main_width = max_width
        main_height = int(main_width / aspect_ratio)
        frame = cv2.resize(frame, (main_width, main_height))

        # Detect motion
        motion_mask, has_motion, motion_amount = detector.detect(frame)

        # Apply particle effects
        result = apply_particle_effect(frame, motion_mask, particles)

        # Display result
        cv2.imshow('Motion Particle Effect', result)

        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF

        if key == ord('q'):
            break

    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nMotion particle effect stopped.")


if __name__ == "__main__":
    main()
