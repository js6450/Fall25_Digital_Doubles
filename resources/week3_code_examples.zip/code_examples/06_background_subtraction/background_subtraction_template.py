"""
Background Subtraction Template (MOG2)
A simplified template for creating visual effects with background subtraction

This template uses MOG2 (Mixture of Gaussians) background subtraction to
separate foreground (moving objects) from background. Students can modify
the apply_effect() function to create custom visual effects.

Background subtraction learns what the background looks like over time and
identifies anything that doesn't match as foreground (moving objects).

Usage:
- Modify apply_effect() to create your own background-based effects
- Press 'r' to reset the background model
- Press 'q' to quit
"""

import cv2
import numpy as np


class BackgroundSubtractor:
    """Simple background subtraction using MOG2"""

    def __init__(self):
        """Initialize MOG2 background subtractor"""
        self.subtractor = cv2.createBackgroundSubtractorMOG2(
            history=500,           # Number of frames to learn from
            varThreshold=16,       # Sensitivity (lower = more sensitive)
            detectShadows=True     # Detect shadows (appear gray in mask)
        )
        self.learning_rate = -1  # -1 = automatic learning rate

    def apply(self, frame):
        """
        Apply background subtraction to frame

        Args:
            frame: Input video frame (BGR)

        Returns:
            fg_mask: Foreground mask (white = foreground, black = background, gray = shadows)
            fg_clean: Cleaned foreground mask (shadows removed, noise reduced)
        """
        # Apply background subtraction
        fg_mask = self.subtractor.apply(frame, learningRate=self.learning_rate)

        # Create cleaned version: remove shadows and noise
        fg_clean = fg_mask.copy()

        # Remove shadows (gray pixels with value 127)
        fg_clean[fg_clean == 127] = 0

        # Apply morphological operations to reduce noise
        kernel = np.ones((3, 3), np.uint8)

        # Remove small noise
        fg_clean = cv2.morphologyEx(fg_clean, cv2.MORPH_OPEN, kernel, iterations=1)

        # Fill small holes
        fg_clean = cv2.morphologyEx(fg_clean, cv2.MORPH_CLOSE, kernel, iterations=2)

        return fg_mask, fg_clean

    def reset(self):
        """Reset the background model"""
        self.subtractor = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=16, detectShadows=True
        )


def apply_effect(frame, fg_mask, fg_clean):
    """
    Apply visual effects using background subtraction

    MODIFY THIS FUNCTION to create your own background-based effects!

    Args:
        frame: Original video frame
        fg_mask: Raw foreground mask (includes shadows as gray)
        fg_clean: Cleaned foreground mask (binary: white = foreground, black = background)

    Returns:
        Modified frame with effects applied
    """
    result = frame.copy()

    # Example Effect 1: Extract only foreground objects (remove background)
    foreground_only = cv2.bitwise_and(frame, frame, mask=fg_clean)

    # Example Effect 2: Create colored background
    # Make background blue, keep foreground normal
    background_color = np.full_like(frame, (200, 100, 50))  # BGR: brownish-blue
    background = cv2.bitwise_and(background_color, background_color, mask=cv2.bitwise_not(fg_clean))

    # Combine foreground and colored background
    result = cv2.add(foreground_only, background)

    # Example Effect 3: Add outline around foreground objects
    # Find contours of foreground
    contours, _ = cv2.findContours(fg_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Draw contours
    cv2.drawContours(result, contours, -1, (0, 255, 0), 2)

    # Count and display number of foreground objects
    num_objects = len([c for c in contours if cv2.contourArea(c) > 100])
    cv2.putText(result, f"Foreground Objects: {num_objects}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    return result


def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)

    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/ice_hockey.mp4')

    if not cap.isOpened():
        print("Error: Could not open video source")
        return

    # Initialize background subtractor
    bg_subtractor = BackgroundSubtractor()

    print("Background Subtraction Template (MOG2)")
    print("=" * 50)
    print("Modify the apply_effect() function to create")
    print("your own background-based visual effects!")
    print("\nTip: Stay still for a few seconds at the start")
    print("     to let the system learn the background.")
    print("\nControls:")
    print("  'r' - Reset background model")
    print("  'q' - Quit")
    print("=" * 50)

    while True:
        # Read frame
        ret, frame = cap.read()

        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        # Resize frame while maintaining aspect ratio
        height, width = frame.shape[:2]
        max_width = 800
        aspect_ratio = width / height
        main_width = max_width
        main_height = int(main_width / aspect_ratio)
        frame = cv2.resize(frame, (main_width, main_height))

        # Apply background subtraction
        fg_mask, fg_clean = bg_subtractor.apply(frame)

        # Apply custom effects
        result = apply_effect(frame, fg_mask, fg_clean)

        # Display result
        cv2.imshow('Background Subtraction Template', result)

        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF

        if key == ord('q'):
            break
        elif key == ord('r'):
            bg_subtractor.reset()
            print("Background model reset - stay still to learn new background")

    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nBackground subtraction stopped.")


if __name__ == "__main__":
    main()
