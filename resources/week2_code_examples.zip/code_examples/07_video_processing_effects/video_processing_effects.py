"""
Week 2 - Example 07: Video Processing Effects
Applying filters to video in real-time

This example demonstrates how to apply various image processing filters
to video streams in real-time. Students will learn to:
- Process video frames as they are captured
- Apply multiple filters (blur, edge detection, etc.)
- Switch between different effects using keyboard input
- Handle real-time video processing efficiently

Key Concepts:
- Real-time video processing pipeline
- Frame-by-frame filter application
- User interaction for effect switching
- Performance considerations

Usage:
- Press 'b' for blur effect
- Press 'e' for edge detection
- Press 'g' for grayscale
- Press 's' for sharpening
- Press 'n' for negative
- Press 'o' for original
- Press 'q' to quit
"""

import cv2
import numpy as np

def apply_blur(frame):
    """Apply Gaussian blur to the frame"""
    return cv2.GaussianBlur(frame, (15, 15), 0)

def apply_edge_detection(frame):
    """Apply Canny edge detection to the frame"""
    # Convert to grayscale first
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Apply Canny edge detection
    edges = cv2.Canny(gray, 50, 150)
    # Convert back to BGR for display
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

def apply_grayscale(frame):
    """Convert frame to grayscale"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Convert back to BGR for display
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

def apply_sharpening(frame):
    """Apply sharpening filter to the frame"""
    # Create sharpening kernel
    kernel = np.array([[-1, -1, -1],
                       [-1,  9, -1],
                       [-1, -1, -1]])
    return cv2.filter2D(frame, -1, kernel)

def apply_negative(frame):
    """Apply negative/invert effect"""
    return cv2.bitwise_not(frame)

def main():
    # Try to open webcam first (index 0)
    cap = cv2.VideoCapture(0)
    
    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        # Use relative path to Resources folder
        cap = cv2.VideoCapture('../Resources/ocean_waves.mp4')
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    # Dictionary to store effect names and their functions
    effects = {
        'o': ('Original', lambda x: x),
        'b': ('Blur', apply_blur),
        'e': ('Edge Detection', apply_edge_detection),
        'g': ('Grayscale', apply_grayscale),
        's': ('Sharpening', apply_sharpening),
        'n': ('Negative', apply_negative)
    }
    
    # Start with original (no effect)
    current_effect = 'o'
    
    print("Video Processing Effects")
    print("=" * 50)
    print("Controls:")
    print("  'b' - Blur effect")
    print("  'e' - Edge detection")
    print("  'g' - Grayscale")
    print("  's' - Sharpening")
    print("  'n' - Negative")
    print("  'o' - Original (no effect)")
    print("  'q' - Quit")
    print("=" * 50)
    
    while True:
        # Read frame from video
        ret, frame = cap.read()
        
        # If frame is not read successfully (end of video), loop back
        if not ret:
            # Reset video to beginning
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue
        
        # Resize frame for better display (optional)
        frame = cv2.resize(frame, (640, 480))
        
        # Apply current effect
        effect_name, effect_function = effects[current_effect]
        processed_frame = effect_function(frame)
        
        # Add text overlay showing current effect
        cv2.putText(processed_frame, f"Effect: {effect_name}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   1, (0, 255, 0), 2)
        
        # Display the processed frame
        cv2.imshow('Video Processing Effects', processed_frame)
        
        # Wait for key press (1ms)
        key = cv2.waitKey(1) & 0xFF
        
        # Check for effect change
        if key in effects.keys():
            current_effect = chr(key)
            print(f"Switched to: {effects[current_effect][0]}")
        
        # Quit if 'q' is pressed
        elif key == ord('q'):
            break
    
    # Release video capture and close windows
    cap.release()
    cv2.destroyAllWindows()
    print("Video processing stopped.")

if __name__ == "__main__":
    main()
