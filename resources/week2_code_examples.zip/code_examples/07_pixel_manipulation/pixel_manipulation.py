"""
Pixel Manipulation
Digital Doubles - Week 1

This script demonstrates direct pixel manipulation:
- Accessing individual pixel values
- Modifying single pixels
- Creating colored regions
- Splitting and merging color channels
- Channel swapping for creative effects

Understanding pixel-level operations is fundamental to image processing.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Pixel Manipulation Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/pinkflower.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    height, width = img.shape[:2]
    print(f"✓ Image loaded: {width}x{height} pixels")
    print()
    
    # Display original
    cv2.imshow('Original Image', img)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== ACCESSING PIXELS ==========
    print("1. ACCESSING PIXEL VALUES")
    print("=" * 60)
    print()
    
    # Access a single pixel
    y, x = 100, 100
    pixel = img[y, x]
    
    print(f"Pixel at position ({y}, {x}):")
    print(f"  BGR values: {pixel}")
    print(f"  Blue:  {pixel[0]}")
    print(f"  Green: {pixel[1]}")
    print(f"  Red:   {pixel[2]}")
    print()
    print("Remember: OpenCV uses BGR order, not RGB!")
    print("Remember: Coordinates are [y, x], not [x, y]!")
    print()
    
    # Access multiple pixels
    print("Accessing a region of pixels [50:100, 50:100]:")
    region = img[50:100, 50:100]
    print(f"  Shape: {region.shape}")
    print(f"  This is a 50x50 pixel region")
    print()
    
    input("Press Enter to continue...")
    print()
    
    # ========== MODIFYING SINGLE PIXELS ==========
    print("2. MODIFYING SINGLE PIXELS")
    print("=" * 60)
    print()
    
    # Make a copy so we don't modify the original
    img_modified = img.copy()
    
    # Set a single pixel to red
    print("Setting pixel at (100, 100) to red [0, 0, 255]")
    img_modified[100, 100] = [0, 0, 255]  # BGR: Red
    
    # Draw a small cross to make it visible
    for i in range(-2, 3):
        img_modified[100+i, 100] = [0, 0, 255]
        img_modified[100, 100+i] = [0, 0, 255]
    
    cv2.imshow('2. Single Pixel Modified (red cross)', img_modified)
    print("Look for the tiny red cross")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CREATING COLORED REGIONS ==========
    print("3. CREATING COLORED REGIONS")
    print("=" * 60)
    print()
    
    img_regions = img.copy()
    
    # Red square
    print("Creating colored squares...")
    img_regions[50:150, 50:150] = [0, 0, 255]  # Red (BGR)
    print("  ✓ Red square at (50:150, 50:150)")
    
    # Green square
    img_regions[200:300, 200:300] = [0, 255, 0]  # Green
    print("  ✓ Green square at (200:300, 200:300)")
    
    # Blue square
    img_regions[50:150, 200:300] = [255, 0, 0]  # Blue
    print("  ✓ Blue square at (50:150, 200:300)")
    
    # Yellow square (Red + Green)
    img_regions[200:300, 50:150] = [0, 255, 255]  # Yellow
    print("  ✓ Yellow square at (200:300, 50:150)")
    
    cv2.imshow('3. Colored Regions', img_regions)
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== DRAWING PATTERNS ==========
    print("4. DRAWING PATTERNS")
    print("=" * 60)
    print()
    
    img_pattern = img.copy()
    
    # Create a checkerboard pattern
    print("Creating a checkerboard pattern...")
    square_size = 30
    for i in range(0, height, square_size * 2):
        for j in range(0, width, square_size * 2):
            # White squares
            img_pattern[i:i+square_size, j:j+square_size] = [255, 255, 255]
            img_pattern[i+square_size:i+square_size*2, 
                       j+square_size:j+square_size*2] = [255, 255, 255]
            # Black squares
            img_pattern[i:i+square_size, j+square_size:j+square_size*2] = [0, 0, 0]
            img_pattern[i+square_size:i+square_size*2, j:j+square_size] = [0, 0, 0]
    
    cv2.imshow('4. Checkerboard Pattern', img_pattern)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CHANNEL SPLITTING ==========
    print("5. SPLITTING COLOR CHANNELS")
    print("=" * 60)
    print()
    
    print("Splitting image into B, G, R channels...")
    b, g, r = cv2.split(img)
    
    print(f"Original shape: {img.shape}")
    print(f"Blue channel shape: {b.shape}")
    print(f"Each channel is now a 2D grayscale image")
    print()
    
    # Display each channel
    cv2.imshow('5a. Blue Channel', b)
    cv2.imshow('5b. Green Channel', g)
    cv2.imshow('5c. Red Channel', r)
    
    print("Each channel shows where that color is strong:")
    print("  - Bright areas = lots of that color")
    print("  - Dark areas = little of that color")
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CHANNEL MANIPULATION ==========
    print("6. MANIPULATING INDIVIDUAL CHANNELS")
    print("=" * 60)
    print()
    
    # Zero out the red channel
    print("a) Removing red channel (setting to 0)...")
    img_no_red = img.copy()
    img_no_red[:, :, 2] = 0  # Red is channel 2
    cv2.imshow('6a. No Red Channel', img_no_red)
    print("   Notice the image looks cyan/green")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Enhance green channel
    print("b) Boosting green channel...")
    img_enhanced = img.copy()
    img_enhanced[:, :, 1] = np.clip(img_enhanced[:, :, 1].astype(np.int16) * 1.5, 
                                      0, 255).astype(np.uint8)
    cv2.imshow('6b. Enhanced Green', img_enhanced)
    print("   Green tones are more vibrant")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Invert one channel
    print("c) Inverting red channel...")
    img_inverted = img.copy()
    img_inverted[:, :, 2] = 255 - img_inverted[:, :, 2]
    cv2.imshow('6c. Inverted Red Channel', img_inverted)
    print("   Creates an interesting artistic effect")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CHANNEL MERGING ==========
    print("7. MERGING CHANNELS")
    print("=" * 60)
    print()
    
    # Split again for clean manipulation
    b, g, r = cv2.split(img)
    
    # Merge in original order
    print("a) Merging in original order [B, G, R]...")
    merged_original = cv2.merge([b, g, r])
    cv2.imshow('7a. Original Order', merged_original)
    print("   Same as original image")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Swap red and blue
    print("b) Swapping red and blue channels [R, G, B]...")
    swapped_rb = cv2.merge([r, g, b])
    cv2.imshow('7b. Red ↔ Blue Swapped', swapped_rb)
    print("   Creates a color-shifted effect")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # All channels swapped
    print("c) Rotating all channels [G, R, B]...")
    rotated = cv2.merge([g, r, b])
    cv2.imshow('7c. All Channels Rotated', rotated)
    print("   Totally different color palette")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Use only one channel for all
    print("d) Using only red channel for all [R, R, R]...")
    single_channel = cv2.merge([r, r, r])
    cv2.imshow('7d. Red Channel Only', single_channel)
    print("   Creates a grayscale image based on red channel")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CREATIVE EFFECTS ==========
    print("8. CREATIVE EFFECTS")
    print("=" * 60)
    print()
    
    # Color tint
    print("a) Adding a color tint (cyan)...")
    img_tinted = img.copy()
    img_tinted[:, :, 0] = np.clip(img_tinted[:, :, 0].astype(np.int16) + 50, 
                                   0, 255).astype(np.uint8)  # More blue
    img_tinted[:, :, 1] = np.clip(img_tinted[:, :, 1].astype(np.int16) + 50, 
                                   0, 255).astype(np.uint8)  # More green
    cv2.imshow('8a. Cyan Tint', img_tinted)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Posterization effect
    print("b) Posterization (reducing color levels)...")
    img_poster = img.copy()
    img_poster = (img_poster // 64) * 64  # Reduce to 4 levels per channel
    cv2.imshow('8b. Posterized', img_poster)
    print("   Creates a poster-like effect with fewer colors")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SAVING ==========
    print("9. SAVING MANIPULATED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_colored_regions.jpg', img_regions)
    cv2.imwrite('output_channel_swapped.jpg', swapped_rb)
    cv2.imwrite('output_no_red.jpg', img_no_red)
    cv2.imwrite('output_posterized.jpg', img_poster)
    
    print("✓ Saved 4 manipulated images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Access pixels: img[y, x] (note: y first!)")
    print("  - Modify pixels: img[y, x] = [B, G, R]")
    print("  - Access regions: img[y1:y2, x1:x2]")
    print("  - Split channels: b, g, r = cv2.split(img)")
    print("  - Merge channels: merged = cv2.merge([b, g, r])")
    print("  - Access single channel: img[:, :, channel_index]")
    print("  - Pixel manipulation enables endless creative effects!")
    print("=" * 60)

if __name__ == "__main__":
    main()
