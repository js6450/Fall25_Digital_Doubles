"""
Week 2 - Example 06: Video Properties
Digital Doubles - DM-GY 9201 B

This example demonstrates how to get and set video capture properties
in OpenCV. Understanding these properties is essential for controlling
video capture behavior and optimizing performance.

Topics covered:
1. Getting video/camera properties (resolution, FPS, format, etc.)
2. Setting properties (when supported by the camera)
3. Understanding property limitations
4. Practical applications of property manipulation

Press 'q' to quit at any time
"""

import cv2
import numpy as np
import os

def display_all_properties(cap, source_name="Video"):
    """Display all available properties for a video capture object"""
    print(f"\n{source_name} Properties:")
    print("=" * 60)
    
    # Dictionary of common OpenCV capture properties
    properties = {
        cv2.CAP_PROP_FRAME_WIDTH: "Frame Width",
        cv2.CAP_PROP_FRAME_HEIGHT: "Frame Height",
        cv2.CAP_PROP_FPS: "Frames Per Second",
        cv2.CAP_PROP_FRAME_COUNT: "Total Frame Count",
        cv2.CAP_PROP_BRIGHTNESS: "Brightness",
        cv2.CAP_PROP_CONTRAST: "Contrast",
        cv2.CAP_PROP_SATURATION: "Saturation",
        cv2.CAP_PROP_HUE: "Hue",
        cv2.CAP_PROP_GAIN: "Gain",
        cv2.CAP_PROP_EXPOSURE: "Exposure",
        cv2.CAP_PROP_AUTO_EXPOSURE: "Auto Exposure",
        cv2.CAP_PROP_AUTOFOCUS: "Auto Focus",
        cv2.CAP_PROP_FOCUS: "Focus",
        cv2.CAP_PROP_ZOOM: "Zoom",
        cv2.CAP_PROP_BACKEND: "Backend",
        cv2.CAP_PROP_BUFFERSIZE: "Buffer Size"
    }
    
    for prop_id, prop_name in properties.items():
        value = cap.get(prop_id)
        # Only display if value is valid (not -1 or 0 for unsupported properties)
        if value >= 0:
            if prop_name in ["Frame Width", "Frame Height", "Total Frame Count", "Buffer Size"]:
                print(f"  {prop_name:.<40} {int(value)}")
            else:
                print(f"  {prop_name:.<40} {value:.2f}")


def explore_video_file_properties():
    """Explore properties of a video file"""
    print("\n" + "=" * 60)
    print("PART 1: Video File Properties")
    print("=" * 60)
    
    # Get the path to the Resources folder
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resources_path = os.path.join(script_dir, '..', 'Resources')
    
    # Find a video file
    video_files = [f for f in os.listdir(resources_path) 
                   if f.endswith(('.mp4', '.avi', '.mov'))]
    
    if not video_files:
        print("No video files found in Resources folder.")
        return None
    
    video_path = os.path.join(resources_path, video_files[0])
    print(f"Analyzing: {video_files[0]}")
    
    # Open video
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        print("Error: Could not open video file")
        return None
    
    # Display all properties
    display_all_properties(cap, "Video File")
    
    # Calculate additional useful information
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    print("\nCalculated Information:")
    print("=" * 60)
    print(f"  Duration: {frame_count/fps:.2f} seconds ({frame_count/fps/60:.2f} minutes)")
    print(f"  Aspect Ratio: {width/height:.2f}:1")
    print(f"  Total Pixels per Frame: {width * height:,}")
    print(f"  Approximate File Processing Rate: {width * height * fps / 1_000_000:.2f} megapixels/sec")
    
    # Demonstrate seeking to different positions
    print("\n" + "=" * 60)
    print("Frame Position Control:")
    print("=" * 60)
    
    # Get frame at 25%, 50%, 75% of video
    positions = [0.25, 0.50, 0.75]
    
    for pos in positions:
        frame_pos = int(frame_count * pos)
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_pos)
        ret, frame = cap.read()
        
        if ret:
            # Add position info to frame
            cv2.putText(frame, f'{int(pos*100)}% through video', (20, 50),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, f'Frame {frame_pos}/{frame_count}', (20, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            cv2.imshow(f'Video at {int(pos*100)}%', frame)
            print(f"Showing frame at {int(pos*100)}% (frame {frame_pos})")
            print("Press any key to continue...")
            cv2.waitKey(0)
            cv2.destroyWindow(f'Video at {int(pos*100)}%')
    
    cap.release()
    return True


def explore_webcam_properties():
    """Explore and modify webcam properties"""
    print("\n" + "=" * 60)
    print("PART 2: Webcam Properties")
    print("=" * 60)
    
    # Open webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Error: Could not access webcam")
        print("Skipping webcam properties demonstration.")
        return False
    
    print("Webcam opened successfully!")
    
    # Display current properties
    display_all_properties(cap, "Webcam")
    
    # Try to set different resolutions
    print("\n" + "=" * 60)
    print("Testing Resolution Changes:")
    print("=" * 60)
    
    resolutions = [
        (640, 480, "VGA"),
        (1280, 720, "HD 720p"),
        (1920, 1080, "Full HD 1080p"),
        (320, 240, "QVGA")
    ]
    
    print("\nAttempting to set different resolutions...")
    print("(Note: Not all cameras support all resolutions)")
    
    for width, height, name in resolutions:
        # Try to set resolution
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        
        # Check what resolution we actually got
        actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        success = (actual_width == width and actual_height == height)
        status = "✓" if success else "✗"
        
        print(f"  {status} {name:.<20} Requested: {width}x{height}, Got: {actual_width}x{actual_height}")
    
    # Interactive property adjustment
    print("\n" + "=" * 60)
    print("Interactive Property Control:")
    print("=" * 60)
    print("\nControls:")
    print("  'q' - Quit")
    print("  '1' - Decrease brightness")
    print("  '2' - Increase brightness")
    print("  '3' - Decrease contrast")
    print("  '4' - Increase contrast")
    print("  '5' - Reset to defaults")
    print("  'r' - Reset resolution to 640x480")
    
    # Set initial resolution
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    brightness = cap.get(cv2.CAP_PROP_BRIGHTNESS)
    contrast = cap.get(cv2.CAP_PROP_CONTRAST)
    
    while True:
        ret, frame = cap.read()
        
        if not ret:
            print("Error reading from webcam")
            break
        
        # Get current properties
        current_brightness = cap.get(cv2.CAP_PROP_BRIGHTNESS)
        current_contrast = cap.get(cv2.CAP_PROP_CONTRAST)
        current_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        current_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # Display property info on frame
        info_y = 30
        cv2.putText(frame, f'Resolution: {current_width}x{current_height}', 
                   (10, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        info_y += 30
        
        if current_brightness >= 0:
            cv2.putText(frame, f'Brightness: {current_brightness:.2f}', 
                       (10, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            info_y += 30
        
        if current_contrast >= 0:
            cv2.putText(frame, f'Contrast: {current_contrast:.2f}', 
                       (10, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            info_y += 30
        
        cv2.putText(frame, 'Press 1-5 to adjust', 
                   (10, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        cv2.imshow('Webcam Properties', frame)
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('1'):  # Decrease brightness
            new_val = max(0, current_brightness - 10)
            cap.set(cv2.CAP_PROP_BRIGHTNESS, new_val)
            print(f"Brightness: {current_brightness:.2f} → {new_val:.2f}")
        elif key == ord('2'):  # Increase brightness
            new_val = min(255, current_brightness + 10)
            cap.set(cv2.CAP_PROP_BRIGHTNESS, new_val)
            print(f"Brightness: {current_brightness:.2f} → {new_val:.2f}")
        elif key == ord('3'):  # Decrease contrast
            new_val = max(0, current_contrast - 10)
            cap.set(cv2.CAP_PROP_CONTRAST, new_val)
            print(f"Contrast: {current_contrast:.2f} → {new_val:.2f}")
        elif key == ord('4'):  # Increase contrast
            new_val = min(255, current_contrast + 10)
            cap.set(cv2.CAP_PROP_CONTRAST, new_val)
            print(f"Contrast: {current_contrast:.2f} → {new_val:.2f}")
        elif key == ord('5'):  # Reset
            cap.set(cv2.CAP_PROP_BRIGHTNESS, brightness)
            cap.set(cv2.CAP_PROP_CONTRAST, contrast)
            print("Reset to defaults")
        elif key == ord('r'):  # Reset resolution
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            print("Reset resolution to 640x480")
    
    cap.release()
    cv2.destroyAllWindows()
    return True


def main():
    print("Video Properties")
    print("=" * 60)
    print("\nThis example explores video capture properties in OpenCV.")
    print("You'll learn how to get and set various video/camera properties.")
    
    # Part 1: Video file properties
    video_success = explore_video_file_properties()
    
    if video_success:
        input("\nPress Enter to continue to webcam properties...")
    
    # Part 2: Webcam properties
    webcam_success = explore_webcam_properties()
    
    # Summary
    print("\n" + "=" * 60)
    print("Key Takeaways:")
    print("=" * 60)
    print("GETTING PROPERTIES:")
    print("  • cap.get(cv2.CAP_PROP_XXX) - Get property value")
    print("  • Common properties: WIDTH, HEIGHT, FPS, FRAME_COUNT")
    print("  • Returns -1 or 0 if property not supported")
    print()
    print("SETTING PROPERTIES:")
    print("  • cap.set(cv2.CAP_PROP_XXX, value) - Set property")
    print("  • Not all properties can be set")
    print("  • Camera hardware limitations apply")
    print("  • Always verify with cap.get() after setting")
    print()
    print("IMPORTANT NOTES:")
    print("  • Video files: Can read properties, cannot set them")
    print("  • Webcams: Can usually set some properties")
    print("  • Property support varies by camera/driver")
    print("  • Some properties are read-only")
    print()
    print("PRACTICAL USES:")
    print("  • Optimize resolution for performance")
    print("  • Calculate video duration and file info")
    print("  • Jump to specific frames in video")
    print("  • Adjust camera settings for better capture")
    print("=" * 60)

if __name__ == "__main__":
    main()
