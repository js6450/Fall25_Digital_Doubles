"""
Week 2 - Example 03: Sharpening Filters
Digital Doubles - DM-GY 9201 B

This example demonstrates image sharpening techniques that enhance edges
and fine details in images. Two main approaches are covered:
1. Unsharp masking (professional technique)
2. Sharpening kernels (direct convolution)

Sharpening is the opposite of blurring - it emphasizes transitions
between light and dark regions to make images appear more crisp.

Press any key to advance through examples.
Press 'q' to quit at any time.
"""

import cv2
import numpy as np
import os

def main():
    # Get the path to the Resources folder
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resources_path = os.path.join(script_dir, '..', 'Resources')
    
    # Load an image that will benefit from sharpening
    img_path = os.path.join(resources_path, 'mountain.jpg')
    img = cv2.imread(img_path)
    
    if img is None:
        print(f"Error: Could not load image from {img_path}")
        print("Make sure the Resources folder contains mountain.jpg")
        return
    
    print("Sharpening Filters")
    print("=" * 50)
    print("\nSharpening enhances edges and fine details.")
    print("Two main techniques:")
    print("1. Unsharp Masking - Professional technique")
    print("2. Sharpening Kernels - Direct approach\n")
    print("Press any key to see each technique")
    print("Press 'q' to quit\n")
    
    # Show original
    cv2.imshow('Original Image', img)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 1. UNSHARP MASKING
    # ========================================
    print("\n1. UNSHARP MASKING")
    print("-" * 50)
    print("Professional technique used in photo editing:")
    print("1. Create blurred version of image")
    print("2. Subtract blur from original to get 'mask'")
    print("3. Add mask back to original (weighted)")
    
    # Blur the image
    blurred = cv2.GaussianBlur(img, (0, 0), 3)
    
    # Create unsharp mask
    unsharp_mask = cv2.addWeighted(img, 1.5, blurred, -0.5, 0)
    
    # Show comparison
    comparison = np.hstack([img, blurred, unsharp_mask])
    
    # Add labels
    cv2.putText(comparison, 'Original', (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(comparison, 'Blurred', (img.shape[1] + 10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(comparison, 'Sharpened', (img.shape[1] * 2 + 10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('Unsharp Masking Process', comparison)
    print("\nNotice how details are enhanced in the sharpened version!")
    print("The formula: Sharpened = 1.5 * Original - 0.5 * Blurred")
    
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 2. SHARPENING KERNELS
    # ========================================
    print("\n2. SHARPENING KERNELS")
    print("-" * 50)
    print("Direct approach using convolution kernels")
    
    # Define different sharpening kernels
    # Basic sharpen kernel
    kernel_sharpen_1 = np.array([
        [ 0, -1,  0],
        [-1,  5, -1],
        [ 0, -1,  0]
    ])
    
    # Stronger sharpen kernel
    kernel_sharpen_2 = np.array([
        [-1, -1, -1],
        [-1,  9, -1],
        [-1, -1, -1]
    ])
    
    # Very strong sharpen kernel
    kernel_sharpen_3 = np.array([
        [ 1,  1,  1],
        [ 1, -7,  1],
        [ 1,  1,  1]
    ])
    
    # Apply each kernel
    sharpen_1 = cv2.filter2D(img, -1, kernel_sharpen_1)
    sharpen_2 = cv2.filter2D(img, -1, kernel_sharpen_2)
    sharpen_3 = cv2.filter2D(img, -1, kernel_sharpen_3)
    
    print("\nKernel 1 (Mild sharpening):")
    print(kernel_sharpen_1)
    
    # Show mild sharpen
    comparison = np.hstack([img, sharpen_1])
    cv2.putText(comparison, 'Original', (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(comparison, 'Mild Sharpen', (img.shape[1] + 10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('Sharpening Kernel 1', comparison)
    
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    print("\nKernel 2 (Strong sharpening):")
    print(kernel_sharpen_2)
    
    # Show strong sharpen
    comparison = np.hstack([img, sharpen_2])
    cv2.putText(comparison, 'Original', (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(comparison, 'Strong Sharpen', (img.shape[1] + 10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('Sharpening Kernel 2', comparison)
    
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    print("\nKernel 3 (Very strong - edge emphasis):")
    print(kernel_sharpen_3)
    print("Note: This kernel emphasizes edges dramatically!")
    
    # Show very strong sharpen
    comparison = np.hstack([img, sharpen_3])
    cv2.putText(comparison, 'Original', (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(comparison, 'Very Strong', (img.shape[1] + 10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('Sharpening Kernel 3', comparison)
    
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 3. COMPARISON: All Methods
    # ========================================
    print("\n3. COMPARING ALL METHODS")
    print("-" * 50)
    
    # Resize for comparison grid
    img_small = cv2.resize(img, (400, 300))
    unsharp_small = cv2.resize(unsharp_mask, (400, 300))
    sharpen1_small = cv2.resize(sharpen_1, (400, 300))
    sharpen2_small = cv2.resize(sharpen_2, (400, 300))
    
    # Create 2x2 grid
    top_row = np.hstack([img_small, unsharp_small])
    bottom_row = np.hstack([sharpen1_small, sharpen2_small])
    grid = np.vstack([top_row, bottom_row])
    
    # Add labels
    cv2.putText(grid, 'Original', (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(grid, 'Unsharp Mask', (410, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(grid, 'Kernel Mild', (10, 330), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(grid, 'Kernel Strong', (410, 330), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    
    cv2.imshow('All Sharpening Methods Compared', grid)
    print("\nCompare the different sharpening strengths!")
    print("Press any key to finish...")
    cv2.waitKey(0)
    
    # Clean up
    cv2.destroyAllWindows()
    
    print("\n" + "=" * 50)
    print("Key Takeaways:")
    print("=" * 50)
    print("UNSHARP MASKING:")
    print("  ✓ Professional technique")
    print("  ✓ Natural-looking results")
    print("  ✓ More control over strength")
    print("  ✓ Used in Photoshop and other software")
    print()
    print("SHARPENING KERNELS:")
    print("  ✓ Direct and fast")
    print("  ✓ Various strengths available")
    print("  ✗ Can create artifacts if too strong")
    print("  ✓ Good for real-time processing")
    print()
    print("WHEN TO USE:")
    print("  • Fix slightly soft images")
    print("  • Enhance details in landscapes")
    print("  • Compensate for blur in video")
    print("  ⚠ Be careful not to over-sharpen!")
    print("=" * 50)

if __name__ == "__main__":
    main()
