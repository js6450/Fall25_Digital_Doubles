"""
Image Loading Basics
Digital Doubles - Week 1

This script demonstrates the fundamental operations of:
- Loading an image from file
- Displaying an image in a window
- Getting image properties (dimensions, channels, data type)
- Saving an image to file
- Proper error handling

Press any key while the image window is active to continue to the next step.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Image Loading Basics Demo")
    print("=" * 60)
    print()
    
    # 1. Load an image
    print("Step 1: Loading image...")
    image_path = '../Resources/mountain.jpg'
    img = cv2.imread(image_path)
    
    # Error handling: Check if image was loaded successfully
    if img is None:
        print(f"Error: Could not load image from '{image_path}'")
        print("Please check that the file exists and the path is correct.")
        return
    
    print(f"✓ Image loaded successfully from '{image_path}'")
    print()
    
    # 2. Get and display image properties
    print("Step 2: Image Properties")
    print("-" * 60)
    
    # Get image dimensions
    height, width, channels = img.shape
    print(f"Image dimensions:")
    print(f"  Width:  {width} pixels")
    print(f"  Height: {height} pixels")
    print(f"  Channels: {channels} (BGR)")
    print()
    
    # Get data type
    print(f"Data type: {img.dtype}")
    print(f"  This means each pixel value is stored as an unsigned 8-bit integer (0-255)")
    print()
    
    # Calculate and display file size in memory
    size_bytes = img.nbytes
    size_mb = size_bytes / (1024 * 1024)
    print(f"Size in memory: {size_bytes:,} bytes ({size_mb:.2f} MB)")
    print()
    
    # Get pixel value at a specific location
    sample_pixel = img[100, 100]  # [y, x] - note the order!
    print(f"Sample pixel at position (100, 100):")
    print(f"  BGR values: {sample_pixel}")
    print(f"  Blue:  {sample_pixel[0]}")
    print(f"  Green: {sample_pixel[1]}")
    print(f"  Red:   {sample_pixel[2]}")
    print()
    
    # 3. Display the image
    print("Step 3: Displaying image...")
    print("A window should open showing the image.")
    print("Press any key while the window is active to continue.")
    print()
    
    cv2.imshow('Original Image - Press any key to continue', img)
    cv2.waitKey(0)  # Wait for key press
    print("✓ Image displayed successfully")
    print()
    
    # 4. Save the image
    print("Step 4: Saving image...")
    output_path = 'output_copy.jpg'
    
    # Save with default quality
    success = cv2.imwrite(output_path, img)
    
    if success:
        print(f"✓ Image saved to '{output_path}'")
    else:
        print(f"✗ Failed to save image to '{output_path}'")
    print()
    
    # Save with high quality (90 out of 100)
    output_path_hq = 'output_high_quality.jpg'
    cv2.imwrite(output_path_hq, img, [cv2.IMWRITE_JPEG_QUALITY, 90])
    print(f"✓ High quality version saved to '{output_path_hq}'")
    print()
    
    # 5. Load the saved image to verify
    print("Step 5: Verifying saved image...")
    loaded_copy = cv2.imread(output_path)
    
    if loaded_copy is not None:
        print("✓ Successfully loaded the saved image")
        cv2.imshow('Loaded Copy - Press any key to close', loaded_copy)
        cv2.waitKey(0)
    else:
        print("✗ Could not load the saved image")
    print()
    
    # Clean up: Close all windows
    cv2.destroyAllWindows()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Always check if cv2.imread() returns None (error handling)")
    print("  - Image dimensions are accessed as img.shape → (height, width, channels)")
    print("  - Pixel coordinates are [y, x], not [x, y]")
    print("  - OpenCV uses BGR color order, not RGB")
    print("  - cv2.imshow() displays images, cv2.waitKey() waits for key press")
    print("  - cv2.destroyAllWindows() closes all OpenCV windows")
    print("=" * 60)

if __name__ == "__main__":
    main()
