"""
Thresholding Demo
Digital Doubles - Week 1

This script demonstrates different thresholding techniques:
- Simple binary threshold
- Inverse binary threshold
- Adaptive threshold (for varying lighting)
- Otsu's method (automatic threshold selection)

Thresholding converts grayscale images to binary (black and white only),
which is useful for segmentation and analysis.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Thresholding Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/whiteflower.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    # Convert to grayscale (required for thresholding)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    print("✓ Image loaded and converted to grayscale")
    print()
    
    # Display original and grayscale
    cv2.imshow('Original (Color)', img)
    cv2.imshow('Grayscale', gray)
    print("Thresholding works on grayscale images")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SIMPLE BINARY THRESHOLD ==========
    print("1. SIMPLE BINARY THRESHOLD")
    print("=" * 60)
    print("Pixels > threshold become white (255)")
    print("Pixels ≤ threshold become black (0)")
    print()
    
    # Threshold at 127 (middle value)
    print("a) Threshold at 127 (middle)")
    threshold_value = 127
    ret, binary_127 = cv2.threshold(gray, threshold_value, 255, cv2.THRESH_BINARY)
    print(f"   Pixels > {threshold_value} → white")
    print(f"   Pixels ≤ {threshold_value} → black")
    cv2.imshow('1a. Binary Threshold (127)', binary_127)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Lower threshold
    print("b) Threshold at 80 (lower)")
    ret, binary_80 = cv2.threshold(gray, 80, 255, cv2.THRESH_BINARY)
    print("   More pixels become white")
    cv2.imshow('1b. Binary Threshold (80)', binary_80)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Higher threshold
    print("c) Threshold at 180 (higher)")
    ret, binary_180 = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY)
    print("   Fewer pixels become white (only brightest areas)")
    cv2.imshow('1c. Binary Threshold (180)', binary_180)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== INVERSE BINARY THRESHOLD ==========
    print("2. INVERSE BINARY THRESHOLD")
    print("=" * 60)
    print("Same as binary, but colors are inverted:")
    print("Pixels > threshold become black (0)")
    print("Pixels ≤ threshold become white (255)")
    print()
    
    ret, binary_inv = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
    
    cv2.imshow('2a. Normal Binary (127)', binary_127)
    cv2.imshow('2b. Inverse Binary (127)', binary_inv)
    print("Notice: Inverse is like a negative of the normal threshold")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== ADAPTIVE THRESHOLD ==========
    print("3. ADAPTIVE THRESHOLD")
    print("=" * 60)
    print("Adaptive thresholding calculates different thresholds")
    print("for different regions of the image.")
    print("This is better for images with varying lighting.")
    print()
    
    # Create an image with varying lighting for demo
    print("Creating image with uneven lighting for demonstration...")
    # Apply a gradient to simulate uneven lighting
    gradient = np.linspace(0, 100, gray.shape[1], dtype=np.uint8)
    gradient = np.tile(gradient, (gray.shape[0], 1))
    uneven = cv2.add(gray, gradient)
    
    cv2.imshow('3a. Image with uneven lighting', uneven)
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Simple threshold on uneven lighting
    print("Applying simple threshold to uneven lighting...")
    ret, simple_on_uneven = cv2.threshold(uneven, 127, 255, cv2.THRESH_BINARY)
    cv2.imshow('3b. Simple Threshold (poor result)', simple_on_uneven)
    print("Notice: Parts that should be visible are lost")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Adaptive threshold - Mean
    print("Applying adaptive threshold (Mean method)...")
    adaptive_mean = cv2.adaptiveThreshold(
        uneven, 255, cv2.ADAPTIVE_THRESH_MEAN_C, 
        cv2.THRESH_BINARY, 11, 2
    )
    cv2.imshow('3c. Adaptive Threshold (Mean)', adaptive_mean)
    print("Much better! Adapts to local lighting conditions")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Adaptive threshold - Gaussian
    print("Applying adaptive threshold (Gaussian method)...")
    adaptive_gaussian = cv2.adaptiveThreshold(
        uneven, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 11, 2
    )
    cv2.imshow('3d. Adaptive Threshold (Gaussian)', adaptive_gaussian)
    print("Gaussian method: Smoother, weights nearby pixels more")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # Parameters explanation
    print("Adaptive threshold parameters:")
    print("  - Block size (11): Size of pixel neighborhood for calculation")
    print("  - C (2): Constant subtracted from mean/weighted mean")
    print("  - Larger block size → smoother, less detail")
    print("  - Larger C → more aggressive thresholding")
    print()
    
    # ========== OTSU'S METHOD ==========
    print("4. OTSU'S METHOD")
    print("=" * 60)
    print("Otsu's method automatically finds the optimal threshold value")
    print("by analyzing the image histogram.")
    print()
    
    # Apply Otsu's thresholding
    print("Applying Otsu's threshold...")
    otsu_threshold, otsu_binary = cv2.threshold(
        gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    
    print(f"✓ Otsu's method chose threshold value: {otsu_threshold:.1f}")
    print()
    
    # Compare with manual threshold
    ret, manual_127 = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    
    cv2.imshow('4a. Manual Threshold (127)', manual_127)
    cv2.imshow(f'4b. Otsu Threshold ({otsu_threshold:.0f})', otsu_binary)
    print("Otsu's method often finds a better threshold than guessing")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== COMPARISON ==========
    print("5. METHOD COMPARISON")
    print("=" * 60)
    print("Comparing all threshold methods on original image")
    print()
    
    # Apply all methods
    _, simple = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    _, simple_inv = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
    adaptive = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 11, 2
    )
    _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    cv2.imshow('5a. Original Grayscale', gray)
    cv2.imshow('5b. Simple Binary', simple)
    cv2.imshow('5c. Simple Binary Inverse', simple_inv)
    cv2.imshow('5d. Adaptive Threshold', adaptive)
    cv2.imshow('5e. Otsu Threshold', otsu)
    
    print("Compare the results - each method has its use case")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== PRACTICAL APPLICATIONS ==========
    print("6. WHEN TO USE WHICH METHOD")
    print("=" * 60)
    print()
    print("Simple Binary Threshold:")
    print("  ✓ Uniform lighting")
    print("  ✓ Known threshold value")
    print("  ✓ Simple segmentation")
    print()
    print("Inverse Binary:")
    print("  ✓ When you need black/white reversed")
    print("  ✓ Creating masks")
    print()
    print("Adaptive Threshold:")
    print("  ✓ Varying lighting conditions")
    print("  ✓ Document scanning")
    print("  ✓ Text extraction")
    print()
    print("Otsu's Method:")
    print("  ✓ Don't know optimal threshold")
    print("  ✓ Bimodal histograms (two clear peaks)")
    print("  ✓ Automatic processing")
    print()
    
    # ========== SAVING ==========
    print("7. SAVING THRESHOLDED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_binary_threshold.jpg', simple)
    cv2.imwrite('output_binary_inverse.jpg', simple_inv)
    cv2.imwrite('output_adaptive_threshold.jpg', adaptive)
    cv2.imwrite('output_otsu_threshold.jpg', otsu)
    
    print("✓ Saved 4 thresholded images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Thresholding converts grayscale to binary (black/white)")
    print("  - Simple threshold: Single value for entire image")
    print("  - Adaptive threshold: Different values for different regions")
    print("  - Otsu's method: Automatically finds optimal threshold")
    print("  - Choose method based on your image characteristics")
    print("=" * 60)

if __name__ == "__main__":
    main()
