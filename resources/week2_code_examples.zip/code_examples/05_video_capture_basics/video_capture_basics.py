"""
Video Capture Basics
Demonstrates fundamental video capture and playback using OpenCV.

Topics Covered:
- Reading video from files
- Reading video from webcam
- Getting video properties
- Basic video playback
- Frame navigation

Key Concepts:
- Video is a sequence of images (frames)
- Frame rate (fps) determines playback speed
- VideoCapture handles both files and cameras
- Always check if video opened successfully
- Always release resources when done
"""

import cv2
import sys

def display_video_info(cap):
    """
    Display information about video source
    
    Args:
        cap: cv2.VideoCapture object
    """
    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    print("\n" + "=" * 50)
    print("VIDEO INFORMATION")
    print("=" * 50)
    print(f"Resolution: {width} x {height}")
    print(f"Frame Rate: {fps:.2f} fps")
    print(f"Total Frames: {total_frames}")
    
    if total_frames > 0:
        duration = total_frames / fps
        print(f"Duration: {duration:.2f} seconds ({duration/60:.2f} minutes)")
    else:
        print("Duration: Unknown (live camera)")
    
    print("=" * 50 + "\n")

def play_video_file(video_path):
    """
    Play video from a file
    
    Args:
        video_path: Path to video file
    """
    print(f"\nAttempting to open video file: {video_path}")
    
    # Open video file
    cap = cv2.VideoCapture(video_path)
    
    # Check if video opened successfully
    if not cap.isOpened():
        print(f"Error: Could not open video file '{video_path}'")
        return
    
    print("Video file opened successfully!")
    
    # Display video information
    display_video_info(cap)
    
    print("CONTROLS:")
    print("  SPACE - Pause/Resume")
    print("  Q     - Quit")
    print("  R     - Restart video")
    print("\nPlaying video...\n")
    
    paused = False
    
    while True:
        if not paused:
            # Read next frame
            ret, frame = cap.read()
            
            # Check if frame was read successfully
            if not ret:
                print("End of video reached")
                break
            
            # Display current frame number
            current_frame = int(cap.get(cv2.CAP_PROP_POS_FRAMES))
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            
            # Add frame counter to display
            text = f"Frame: {current_frame}/{total_frames}"
            cv2.putText(frame, text, (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # Display the frame
            cv2.imshow('Video Playback', frame)
        
        # Wait based on frame rate (to play at correct speed)
        # Typical: 1000ms / fps = delay per frame
        # But we use 25ms and let OpenCV handle timing
        key = cv2.waitKey(25) & 0xFF
        
        # Handle keyboard input
        if key == ord('q'):
            print("Quitting...")
            break
        elif key == ord(' '):  # Space bar
            paused = not paused
            print("Paused" if paused else "Resumed")
        elif key == ord('r'):
            # Restart video
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            print("Restarting video...")
    
    # Release resources
    cap.release()
    cv2.destroyAllWindows()

def capture_webcam():
    """
    Capture video from webcam
    """
    print("\nAttempting to open webcam...")
    
    # Open default camera (0)
    # Try 1, 2, etc. if you have multiple cameras
    cap = cv2.VideoCapture(0)
    
    # Check if camera opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam")
        print("Make sure:")
        print("  - Camera is connected")
        print("  - No other app is using camera")
        print("  - You have camera permissions")
        return
    
    print("Webcam opened successfully!")
    
    # Optionally set camera properties
    # Note: Not all cameras support all settings
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)
    
    # Display actual properties (may differ from requested)
    display_video_info(cap)
    
    print("CONTROLS:")
    print("  Q - Quit")
    print("  S - Save current frame")
    print("\nCapturing from webcam...\n")
    
    frame_count = 0
    
    while True:
        # Read frame
        ret, frame = cap.read()
        
        if not ret:
            print("Error: Could not read frame")
            break
        
        frame_count += 1
        
        # Add frame counter
        text = f"Frame: {frame_count}"
        cv2.putText(frame, text, (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Display the frame
        cv2.imshow('Webcam Capture', frame)
        
        # Wait 1ms for key press
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q'):
            print("Quitting...")
            break
        elif key == ord('s'):
            # Save current frame
            filename = f'webcam_frame_{frame_count}.jpg'
            cv2.imwrite(filename, frame)
            print(f"Saved frame to '{filename}'")
    
    # Release resources
    cap.release()
    cv2.destroyAllWindows()

def compare_video_sources():
    """
    Display video file and webcam side-by-side
    """
    # Open video file
    video_cap = cv2.VideoCapture('../Resources/ocean_waves.mp4')
    
    # Open webcam
    webcam_cap = cv2.VideoCapture(0)
    
    if not video_cap.isOpened():
        print("Error: Could not open video file")
        print("Make sure 'ocean_waves.mp4' is in the Resources folder")
        return
    
    if not webcam_cap.isOpened():
        print("Error: Could not open webcam")
        video_cap.release()
        return
    
    print("\nComparing video file and webcam feed")
    print("Press 'q' to quit\n")
    
    while True:
        # Read from both sources
        ret_video, frame_video = video_cap.read()
        ret_webcam, frame_webcam = webcam_cap.read()
        
        # Check if video file ended
        if not ret_video:
            # Restart video
            video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue
        
        if not ret_webcam:
            print("Error reading from webcam")
            break
        
        # Resize to same height for side-by-side display
        height = 480
        frame_video = cv2.resize(frame_video, 
                                 (int(frame_video.shape[1] * height / frame_video.shape[0]), height))
        frame_webcam = cv2.resize(frame_webcam, 
                                  (int(frame_webcam.shape[1] * height / frame_webcam.shape[0]), height))
        
        # Add labels
        cv2.putText(frame_video, "Video File", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(frame_webcam, "Webcam", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Combine side by side
        combined = cv2.hconcat([frame_video, frame_webcam])
        
        # Display
        cv2.imshow('Video File vs Webcam', combined)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    # Release resources
    video_cap.release()
    webcam_cap.release()
    cv2.destroyAllWindows()

def main():
    print("\n" + "=" * 50)
    print("VIDEO CAPTURE BASICS")
    print("=" * 50)
    print("\nChoose an option:")
    print("  1 - Play video file")
    print("  2 - Capture from webcam")
    print("  3 - Compare video file and webcam")
    print("=" * 50)
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == '1':
        # Play video file
        video_path = '../Resources/ocean_waves.mp4'
        play_video_file(video_path)
    
    elif choice == '2':
        # Capture from webcam
        capture_webcam()
    
    elif choice == '3':
        # Compare both sources
        compare_video_sources()
    
    else:
        print("Invalid choice!")

if __name__ == "__main__":
    main()
