"""
Masked Image Compositing
Digital Doubles - Week 1

This script demonstrates advanced compositing using masks to create transparency:
- Creating masks based on pixel values (making black pixels transparent)
- Using masks to selectively composite images
- Different masking techniques for different scenarios
- Anti-aliasing for smooth edges
- Practical creative applications

This technique is essential for creating complex compositions where you want
only specific parts of an image to appear on top of a background.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Masked Image Compositing Demo")
    print("=" * 60)
    print()
    
    # Load images
    print("Loading images...")
    background = cv2.imread('../Resources/ocean.jpg')
    overlay = cv2.imread('../Resources/pinkflower.jpg')
    
    if background is None or overlay is None:
        print("Error: Could not load images")
        return
    
    print("✓ Images loaded")
    print(f"  Background (ocean): {background.shape[1]}x{background.shape[0]}")
    print(f"  Overlay (flower): {overlay.shape[1]}x{overlay.shape[0]}")
    print()
    
    # Display original images
    cv2.imshow('Background: Ocean', background)
    cv2.imshow('Overlay: Pink Flower', overlay)
    print("Notice: The flower image has black background pixels")
    print("We want to make those black pixels transparent!")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # Resize overlay to fit nicely on background
    overlay_resized = cv2.resize(overlay, (400, 400))
    
    # ========== PROBLEM: SIMPLE OVERLAY ==========
    print("1. THE PROBLEM: Simple Overlay (No Masking)")
    print("=" * 60)
    print("First, let's see what happens WITHOUT masking")
    print()
    
    result_no_mask = background.copy()
    x_offset, y_offset = 100, 100
    y1, y2 = y_offset, y_offset + overlay_resized.shape[0]
    x1, x2 = x_offset, x_offset + overlay_resized.shape[1]
    
    result_no_mask[y1:y2, x1:x2] = overlay_resized
    
    cv2.imshow('1. Without Masking - Problem!', result_no_mask)
    print("❌ The black background of the flower image blocks the ocean")
    print("❌ We see a black square instead of just the flower")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SOLUTION 1: SIMPLE THRESHOLD MASK ==========
    print("2. SOLUTION 1: Simple Threshold Mask")
    print("=" * 60)
    print("Create a mask where black pixels = 0 (transparent)")
    print("and non-black pixels = 255 (opaque)")
    print()
    
    # Convert overlay to grayscale
    overlay_gray = cv2.cvtColor(overlay_resized, cv2.COLOR_BGR2GRAY)
    
    # Create mask: pixels brighter than 10 are kept (255), darker are removed (0)
    # This makes black pixels (value ~0) transparent
    threshold_value = 10
    _, mask_simple = cv2.threshold(overlay_gray, threshold_value, 255, cv2.THRESH_BINARY)
    
    print(f"Created binary mask using threshold = {threshold_value}")
    print("  Black pixels (< 10) → 0 in mask (transparent)")
    print("  Other pixels (≥ 10) → 255 in mask (opaque)")
    
    # Show the mask
    cv2.imshow('2a. The Mask (White = Keep, Black = Remove)', mask_simple)
    print("\nIn the mask:")
    print("  White areas = flower (will be visible)")
    print("  Black areas = background (will be transparent)")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Apply the mask to composite
    result_simple = background.copy()
    bg_region = result_simple[y1:y2, x1:x2]
    
    # Convert mask to 3 channels
    mask_3channel = cv2.merge([mask_simple, mask_simple, mask_simple])
    
    # Use the mask:
    # Where mask is 255 (white), use overlay pixel
    # Where mask is 0 (black), use background pixel
    mask_inv = cv2.bitwise_not(mask_simple)
    mask_inv_3channel = cv2.merge([mask_inv, mask_inv, mask_inv])
    
    # Extract regions
    overlay_fg = cv2.bitwise_and(overlay_resized, mask_3channel)
    background_bg = cv2.bitwise_and(bg_region, mask_inv_3channel)
    
    # Combine
    composited = cv2.add(overlay_fg, background_bg)
    result_simple[y1:y2, x1:x2] = composited
    
    cv2.imshow('2b. With Simple Mask - Better!', result_simple)
    print("✓ Black pixels are now transparent!")
    print("✓ Only the flower shape appears on the ocean")
    print("\nHowever, notice the edges might look a bit rough...")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SOLUTION 2: SMOOTHER EDGES WITH BLUR ==========
    print("3. SOLUTION 2: Smoother Edges (Anti-aliased Mask)")
    print("=" * 60)
    print("Blur the mask slightly for smoother, more natural edges")
    print()
    
    # Create mask with higher threshold for cleaner separation
    _, mask_clean = cv2.threshold(overlay_gray, 15, 255, cv2.THRESH_BINARY)
    
    # Blur the mask to create smooth edges
    mask_smooth = cv2.GaussianBlur(mask_clean, (5, 5), 0)
    
    cv2.imshow('3a. Smoothed Mask (Anti-aliased)', mask_smooth)
    print("The blurred mask creates softer edges")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Apply smoothed mask with alpha blending
    result_smooth = background.copy()
    bg_region = result_smooth[y1:y2, x1:x2]
    
    # Normalize mask to 0-1 range for blending
    mask_normalized = mask_smooth.astype(float) / 255.0
    mask_3d = np.stack([mask_normalized, mask_normalized, mask_normalized], axis=2)
    
    # Alpha blend using the mask
    overlay_float = overlay_resized.astype(float)
    bg_float = bg_region.astype(float)
    
    blended = (overlay_float * mask_3d + bg_float * (1 - mask_3d)).astype(np.uint8)
    result_smooth[y1:y2, x1:x2] = blended
    
    cv2.imshow('3b. With Smoothed Mask - Smooth Edges!', result_smooth)
    print("✓ Much smoother, more natural-looking edges!")
    print("✓ The flower blends seamlessly with the ocean")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SOLUTION 3: COLOR RANGE MASK ==========
    print("4. SOLUTION 3: Color Range Mask")
    print("=" * 60)
    print("More precise masking using specific color ranges")
    print("Good for removing specific colors, not just black")
    print()
    
    # Define range for "dark" colors (near black)
    # In BGR format
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([30, 30, 30])  # Anything darker than this
    
    # Create mask based on color range
    mask_color = cv2.inRange(overlay_resized, lower_black, upper_black)
    
    # Invert mask (we want to KEEP non-black pixels)
    mask_color_inv = cv2.bitwise_not(mask_color)
    
    # Smooth it
    mask_color_smooth = cv2.GaussianBlur(mask_color_inv, (5, 5), 0)
    
    cv2.imshow('4a. Color Range Mask', mask_color_smooth)
    print("This mask removes all pixels in the dark range")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Apply color range mask
    result_color = background.copy()
    bg_region = result_color[y1:y2, x1:x2]
    
    # Normalize and blend
    mask_normalized = mask_color_smooth.astype(float) / 255.0
    mask_3d = np.stack([mask_normalized, mask_normalized, mask_normalized], axis=2)
    
    overlay_float = overlay_resized.astype(float)
    bg_float = bg_region.astype(float)
    
    blended = (overlay_float * mask_3d + bg_float * (1 - mask_3d)).astype(np.uint8)
    result_color[y1:y2, x1:x2] = blended
    
    cv2.imshow('4b. With Color Range Mask', result_color)
    print("✓ Very precise color-based masking!")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== MULTIPLE MASKED OVERLAYS ==========
    print("5. CREATIVE APPLICATION: Multiple Masked Overlays")
    print("=" * 60)
    print("Compositing multiple images with masks at different positions")
    print()
    
    # Load second flower
    overlay2 = cv2.imread('../Resources/whiteflower.jpg')
    overlay2_resized = cv2.resize(overlay2, (300, 300))
    
    result_multi = background.copy()
    
    # Function to apply masked overlay at position
    def apply_masked_overlay(base, overlay, x, y):
        """Helper function to apply masked overlay at specific position."""
        h, w = overlay.shape[:2]
        
        # Create mask
        gray = cv2.cvtColor(overlay, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 15, 255, cv2.THRESH_BINARY)
        mask_smooth = cv2.GaussianBlur(mask, (5, 5), 0)
        
        # Get background region
        bg_region = base[y:y+h, x:x+w]
        
        # Normalize mask and blend
        mask_norm = mask_smooth.astype(float) / 255.0
        mask_3d = np.stack([mask_norm, mask_norm, mask_norm], axis=2)
        
        overlay_float = overlay.astype(float)
        bg_float = bg_region.astype(float)
        
        blended = (overlay_float * mask_3d + bg_float * (1 - mask_3d)).astype(np.uint8)
        base[y:y+h, x:x+w] = blended
        
        return base
    
    # Apply first flower
    result_multi = apply_masked_overlay(result_multi, overlay_resized, 50, 50)
    print("✓ Added pink flower at (50, 50)")
    
    # Apply second flower
    result_multi = apply_masked_overlay(result_multi, overlay2_resized, 500, 300)
    print("✓ Added white flower at (500, 300)")
    
    # Apply third flower (scaled differently)
    overlay_small = cv2.resize(overlay, (250, 250))
    result_multi = apply_masked_overlay(result_multi, overlay_small, 700, 100)
    print("✓ Added small pink flower at (700, 100)")
    
    cv2.imshow('5. Multiple Masked Overlays', result_multi)
    print("\n✓ Created complex composition with multiple masked images!")
    print("✓ Each flower sits naturally on the ocean background")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== COMPARISON ==========
    print("6. COMPARISON: All Methods Side by Side")
    print("=" * 60)
    
    # Create comparison canvas
    canvas = np.zeros((800, 1600, 3), dtype=np.uint8)
    
    # Resize results to fit
    small_h, small_w = 350, 525
    
    comparison_images = [
        (result_no_mask, "Without Mask"),
        (result_simple, "Simple Threshold"),
        (result_smooth, "Smooth Edges"),
        (result_color, "Color Range")
    ]
    
    # Add title
    cv2.putText(canvas, "Masking Techniques Comparison", (450, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 2)
    
    # Arrange comparisons
    for idx, (img, title) in enumerate(comparison_images):
        row = idx // 2
        col = idx % 2
        
        img_small = cv2.resize(img, (small_w, small_h))
        
        x = 50 + col * (small_w + 50)
        y = 100 + row * (small_h + 100)
        
        canvas[y:y+small_h, x:x+small_w] = img_small
        
        # Add label
        cv2.putText(canvas, title, (x + 10, y + small_h + 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    cv2.imshow('6. Comparison of Methods', canvas)
    print("Compare all four approaches:")
    print("  1. Without Mask - Shows the problem")
    print("  2. Simple Threshold - Basic solution")
    print("  3. Smooth Edges - Better quality")
    print("  4. Color Range - Most precise")
    print("\nPress any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== KEY CONCEPTS ==========
    print("7. KEY CONCEPTS")
    print("=" * 60)
    print()
    print("Understanding Masks:")
    print("  • A mask is a grayscale image (0-255)")
    print("  • 255 (white) = fully opaque (show overlay)")
    print("  • 0 (black) = fully transparent (show background)")
    print("  • Values in between = partial transparency")
    print()
    print("Creating Masks:")
    print("  1. Threshold: Convert grayscale to binary")
    print("  2. Color Range: Select specific color ranges")
    print("  3. Blur: Smooth edges for better quality")
    print()
    print("Applying Masks:")
    print("  • Bitwise operations: cv2.bitwise_and() for hard edges")
    print("  • Alpha blending: Multiply by normalized mask for soft edges")
    print("  • Normalized mask: Divide by 255 to get 0.0-1.0 range")
    print()
    print("When to Use:")
    print("  • Removing backgrounds from images")
    print("  • Creating complex compositions")
    print("  • Artistic effects (silhouettes, cutouts)")
    print("  • Preparing images for green screen effects")
    print()
    
    # ========== SAVING ==========
    print("8. SAVING RESULTS")
    print("=" * 60)
    
    cv2.imwrite('output_no_mask.jpg', result_no_mask)
    cv2.imwrite('output_simple_mask.jpg', result_simple)
    cv2.imwrite('output_smooth_mask.jpg', result_smooth)
    cv2.imwrite('output_color_mask.jpg', result_color)
    cv2.imwrite('output_multiple_masked.jpg', result_multi)
    cv2.imwrite('output_comparison.jpg', canvas)
    cv2.imwrite('output_mask_example.jpg', mask_smooth)  # Save mask for reference
    
    print("✓ Saved 7 output images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("KEY TAKEAWAYS:")
    print("  ✓ Masks let you make specific pixels transparent")
    print("  ✓ Use thresholding to create masks from pixel values")
    print("  ✓ Blur masks for smoother, more natural edges")
    print("  ✓ Color range masks are more precise than simple thresholds")
    print("  ✓ Normalize masks (0-1) for alpha blending")
    print("  ✓ This technique is essential for complex compositions")
    print()
    print("TRY IT YOURSELF:")
    print("  • Experiment with different threshold values")
    print("  • Try different blur kernel sizes")
    print("  • Use different color ranges")
    print("  • Create your own multi-layer compositions")
    print("=" * 60)

if __name__ == "__main__":
    main()
