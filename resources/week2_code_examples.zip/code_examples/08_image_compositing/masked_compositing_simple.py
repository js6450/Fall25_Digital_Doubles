"""
Simple Masked Compositing
Digital Doubles - Week 1

Quick example: Making black pixels transparent when compositing images.

This shows the essential technique in a concise way:
1. Create a mask based on pixel brightness
2. Use the mask to blend overlay with background
3. Result: Only the flower (not black background) appears on ocean

Perfect for understanding the core concept quickly!
"""

import cv2
import numpy as np

# Load images
background = cv2.imread('../Resources/ocean.jpg')
flower = cv2.imread('../Resources/pinkflower.jpg')

# Resize flower to fit nicely
flower_resized = cv2.resize(flower, (400, 400))

# Position where we want to place the flower
x, y = 100, 100

# ========================================
# METHOD 1: Without Mask (THE PROBLEM)
# ========================================
result_no_mask = background.copy()
h, w = flower_resized.shape[:2]
result_no_mask[y:y+h, x:x+w] = flower_resized

cv2.imshow('WITHOUT MASK - Problem: Black box appears', result_no_mask)
print("Problem: The black background blocks the ocean")
cv2.waitKey(0)

# ========================================
# METHOD 2: With Mask (THE SOLUTION!)
# ========================================

# Step 1: Create a mask from the flower image
# Convert to grayscale
flower_gray = cv2.cvtColor(flower_resized, cv2.COLOR_BGR2GRAY)

# Threshold: Make mask where black pixels (< 10) become 0, others become 255
_, mask = cv2.threshold(flower_gray, 10, 255, cv2.THRESH_BINARY)

# Step 2: Blur the mask for smooth edges
mask_smooth = cv2.GaussianBlur(mask, (5, 5), 0)

# Show the mask
cv2.imshow('THE MASK: White=Keep, Black=Remove', mask_smooth)
print("\nThe mask: White areas will be visible, black areas transparent")
cv2.waitKey(0)

# Step 3: Apply the mask to composite
result_with_mask = background.copy()

# Get the background region where we'll place the flower
bg_region = result_with_mask[y:y+h, x:x+w]

# Normalize mask to 0.0-1.0 range for alpha blending
mask_normalized = mask_smooth.astype(float) / 255.0

# Expand mask to 3 channels (one for each color channel)
mask_3d = np.stack([mask_normalized, mask_normalized, mask_normalized], axis=2)

# Alpha blend: 
# output = (overlay * mask) + (background * (1 - mask))
flower_float = flower_resized.astype(float)
bg_float = bg_region.astype(float)

blended = (flower_float * mask_3d + bg_float * (1 - mask_3d)).astype(np.uint8)

# Place the blended result back
result_with_mask[y:y+h, x:x+w] = blended

cv2.imshow('WITH MASK - Success: Only flower appears!', result_with_mask)
print("\nSuccess! Black pixels are transparent, only flower shows")
cv2.waitKey(0)

# ========================================
# COMPARISON
# ========================================
comparison = np.hstack([result_no_mask, result_with_mask])
cv2.imshow('COMPARISON: Without Mask vs With Mask', comparison)
print("\nComparison: Without mask (left) vs With mask (right)")
cv2.waitKey(0)

cv2.destroyAllWindows()

# Save results
cv2.imwrite('simple_masked_result.jpg', result_with_mask)
cv2.imwrite('simple_mask.jpg', mask_smooth)

print("\n" + "="*60)
print("HOW IT WORKS:")
print("="*60)
print("1. Create mask: Bright pixels → 255 (keep)")
print("                Dark pixels → 0 (remove)")
print("2. Blur mask: Smooth edges for natural look")
print("3. Normalize: Divide by 255 to get 0.0-1.0")
print("4. Blend: (overlay × mask) + (background × (1-mask))")
print("="*60)
print("\nKey insight: The mask acts as a 'stencil' that controls")
print("which pixels from the overlay should be visible!")
print("="*60)
