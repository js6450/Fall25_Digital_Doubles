# Image Compositing Examples

## Overview
This folder contains examples demonstrating how to layer and composite images in OpenCV. These techniques are fundamental for creating complex visual compositions and are widely used in digital art, photo editing, and creative coding.

## Files

### `image_compositing.py`
**Comprehensive compositing techniques**

Covers basic to intermediate compositing:
1. **Basic Overlay** - Placing one image on another
2. **Multiple Overlays** - Arranging several images
3. **Alpha Blending** - Creating transparency effects
4. **Collages** - Grid arrangements
5. **Watermarks** - Semi-transparent overlays
6. **Picture-in-Picture** - Inset images with borders

**Run:** `python image_compositing.py`

---

### `masked_compositing.py` ⭐ NEW
**Advanced masking techniques**

Demonstrates how to use masks to make specific pixels transparent:
1. **Problem Demonstration** - Why masking is needed
2. **Simple Threshold Mask** - Basic black pixel removal
3. **Smooth Edges** - Anti-aliased masks for better quality
4. **Color Range Mask** - Precise color-based masking
5. **Multiple Masked Overlays** - Complex compositions
6. **Comparison** - All methods side by side

**Key Concept:** Makes black (or any color) pixels transparent so only the subject appears on the background.

**Example Use Case:** Overlay flower image on ocean, but only show the flower shape (not the black background).

**Run:** `python masked_compositing.py`

---

### `masked_compositing_simple.py`
**Quick introduction to masking**

A concise, easy-to-understand version that shows:
- The problem (black box appears)
- The solution (mask-based transparency)
- How it works (step by step)

Perfect for quickly grasping the concept!

**Run:** `python masked_compositing_simple.py`

---

## When to Use Each Example

### Use `image_compositing.py` when:
- Learning basic image placement
- Creating collages or grids
- Adding watermarks
- Understanding alpha blending fundamentals

### Use `masked_compositing.py` when:
- Removing backgrounds from images
- Creating complex multi-layer compositions
- Need transparent regions based on color
- Want smooth, anti-aliased edges
- Working on creative/artistic projects

### Use `masked_compositing_simple.py` when:
- Need a quick example
- Want to understand masking basics fast
- Looking for clean, simple code to modify

---

## Key Concepts

### Basic Compositing
**Direct Placement:**
```python
background[y1:y2, x1:x2] = overlay
```
- Fast and simple
- Completely replaces background pixels
- No transparency

**Alpha Blending:**
```python
result = cv2.addWeighted(bg, 1-alpha, overlay, alpha, 0)
```
- Creates uniform transparency
- Good for fade effects
- Same transparency everywhere

### Masked Compositing
**Creating Masks:**
```python
# Threshold method
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, mask = cv2.threshold(gray, threshold_value, 255, cv2.THRESH_BINARY)

# Color range method
mask = cv2.inRange(img, lower_color, upper_color)
```

**Applying Masks:**
```python
# Normalize mask to 0-1
mask_norm = mask.astype(float) / 255.0

# Blend using mask
result = (overlay * mask_norm) + (background * (1 - mask_norm))
```

**Key Insight:** The mask acts as a "stencil" controlling pixel-by-pixel transparency.

---

## Masking Techniques Comparison

| Method | Best For | Edge Quality | Precision |
|--------|----------|--------------|-----------|
| Simple Threshold | Quick results | Hard edges | Medium |
| Smooth Mask | Natural look | Soft, anti-aliased | Medium |
| Color Range | Specific colors | Adjustable | High |

---

## Common Use Cases

### Artistic Compositions
- Layering multiple elements
- Creating surreal imagery
- Digital collages
- Mixed media effects

### Practical Applications
- Removing backgrounds
- Product photography composites
- Logo/watermark placement
- UI element overlays

### Creative Effects
- Silhouettes
- Cutouts
- Green screen effects (Week 2+)
- Transparent overlays

---

## Tips and Best Practices

### 1. Mask Creation
- **Threshold value**: Experiment with different values (5-30 typical for black)
- **Blur amount**: Larger kernels = softer edges (3-9 typical)
- **Color range**: Adjust based on actual image colors

### 2. Edge Quality
- Always blur masks for smooth edges
- Use odd kernel sizes (3, 5, 7, 9)
- Higher blur = softer transition

### 3. Performance
- Create mask once, reuse if needed
- Resize images before compositing
- Use appropriate data types (float for blending, uint8 for display)

### 4. Image Sizes
- Ensure overlay fits within background
- Check dimensions before placing
- Handle edge cases (overlay larger than background)

---

## Common Issues and Solutions

**Issue:** "Jagged, pixelated edges"
- **Solution:** Blur the mask with `cv2.GaussianBlur()`

**Issue:** "Not all background removed"
- **Solution:** Adjust threshold value or use color range mask

**Issue:** "Halo effect around subject"
- **Solution:** Refine mask edges or adjust blur amount

**Issue:** "Image dimensions don't match"
- **Solution:** Resize overlay or check placement coordinates

---

## Mathematical Understanding

### Alpha Blending Formula
```
output = (overlay × alpha) + (background × (1 - alpha))
```

Where:
- `alpha` = transparency value (0.0 to 1.0)
- 1.0 = fully opaque (show overlay)
- 0.0 = fully transparent (show background)

### Masked Blending
```
output = (overlay × mask) + (background × (1 - mask))
```

Where:
- `mask` = per-pixel alpha values (0.0 to 1.0)
- Different alpha for each pixel
- Enables pixel-level control

---

## Relationship to Other Examples

**Builds on:**
- Example 03: Color Space Conversions (grayscale for masks)
- Example 07: Thresholding (creating binary masks)
- Example 08: Pixel Manipulation (understanding pixel values)

**Prepares for:**
- Week 2: Video compositing and real-time effects
- Week 3: Interactive effects with live video
- Final Project: Complex visual installations

---

## Experimentation Ideas

Try modifying the code to:
1. Use different threshold values to see the effect
2. Change blur kernel size for edge quality
3. Mask different colors (not just black)
4. Create layered compositions with multiple images
5. Add borders or effects to masked regions
6. Combine masking with other transformations
7. Create artistic effects (double exposure, etc.)

---

## Next Steps

After mastering these examples:
1. Experiment with your own images
2. Try complex multi-layer compositions
3. Combine with color space conversions for effects
4. Prepare for Week 2 video compositing
5. Think about how this applies to your final project

---

## Additional Resources

- [OpenCV Masking Tutorial](https://docs.opencv.org/master/d0/d86/tutorial_py_image_arithmetics.html)
- [Alpha Compositing (Wikipedia)](https://en.wikipedia.org/wiki/Alpha_compositing)
- [Color Space Masking](https://docs.opencv.org/master/df/d9d/tutorial_py_colorspaces.html)

---

**Week 1 - Digital Doubles**  
**Instructor:** Jiwon Shin
