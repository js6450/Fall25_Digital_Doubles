# Masked Compositing Examples - Instructor Notes

## Summary for Instructor (Jiwon Shin)

### What Was Created

I've added **masked compositing examples** to the existing image compositing folder (Example 09). These demonstrate how to make specific pixels transparent when compositing images, which was specifically requested to show how to overlay pinkflower.jpg on ocean.jpg with black pixels transparent.

### Location
`/DigitalDoubles/Week1/code_examples/09_image_compositing/`

### New Files Created

1. **masked_compositing.py** (Comprehensive)
   - Full demonstration of masking techniques
   - 6 different approaches with comparisons
   - Visual demonstrations of each step
   - ~400 lines with detailed comments
   
2. **masked_compositing_simple.py** (Quick Start)
   - Concise version (~100 lines)
   - Shows problem and solution clearly
   - Perfect for quick understanding
   - Step-by-step with explanations

3. **README.md** (Documentation)
   - Complete guide to all compositing examples
   - Comparison table of techniques
   - Tips and best practices
   - Common issues and solutions

### What the Examples Teach

**Core Concept:** Using masks to control pixel-level transparency

**Techniques Covered:**
1. **Simple Threshold Mask**
   - Convert to grayscale
   - Threshold to create binary mask
   - Black pixels → transparent, others → opaque

2. **Smoothed Edges**
   - Blur the mask for anti-aliasing
   - Creates natural-looking edges
   - Professional quality results

3. **Color Range Mask**
   - More precise than simple threshold
   - Target specific color ranges
   - Good for various background colors

4. **Multiple Overlays**
   - Complex compositions
   - Layering multiple masked images
   - Practical creative applications

### Problem Solved

**Original Request:** "Make pinkflower.jpg overlay on ocean.jpg with black pixels transparent"

**Solution Demonstrated:**
- Load both images ✓
- Create mask from black pixels ✓
- Apply mask to make black transparent ✓
- Result: Only flower shape appears on ocean ✓

### Learning Progression

**Level 1: Understanding the Problem**
- Show what happens WITHOUT masking
- Black box appears - clearly not what we want

**Level 2: Basic Solution**
- Simple threshold creates mask
- Binary decision: keep or remove
- Works, but edges might be rough

**Level 3: Professional Quality**
- Blur the mask for smooth edges
- Normalize for proper blending
- Natural-looking results

**Level 4: Advanced Techniques**
- Color range masking
- Multiple layers
- Complex compositions

### How to Use in Class

#### Option 1: Quick Demo (15 minutes)
```bash
cd 09_image_compositing
python masked_compositing_simple.py
```
- Show the problem first (black box)
- Show the mask visualization
- Show the solution (transparent background)
- Explain the key concept

#### Option 2: Detailed Walkthrough (30 minutes)
```bash
python masked_compositing.py
```
- Walk through all 6 demonstrations
- Discuss each technique
- Compare results
- Discuss when to use each approach

#### Option 3: Lab Activity (45 minutes)
1. Students run `masked_compositing_simple.py`
2. Modify threshold value and observe results
3. Try with different images
4. Create their own masked composition
5. Share results and discuss

### Key Teaching Moments

**Concept 1: Masks as Stencils**
- Mask = template controlling visibility
- White = keep, Black = remove
- Grayscale = partial transparency

**Concept 2: Threshold Selection**
- Different images need different thresholds
- Black isn't always exactly 0
- Experimentation is key

**Concept 3: Edge Quality**
- Hard edges = jaggy, unrealistic
- Blur = smooth, natural
- Kernel size affects softness

**Concept 4: Mathematical Understanding**
```
output = (overlay × mask) + (background × (1 - mask))
```
- Mask controls blending per pixel
- 0-1 range for proper blending
- Each pixel can have different transparency

### Integration with Course

**Builds On:**
- Example 03: Color spaces (grayscale conversion)
- Example 07: Thresholding (mask creation)
- Example 08: Pixel manipulation (understanding values)

**Prepares For:**
- Week 2: Real-time video masking
- Week 3: Interactive chroma key (green screen)
- Week 4: Background subtraction
- Final Project: Complex video compositions

### Technical Details

**Requirements:**
- OpenCV, NumPy (standard Week 1 dependencies)
- Resource images: ocean.jpg, pinkflower.jpg, whiteflower.jpg

**Output Files Created:**
- output_no_mask.jpg
- output_simple_mask.jpg
- output_smooth_mask.jpg
- output_color_mask.jpg
- output_multiple_masked.jpg
- output_comparison.jpg
- output_mask_example.jpg

**Performance:**
- Suitable for real-time processing
- Can be applied to video frames (Week 2)
- Optimized with NumPy vectorization

### Common Student Questions (Prepared Answers)

**Q: "Why blur the mask?"**
A: Creates smooth transitions at edges, prevents jaggy artifacts, looks more natural and professional.

**Q: "What if my background isn't black?"**
A: Use color range masking (`cv2.inRange`) to target specific colors, or use more advanced techniques in Week 4 (background subtraction).

**Q: "Can this work with video?"**
A: Yes! Week 2 will show how to apply this frame-by-frame for real-time video effects.

**Q: "What's the difference between masking and alpha blending?"**
A: Alpha blending applies uniform transparency everywhere; masking gives pixel-level control with different transparency per pixel.

**Q: "How do I choose the threshold value?"**
A: Experiment! Start around 10-20 for black backgrounds. Use the interactive demo from Example 11 to find the best value.

### Extensions and Challenges

**Beginner:**
- Try different threshold values
- Change blur kernel size
- Use different images

**Intermediate:**
- Mask different colors (not just black)
- Create multi-layer compositions
- Add borders around masked regions

**Advanced:**
- Combine with color transformations
- Create artistic double-exposure effects
- Implement automatic threshold detection
- Add feathering effects

### Relationship to Final Project

Students' final project involves creating a digital installation with live video. Masking is crucial for:
- Real-time background removal
- Creating augmented reality effects
- Layering video feeds
- Interactive installations
- Chroma key (green screen) effects

### Discussion Points

**1. Practical Applications:**
- Photography/graphic design
- Video production
- AR/VR applications
- Live performance visuals

**2. Artistic Considerations:**
- How does masking change perception?
- Transparency as a creative tool
- Layering as visual metaphor
- Digital representation themes

**3. Technical Decisions:**
- Trade-offs: speed vs. quality
- When to use simple vs. complex masking
- Performance in real-time applications

### Testing Recommendations

Before class:
1. Run both scripts to ensure they work
2. Check output image quality
3. Verify all resource images are present
4. Test on classroom computer

### Updates Made to Course Materials

1. ✓ Created `masked_compositing.py` (comprehensive example)
2. ✓ Created `masked_compositing_simple.py` (quick version)
3. ✓ Created `09_image_compositing/README.md` (documentation)
4. ✓ Updated main `Week1/code_examples/README.md`

### Quick Reference Commands

```bash
# Navigate to folder
cd DigitalDoubles/Week1/code_examples/09_image_compositing

# Run simple version (recommended for teaching)
python masked_compositing_simple.py

# Run comprehensive version (for exploration)
python masked_compositing.py

# Run original compositing (for comparison)
python image_compositing.py
```

---

## Key Message for Students

*"A mask is like a stencil - it controls which parts of your overlay image are visible and which parts let the background show through. This gives you pixel-perfect control over transparency, enabling complex and creative compositions."*

---

**Created:** October 2025  
**Status:** Ready for Week 1  
**Complements:** Examples 01-09  
**Prerequisites:** Understanding of pixel values, color spaces, and basic compositing
