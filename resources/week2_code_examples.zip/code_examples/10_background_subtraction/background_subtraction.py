"""
Week 2 - Example 10: Background Subtraction
Advanced motion detection using MOG2 and KNN background subtractors

This example introduces OpenCV's built-in background subtraction algorithms,
which are more sophisticated than simple frame differencing. These algorithms
learn a model of the background over time and can adapt to gradual changes
like lighting variations.

Students will learn:
- Background subtraction concepts
- MOG2 (Mixture of Gaussians) algorithm
- KNN (K-Nearest Neighbors) algorithm
- Comparison between different methods
- Foreground mask processing

Key Concepts:
- Adaptive background modeling
- Gaussian mixture models
- K-Nearest Neighbors classification
- Learning rate adjustment
- Shadow detection

Algorithms:
1. MOG2 (Mixture of Gaussians 2):
   - Models each pixel as a mixture of Gaussian distributions
   - Can detect shadows (gray in mask)
   - Good for complex backgrounds
   
2. KNN (K-Nearest Neighbors):
   - Uses K-nearest neighbors to classify pixels
   - Generally faster than MOG2
   - Good for dynamic backgrounds

Usage:
- 'm' to switch between MOG2 and KNN
- 's' to toggle shadow detection (MOG2 only)
- '+' to increase learning rate
- '-' to decrease learning rate
- 'r' to reset background model
- 'q' to quit
"""

import cv2
import numpy as np

class BackgroundSubtractorManager:
    """
    Manager for background subtraction algorithms
    """
    
    def __init__(self):
        """Initialize background subtractors"""
        # MOG2 parameters
        self.mog2 = cv2.createBackgroundSubtractorMOG2(
            history=500,           # Number of frames to learn from
            varThreshold=16,       # Threshold for classification
            detectShadows=True     # Detect shadows
        )
        
        # KNN parameters
        self.knn = cv2.createBackgroundSubtractorKNN(
            history=500,           # Number of frames to learn from
            dist2Threshold=400,    # Threshold for classification
            detectShadows=True     # Detect shadows
        )
        
        self.current_method = 'MOG2'
        self.learning_rate = -1  # -1 = automatic learning rate
        self.detect_shadows = True
        
        # Learning rates to cycle through
        self.learning_rates = [-1, 0.001, 0.01, 0.1]
        self.lr_index = 0
    
    def apply(self, frame):
        """
        Apply current background subtraction method
        
        Args:
            frame: Input frame (BGR)
        
        Returns:
            fg_mask: Foreground mask
        """
        if self.current_method == 'MOG2':
            fg_mask = self.mog2.apply(frame, learningRate=self.learning_rate)
        else:  # KNN
            fg_mask = self.knn.apply(frame, learningRate=self.learning_rate)
        
        return fg_mask
    
    def toggle_method(self):
        """Switch between MOG2 and KNN"""
        self.current_method = 'KNN' if self.current_method == 'MOG2' else 'MOG2'
        return self.current_method
    
    def toggle_shadows(self):
        """Toggle shadow detection"""
        self.detect_shadows = not self.detect_shadows
        self.mog2.setDetectShadows(self.detect_shadows)
        self.knn.setDetectShadows(self.detect_shadows)
        return self.detect_shadows
    
    def increase_learning_rate(self):
        """Increase learning rate"""
        self.lr_index = min(self.lr_index + 1, len(self.learning_rates) - 1)
        self.learning_rate = self.learning_rates[self.lr_index]
        return self.learning_rate
    
    def decrease_learning_rate(self):
        """Decrease learning rate"""
        self.lr_index = max(self.lr_index - 1, 0)
        self.learning_rate = self.learning_rates[self.lr_index]
        return self.learning_rate
    
    def reset(self):
        """Reset background models"""
        self.mog2 = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=16, detectShadows=self.detect_shadows
        )
        self.knn = cv2.createBackgroundSubtractorKNN(
            history=500, dist2Threshold=400, detectShadows=self.detect_shadows
        )

def process_foreground_mask(fg_mask, remove_shadows=True):
    """
    Process foreground mask to improve quality
    
    Args:
        fg_mask: Raw foreground mask from background subtractor
        remove_shadows: Whether to remove detected shadows
    
    Returns:
        Processed mask
    """
    # Remove shadows (gray pixels with value 127)
    if remove_shadows:
        fg_mask[fg_mask == 127] = 0
    
    # Apply morphological operations to reduce noise
    kernel = np.ones((3, 3), np.uint8)
    
    # Remove small noise
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel, iterations=1)
    
    # Fill small holes
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    return fg_mask

def create_visualization(frame, fg_mask, method, learning_rate, detect_shadows):
    """
    Create comprehensive visualization
    
    Args:
        frame: Original frame
        fg_mask: Foreground mask
        method: Current method name
        learning_rate: Current learning rate
        detect_shadows: Whether shadow detection is enabled
    
    Returns:
        Visualization image
    """
    # Process mask
    processed_mask = process_foreground_mask(fg_mask.copy(), remove_shadows=not detect_shadows)
    
    # Apply mask to original frame to show only foreground
    foreground = cv2.bitwise_and(frame, frame, mask=processed_mask)
    
    # Create colored masks for better visualization
    fg_colored = cv2.cvtColor(fg_mask, cv2.COLOR_GRAY2BGR)
    processed_colored = cv2.cvtColor(processed_mask, cv2.COLOR_GRAY2BGR)
    
    # Find contours of foreground objects
    contours, _ = cv2.findContours(processed_mask, cv2.RETR_EXTERNAL, 
                                    cv2.CHAIN_APPROX_SIMPLE)
    
    # Draw contours on original frame
    result = frame.copy()
    cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
    
    # Count foreground objects
    num_objects = len([c for c in contours if cv2.contourArea(c) > 100])
    
    # Add info text
    info_text = [
        f"Method: {method}",
        f"Learning Rate: {learning_rate}",
        f"Shadows: {'ON' if detect_shadows else 'OFF'}",
        f"Objects: {num_objects}"
    ]
    
    y_pos = 30
    for text in info_text:
        cv2.putText(result, text, (10, y_pos), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        y_pos += 30
    
    # Create 2x2 grid
    # Top: Original | Raw foreground mask
    # Bottom: Processed mask | Result with contours
    top_row = np.hstack([frame, fg_colored])
    bottom_row = np.hstack([processed_colored, result])
    display = np.vstack([top_row, bottom_row])
    
    # Add labels
    cv2.putText(display, "Original", (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    cv2.putText(display, "Raw Foreground Mask", (650, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    cv2.putText(display, "Processed Mask", (10, 510), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    cv2.putText(display, "Result with Contours", (650, 510), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    # Add note about shadows in raw mask
    if detect_shadows:
        cv2.putText(display, "Gray = Shadows", (650, 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
    
    return display

def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)
    
    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/ice_hockey.mp4')
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    # Initialize background subtractor manager
    bs_manager = BackgroundSubtractorManager()
    
    print("Background Subtraction - MOG2 vs KNN")
    print("=" * 60)
    print("Background subtraction learns what is 'background' and")
    print("detects 'foreground' (moving objects).")
    print("\nAlgorithms:")
    print("  MOG2: Mixture of Gaussians (good for complex backgrounds)")
    print("  KNN:  K-Nearest Neighbors (faster, good for dynamic backgrounds)")
    print("\nControls:")
    print("  'm' - Switch between MOG2 and KNN")
    print("  's' - Toggle shadow detection")
    print("  '+' - Increase learning rate (adapts faster to changes)")
    print("  '-' - Decrease learning rate (more stable)")
    print("  'r' - Reset background model")
    print("  'q' - Quit")
    print(f"\nCurrent method: {bs_manager.current_method}")
    print(f"Learning rate: {bs_manager.learning_rate}")
    print("=" * 60)
    
    while True:
        # Read frame
        ret, frame = cap.read()
        
        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue
        
        # Resize frame
        frame = cv2.resize(frame, (640, 480))
        
        # Apply background subtraction
        fg_mask = bs_manager.apply(frame)
        
        # Create visualization
        display = create_visualization(
            frame, fg_mask, 
            bs_manager.current_method, 
            bs_manager.learning_rate,
            bs_manager.detect_shadows
        )
        
        # Show display
        cv2.imshow('Background Subtraction', display)
        
        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('m'):
            method = bs_manager.toggle_method()
            print(f"Switched to: {method}")
        elif key == ord('s'):
            shadows = bs_manager.toggle_shadows()
            print(f"Shadow detection: {'ON' if shadows else 'OFF'}")
        elif key == ord('+') or key == ord('='):
            lr = bs_manager.increase_learning_rate()
            print(f"Learning rate: {lr}")
        elif key == ord('-') or key == ord('_'):
            lr = bs_manager.decrease_learning_rate()
            print(f"Learning rate: {lr}")
        elif key == ord('r'):
            bs_manager.reset()
            print("Background model reset")
    
    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nBackground subtraction stopped.")

if __name__ == "__main__":
    main()
