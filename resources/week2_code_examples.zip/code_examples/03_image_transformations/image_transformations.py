"""
Image Transformations
Digital Doubles - Week 1

This script demonstrates geometric transformations:
- Resizing (specific size, by percentage, maintaining aspect ratio)
- Cropping
- Rotating (90°, 180°, 270°, arbitrary angles)
- Flipping (horizontal, vertical, both)

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Image Transformations Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/ocean.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    height, width = img.shape[:2]
    print(f"✓ Image loaded: {width}x{height} pixels")
    print()
    
    # Display original
    cv2.imshow('Original Image', img)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== RESIZING ==========
    print("1. RESIZING")
    print("=" * 60)
    print()
    
    # Resize to specific dimensions
    print("a) Resize to specific size (800x600)")
    resized_specific = cv2.resize(img, (800, 600))
    print(f"   New size: {resized_specific.shape[1]}x{resized_specific.shape[0]}")
    cv2.imshow('1a. Resized to 800x600', resized_specific)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Resize by percentage
    print("b) Resize by percentage (50%)")
    scale_percent = 50
    new_width = int(width * scale_percent / 100)
    new_height = int(height * scale_percent / 100)
    resized_percent = cv2.resize(img, (new_width, new_height))
    print(f"   Original: {width}x{height}")
    print(f"   50% size: {new_width}x{new_height}")
    cv2.imshow('1b. Resized to 50%', resized_percent)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Maintain aspect ratio
    print("c) Resize maintaining aspect ratio")
    print("   Setting width to 1000 pixels, height calculated automatically")
    new_width = 1000
    aspect_ratio = width / height
    new_height = int(new_width / aspect_ratio)
    resized_aspect = cv2.resize(img, (new_width, new_height))
    print(f"   New size: {new_width}x{new_height}")
    cv2.imshow('1c. Resized maintaining aspect ratio', resized_aspect)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Different interpolation methods
    print("d) Interpolation methods comparison")
    print("   Different methods affect quality:")
    
    # Make it small first, then enlarge to see the difference
    small = cv2.resize(img, (200, 150))
    
    # Nearest neighbor (fastest, lowest quality)
    nearest = cv2.resize(small, (800, 600), interpolation=cv2.INTER_NEAREST)
    cv2.imshow('1d-1. INTER_NEAREST (pixelated)', nearest)
    
    # Linear interpolation (default, good balance)
    linear = cv2.resize(small, (800, 600), interpolation=cv2.INTER_LINEAR)
    cv2.imshow('1d-2. INTER_LINEAR (smooth)', linear)
    
    # Cubic interpolation (slower, higher quality)
    cubic = cv2.resize(small, (800, 600), interpolation=cv2.INTER_CUBIC)
    cv2.imshow('1d-3. INTER_CUBIC (smoothest)', cubic)
    
    print("   Compare the quality of different interpolation methods")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CROPPING ==========
    print("2. CROPPING")
    print("=" * 60)
    print()
    
    # Simple crop
    print("a) Simple crop [100:400, 100:400]")
    cropped_simple = img[100:400, 100:400]
    print(f"   Cropped size: {cropped_simple.shape[1]}x{cropped_simple.shape[0]}")
    cv2.imshow('2a. Simple crop', cropped_simple)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Center crop
    print("b) Center crop (500x500)")
    crop_size = 500
    center_x, center_y = width // 2, height // 2
    x1 = center_x - crop_size // 2
    y1 = center_y - crop_size // 2
    x2 = x1 + crop_size
    y2 = y1 + crop_size
    cropped_center = img[y1:y2, x1:x2]
    print(f"   Center crop: {crop_size}x{crop_size} from center of image")
    cv2.imshow('2b. Center crop', cropped_center)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== ROTATING ==========
    print("3. ROTATING")
    print("=" * 60)
    print()
    
    # 90 degrees clockwise
    print("a) Rotate 90° clockwise")
    rotated_90 = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    cv2.imshow('3a. Rotated 90° CW', rotated_90)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # 180 degrees
    print("b) Rotate 180°")
    rotated_180 = cv2.rotate(img, cv2.ROTATE_180)
    cv2.imshow('3b. Rotated 180°', rotated_180)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # 270 degrees clockwise (90 degrees counter-clockwise)
    print("c) Rotate 270° CW (90° CCW)")
    rotated_270 = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    cv2.imshow('3c. Rotated 270° CW', rotated_270)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Arbitrary angle rotation
    print("d) Rotate 45° (arbitrary angle)")
    center = (width // 2, height // 2)
    rotation_matrix = cv2.getRotationMatrix2D(center, 45, 1.0)
    rotated_45 = cv2.warpAffine(img, rotation_matrix, (width, height))
    print("   Note: Corners are cut off")
    cv2.imshow('3d. Rotated 45°', rotated_45)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Arbitrary angle with adjusted canvas
    print("e) Rotate 45° with expanded canvas")
    # Calculate new dimensions to fit rotated image
    angle_rad = np.radians(45)
    new_width = int(abs(width * np.cos(angle_rad)) + abs(height * np.sin(angle_rad)))
    new_height = int(abs(width * np.sin(angle_rad)) + abs(height * np.cos(angle_rad)))
    
    # Adjust rotation matrix for new canvas
    rotation_matrix = cv2.getRotationMatrix2D(center, 45, 1.0)
    rotation_matrix[0, 2] += (new_width - width) / 2
    rotation_matrix[1, 2] += (new_height - height) / 2
    
    rotated_45_full = cv2.warpAffine(img, rotation_matrix, (new_width, new_height))
    print("   Now the full image is visible")
    cv2.imshow('3e. Rotated 45° (full image)', rotated_45_full)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== FLIPPING ==========
    print("4. FLIPPING")
    print("=" * 60)
    print()
    
    # Horizontal flip
    print("a) Flip horizontal (mirror left-right)")
    flipped_horizontal = cv2.flip(img, 1)
    cv2.imshow('4a. Flipped horizontal', flipped_horizontal)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Vertical flip
    print("b) Flip vertical (mirror top-bottom)")
    flipped_vertical = cv2.flip(img, 0)
    cv2.imshow('4b. Flipped vertical', flipped_vertical)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Both directions
    print("c) Flip both directions")
    flipped_both = cv2.flip(img, -1)
    cv2.imshow('4c. Flipped both ways', flipped_both)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SAVING ==========
    print("5. SAVING TRANSFORMED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_resized_50percent.jpg', resized_percent)
    cv2.imwrite('output_center_crop.jpg', cropped_center)
    cv2.imwrite('output_rotated_90.jpg', rotated_90)
    cv2.imwrite('output_flipped_horizontal.jpg', flipped_horizontal)
    
    print("✓ Saved 4 transformed images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - cv2.resize() changes image dimensions")
    print("  - Crop using array slicing: img[y1:y2, x1:x2]")
    print("  - cv2.rotate() for 90°, 180°, 270° rotations")
    print("  - cv2.getRotationMatrix2D() + cv2.warpAffine() for arbitrary angles")
    print("  - cv2.flip() for mirroring (0=vertical, 1=horizontal, -1=both)")
    print("  - Remember: coordinates are [y, x] not [x, y]!")
    print("=" * 60)

if __name__ == "__main__":
    main()
