"""
Week 2 - Example 09: Complete Motion Detection
Robust motion detection with contours and bounding boxes

This example builds on basic frame differencing by adding:
- Morphological operations to reduce noise
- Contour detection to identify discrete motion regions
- Bounding boxes to highlight moving objects
- Minimum area filtering to ignore small movements

Students will learn:
- Complete motion detection pipeline
- Noise reduction techniques
- Contour analysis
- Object localization

Key Concepts:
- Morphological operations (erosion, dilation)
- Contour detection and filtering
- Bounding box calculation
- Motion region tracking

Usage:
- 'm' to change minimum area threshold
- 'b' to toggle blur preprocessing
- 'd' to toggle dilation
- 'q' to quit
"""

import cv2
import numpy as np

class MotionDetector:
    """
    Complete motion detection system with contour analysis
    """
    
    def __init__(self, threshold=25, min_area=500, use_blur=True, use_dilation=True):
        """
        Initialize motion detector
        
        Args:
            threshold: Threshold for binary motion mask
            min_area: Minimum contour area to be considered motion
            use_blur: Whether to apply Gaussian blur for noise reduction
            use_dilation: Whether to use dilation to fill gaps
        """
        self.threshold = threshold
        self.min_area = min_area
        self.use_blur = use_blur
        self.use_dilation = use_dilation
        self.prev_frame = None
    
    def detect(self, frame):
        """
        Detect motion in current frame
        
        Args:
            frame: Current video frame (BGR)
        
        Returns:
            motion_mask: Binary mask of motion regions
            contours: List of detected motion contours
            bounding_boxes: List of bounding boxes for motion regions
        """
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise if enabled
        if self.use_blur:
            gray = cv2.GaussianBlur(gray, (21, 21), 0)
        
        # If this is the first frame, store it and return
        if self.prev_frame is None:
            self.prev_frame = gray
            return None, [], []
        
        # Compute absolute difference
        frame_diff = cv2.absdiff(self.prev_frame, gray)
        
        # Apply threshold
        _, motion_mask = cv2.threshold(frame_diff, self.threshold, 255, cv2.THRESH_BINARY)
        
        # Apply morphological operations to reduce noise
        if self.use_dilation:
            # Erosion to remove small noise
            kernel_erode = np.ones((3, 3), np.uint8)
            motion_mask = cv2.erode(motion_mask, kernel_erode, iterations=1)
            
            # Dilation to fill gaps
            kernel_dilate = np.ones((5, 5), np.uint8)
            motion_mask = cv2.dilate(motion_mask, kernel_dilate, iterations=2)
        
        # Find contours
        contours, _ = cv2.findContours(motion_mask, cv2.RETR_EXTERNAL, 
                                       cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours by area and get bounding boxes
        valid_contours = []
        bounding_boxes = []
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > self.min_area:
                valid_contours.append(contour)
                x, y, w, h = cv2.boundingRect(contour)
                bounding_boxes.append((x, y, w, h))
        
        # Update previous frame
        self.prev_frame = gray
        
        return motion_mask, valid_contours, bounding_boxes

def draw_motion_info(frame, contours, bounding_boxes, detector):
    """
    Draw motion detection visualization on frame
    
    Args:
        frame: Original frame to draw on
        contours: Detected motion contours
        bounding_boxes: Bounding boxes for motion regions
        detector: MotionDetector instance
    
    Returns:
        Annotated frame
    """
    result = frame.copy()
    
    # Draw contours in green
    cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
    
    # Draw bounding boxes and labels
    for i, (x, y, w, h) in enumerate(bounding_boxes):
        # Draw rectangle
        cv2.rectangle(result, (x, y), (x + w, y + h), (0, 0, 255), 2)
        
        # Add label with object number and area
        area = w * h
        label = f"Motion {i+1}: {area}px"
        cv2.putText(result, label, (x, y - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    
    # Add detection info
    num_objects = len(bounding_boxes)
    info_text = [
        f"Objects detected: {num_objects}",
        f"Min area: {detector.min_area}",
        f"Threshold: {detector.threshold}",
        f"Blur: {'ON' if detector.use_blur else 'OFF'}",
        f"Dilation: {'ON' if detector.use_dilation else 'OFF'}"
    ]
    
    y_pos = 30
    for text in info_text:
        cv2.putText(result, text, (10, y_pos), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        y_pos += 30
    
    return result

def main():
    # Try to open webcam first
    cap = cv2.VideoCapture(0)
    
    # If webcam fails, use a video file
    if not cap.isOpened():
        print("Webcam not available, using video file...")
        cap = cv2.VideoCapture('../Resources/soccer.mp4')
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    # Initialize motion detector
    detector = MotionDetector(threshold=25, min_area=500, 
                             use_blur=True, use_dilation=True)
    
    # Area thresholds to cycle through
    area_thresholds = [100, 500, 1000, 2000]
    area_index = 1  # Start with 500
    
    print("Complete Motion Detection with Contours")
    print("=" * 50)
    print("This example shows robust motion detection with:")
    print("  - Noise reduction (blur)")
    print("  - Morphological operations")
    print("  - Contour detection")
    print("  - Bounding boxes")
    print("\nControls:")
    print("  'm' - Cycle through minimum area thresholds")
    print("  'b' - Toggle blur preprocessing")
    print("  'd' - Toggle dilation")
    print("  'q' - Quit")
    print(f"\nCurrent min area: {detector.min_area}")
    print("=" * 50)
    
    while True:
        # Read frame
        ret, frame = cap.read()
        
        # If end of video, loop back
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            detector.prev_frame = None  # Reset detector
            continue
        
        # Resize frame
        frame = cv2.resize(frame, (640, 480))
        
        # Detect motion
        motion_mask, contours, bounding_boxes = detector.detect(frame)
        
        # Skip first frame (no previous frame to compare)
        if motion_mask is None:
            continue
        
        # Draw motion information
        result = draw_motion_info(frame, contours, bounding_boxes, detector)
        
        # Create visualization with original, mask, and result
        motion_colored = cv2.cvtColor(motion_mask, cv2.COLOR_GRAY2BGR)
        
        # Stack images horizontally
        top_row = np.hstack([frame, motion_colored])
        
        # Add result below (resize to match width)
        result_display = cv2.resize(result, (top_row.shape[1], 480))
        
        display = np.vstack([top_row, result_display])
        
        # Add labels
        cv2.putText(display, "Original", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(display, "Motion Mask", (650, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(display, "Motion Detection Result", (10, 510), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Show display
        cv2.imshow('Complete Motion Detection', display)
        
        # Handle keyboard input
        key = cv2.waitKey(30) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('m'):
            # Cycle through area thresholds
            area_index = (area_index + 1) % len(area_thresholds)
            detector.min_area = area_thresholds[area_index]
            print(f"Minimum area changed to: {detector.min_area}")
        elif key == ord('b'):
            # Toggle blur
            detector.use_blur = not detector.use_blur
            print(f"Blur: {'ON' if detector.use_blur else 'OFF'}")
        elif key == ord('d'):
            # Toggle dilation
            detector.use_dilation = not detector.use_dilation
            print(f"Dilation: {'ON' if detector.use_dilation else 'OFF'}")
    
    # Clean up
    cap.release()
    cv2.destroyAllWindows()
    print("\nMotion detection stopped.")

if __name__ == "__main__":
    main()
