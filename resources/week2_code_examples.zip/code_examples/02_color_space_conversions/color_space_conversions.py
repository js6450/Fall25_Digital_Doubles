"""
Color Space Conversions
Digital Doubles - Week 1

This script demonstrates converting between different color spaces:
- BGR (OpenCV default)
- RGB (standard)
- Grayscale
- HSV (Hue, Saturation, Value)

Understanding color spaces is crucial for computer vision tasks.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Color Space Conversions Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/pinkflower.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    print("✓ Image loaded")
    print()
    
    # Display original (BGR)
    print("1. Original Image (BGR color space)")
    print("-" * 60)
    print("OpenCV loads images in BGR (Blue, Green, Red) order by default.")
    print("This is for historical reasons related to early video camera hardware.")
    print()
    
    cv2.imshow('1. Original (BGR)', img)
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Convert to RGB
    print("2. RGB Conversion")
    print("-" * 60)
    print("RGB (Red, Green, Blue) is the standard color representation.")
    print("Note: When displaying with OpenCV, RGB will look wrong!")
    print("This demonstrates why BGR/RGB conversion matters.")
    print()
    
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Display RGB image using OpenCV (will look wrong - colors swapped)
    cv2.imshow('2. RGB displayed in OpenCV (colors look wrong!)', img_rgb)
    print("Notice the colors are swapped! This is because OpenCV's display")
    print("expects BGR but we're showing it RGB.")
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Convert to Grayscale
    print("3. Grayscale Conversion")
    print("-" * 60)
    print("Grayscale removes color information, keeping only brightness.")
    print("This is useful when color isn't needed for processing.")
    print("Range: 0 (black) to 255 (white)")
    print()
    
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Show grayscale image properties
    print(f"Original shape: {img.shape} (height, width, channels)")
    print(f"Grayscale shape: {img_gray.shape} (height, width)")
    print("Notice: Grayscale has no channel dimension - it's 2D")
    print()
    
    cv2.imshow('3. Grayscale', img_gray)
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Convert to HSV
    print("4. HSV Conversion")
    print("-" * 60)
    print("HSV (Hue, Saturation, Value) separates color from brightness.")
    print("  Hue: The color itself (0-180 in OpenCV)")
    print("  Saturation: Color intensity (0-255)")
    print("  Value: Brightness (0-255)")
    print()
    print("HSV is often better for color-based object detection.")
    print()
    
    img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    # Split HSV channels to display separately
    h, s, v = cv2.split(img_hsv)
    
    print("Displaying HSV channels separately:")
    cv2.imshow('4a. HSV - Hue (Color)', h)
    cv2.imshow('4b. HSV - Saturation (Intensity)', s)
    cv2.imshow('4c. HSV - Value (Brightness)', v)
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Split and display BGR channels for comparison
    print("5. BGR Channel Separation")
    print("-" * 60)
    print("Let's split the original BGR image into its color channels.")
    print()
    
    b, g, r = cv2.split(img)
    
    print("Each channel shows where that color is strong:")
    print("  Blue channel: Bright where image is blue")
    print("  Green channel: Bright where image is green")
    print("  Red channel: Bright where image is red")
    print()
    
    cv2.imshow('5a. Blue Channel', b)
    cv2.imshow('5b. Green Channel', g)
    cv2.imshow('5c. Red Channel', r)
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Merge channels back
    print("6. Merging Channels")
    print("-" * 60)
    print("We can merge channels back together.")
    print()
    
    # Merge in original order
    merged_original = cv2.merge([b, g, r])
    cv2.imshow('6a. Merged (original order)', merged_original)
    
    # Merge in different order for creative effect
    merged_swapped = cv2.merge([r, g, b])  # Swap red and blue
    cv2.imshow('6b. Merged (swapped red and blue)', merged_swapped)
    
    print("Notice the color shift when we swap channels!")
    print("This is a creative technique for color manipulation.")
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Save examples
    print("7. Saving Different Color Spaces")
    print("-" * 60)
    
    cv2.imwrite('output_grayscale.jpg', img_gray)
    print("✓ Saved grayscale version")
    
    cv2.imwrite('output_hsv.jpg', img_hsv)
    print("✓ Saved HSV version")
    
    cv2.imwrite('output_swapped_channels.jpg', merged_swapped)
    print("✓ Saved swapped channel version")
    print()
    
    # Clean up
    cv2.destroyAllWindows()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - OpenCV uses BGR by default, not RGB")
    print("  - Grayscale reduces 3-channel image to 1-channel")
    print("  - HSV separates color from brightness")
    print("  - Channels can be split and merged for creative effects")
    print("  - Always use cv2.cvtColor() for color space conversion")
    print("=" * 60)

if __name__ == "__main__":
    main()
