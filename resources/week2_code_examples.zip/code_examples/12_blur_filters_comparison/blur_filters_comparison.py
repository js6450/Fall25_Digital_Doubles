"""
Week 2 - Example 02: Blur Filters Comparison
Digital Doubles - DM-GY 9201 B

This example demonstrates and compares different types of blur/smoothing filters
available in OpenCV. Each filter has different characteristics and use cases.

Types of blur covered:
- Gaussian Blur (most common, natural-looking)
- Median Blur (best for salt-and-pepper noise)
- Bilateral Filter (preserves edges while blurring)
- Box/Average Blur (simple, fast)

Press any key to advance through the examples.
Press 'q' to quit at any time.
"""

import cv2
import numpy as np
import os

def main():
    # Get the path to the Resources folder
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resources_path = os.path.join(script_dir, '..', 'Resources')
    
    # Load an image with detail (portrait works well)
    img_path = os.path.join(resources_path, 'personOne.jpg')
    img = cv2.imread(img_path)
    
    if img is None:
        print(f"Error: Could not load image from {img_path}")
        print("Make sure the Resources folder contains personOne.jpg")
        return
    
    print("Blur Filters Comparison")
    print("=" * 50)
    print("\nWe'll compare 4 types of blur filters:")
    print("1. Gaussian Blur - Most common, natural-looking")
    print("2. Median Blur - Best for removing noise")
    print("3. Bilateral Filter - Preserves edges while blurring")
    print("4. Box/Average Blur - Simple, fast\n")
    print("Press any key to see each filter")
    print("Press 'q' to quit\n")
    
    # Show original
    cv2.imshow('Original Image', img)
    cv2.waitKey(0)
    
    # ========================================
    # 1. Gaussian Blur
    # ========================================
    print("\n1. GAUSSIAN BLUR")
    print("   - Weighted average (closer pixels have more influence)")
    print("   - Most natural-looking blur")
    print("   - Most commonly used")
    
    # Different strengths of Gaussian blur
    gaussian_light = cv2.GaussianBlur(img, (5, 5), 0)
    gaussian_medium = cv2.GaussianBlur(img, (15, 15), 0)
    gaussian_strong = cv2.GaussianBlur(img, (31, 31), 0)
    
    # Show progression
    cv2.imshow('Gaussian Blur - Light (5x5)', gaussian_light)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Gaussian Blur - Medium (15x15)', gaussian_medium)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Gaussian Blur - Strong (31x31)', gaussian_strong)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 2. Median Blur
    # ========================================
    print("\n2. MEDIAN BLUR")
    print("   - Takes median value (not average)")
    print("   - Excellent for salt-and-pepper noise")
    print("   - Non-linear filter")
    
    median_light = cv2.medianBlur(img, 5)
    median_medium = cv2.medianBlur(img, 15)
    median_strong = cv2.medianBlur(img, 31)
    
    cv2.imshow('Median Blur - Light (5)', median_light)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Median Blur - Medium (15)', median_medium)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Median Blur - Strong (31)', median_strong)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 3. Bilateral Filter
    # ========================================
    print("\n3. BILATERAL FILTER")
    print("   - Blurs similar colors together")
    print("   - Preserves edges!")
    print("   - Great for portraits (smooth skin, keep features)")
    print("   - Slower than other filters")
    
    bilateral_light = cv2.bilateralFilter(img, 9, 50, 50)
    bilateral_medium = cv2.bilateralFilter(img, 9, 75, 75)
    bilateral_strong = cv2.bilateralFilter(img, 9, 150, 150)
    
    cv2.imshow('Bilateral Filter - Light (sigma=50)', bilateral_light)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Bilateral Filter - Medium (sigma=75)', bilateral_medium)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Bilateral Filter - Strong (sigma=150)', bilateral_strong)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 4. Box/Average Blur
    # ========================================
    print("\n4. BOX/AVERAGE BLUR")
    print("   - Simple average of all pixels in kernel")
    print("   - Fast but less sophisticated")
    print("   - Can look 'blocky'")
    
    box_light = cv2.blur(img, (5, 5))
    box_medium = cv2.blur(img, (15, 15))
    box_strong = cv2.blur(img, (31, 31))
    
    cv2.imshow('Box Blur - Light (5x5)', box_light)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Box Blur - Medium (15x15)', box_medium)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    cv2.imshow('Box Blur - Strong (31x31)', box_strong)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 5. Side-by-Side Comparison (Medium Strength)
    # ========================================
    print("\n5. Creating side-by-side comparison...")
    
    # Resize for comparison
    h, w = img.shape[:2]
    new_h, new_w = h // 2, w // 2
    
    # Use medium strength for all
    comparison_imgs = [
        ('Original', img),
        ('Gaussian', gaussian_medium),
        ('Median', median_medium),
        ('Bilateral', bilateral_medium),
        ('Box', box_medium)
    ]
    
    # Create grid
    row1 = []
    row2 = []
    
    for i, (name, img_to_show) in enumerate(comparison_imgs):
        # Resize
        small = cv2.resize(img_to_show, (new_w, new_h))
        
        # Add label
        labeled = small.copy()
        cv2.putText(labeled, name, (10, 40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        if i < 3:
            row1.append(labeled)
        else:
            row2.append(labeled)
    
    # Concatenate
    top_row = np.hstack(row1)
    bottom_row = np.hstack(row2)
    # Make bottom row match width
    if len(row2) < 3:
        # Add black padding
        padding = np.zeros((new_h, new_w * (3 - len(row2)), 3), dtype=np.uint8)
        bottom_row = np.hstack([bottom_row, padding])
    
    comparison_grid = np.vstack([top_row, bottom_row])
    
    cv2.imshow('Comparison: All Blur Types (Medium Strength)', comparison_grid)
    print("\nComparison grid displayed!")
    print("\nKey differences:")
    print("- Gaussian: Natural, smooth")
    print("- Median: Good for noise, slightly different texture")
    print("- Bilateral: Edges are preserved! (notice face features)")
    print("- Box: Simpler, slightly blocky")
    
    print("\nPress any key to exit...")
    cv2.waitKey(0)
    
    # ========================================
    # 6. Edge Preservation Comparison
    # ========================================
    print("\n6. Testing edge preservation...")
    
    # Load image with clear edges
    edge_img_path = os.path.join(resources_path, 'mountain.jpg')
    edge_img = cv2.imread(edge_img_path)
    
    if edge_img is not None:
        # Apply blurs
        g_blur = cv2.GaussianBlur(edge_img, (21, 21), 0)
        bi_blur = cv2.bilateralFilter(edge_img, 21, 150, 150)
        
        # Show comparison
        comparison = np.hstack([
            cv2.resize(edge_img, (400, 300)),
            cv2.resize(g_blur, (400, 300)),
            cv2.resize(bi_blur, (400, 300))
        ])
        
        cv2.putText(comparison, 'Original', (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(comparison, 'Gaussian (blurred edges)', (410, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(comparison, 'Bilateral (sharp edges)', (810, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        cv2.imshow('Edge Preservation: Gaussian vs Bilateral', comparison)
        print("\nNotice how bilateral filter keeps edges sharp!")
        print("Press any key to finish...")
        cv2.waitKey(0)
    
    # Clean up
    cv2.destroyAllWindows()
    
    print("\n" + "=" * 50)
    print("Key Takeaways:")
    print("=" * 50)
    print("GAUSSIAN BLUR:")
    print("  ✓ Most common, natural-looking")
    print("  ✓ Good general-purpose blur")
    print("  ✗ Blurs everything including edges")
    print()
    print("MEDIAN BLUR:")
    print("  ✓ Best for salt-and-pepper noise")
    print("  ✓ Non-linear (preserves some edges)")
    print("  ✗ Can change texture slightly")
    print()
    print("BILATERAL FILTER:")
    print("  ✓ Preserves edges while blurring")
    print("  ✓ Great for portraits")
    print("  ✗ Slower than other filters")
    print()
    print("BOX BLUR:")
    print("  ✓ Fast and simple")
    print("  ✗ Less sophisticated, can be blocky")
    print("=" * 50)

if __name__ == "__main__":
    main()
