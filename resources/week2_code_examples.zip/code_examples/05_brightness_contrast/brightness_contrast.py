"""
Brightness and Contrast Adjustment
Digital Doubles - Week 1

This script demonstrates how to adjust:
- Brightness (adding/subtracting a constant value)
- Contrast (multiplying by a scaling factor)
- Combined adjustments

Formula: output = alpha * input + beta
  alpha > 1: Increases contrast
  alpha < 1: Decreases contrast
  beta > 0: Increases brightness
  beta < 0: Decreases brightness

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Brightness and Contrast Adjustment Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/mountain.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    print("✓ Image loaded")
    print()
    
    # Display original
    cv2.imshow('Original Image', img)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== BRIGHTNESS ADJUSTMENT ==========
    print("1. BRIGHTNESS ADJUSTMENT")
    print("=" * 60)
    print("Brightness is adjusted by adding or subtracting a constant value")
    print("to all pixels.")
    print()
    
    # Increase brightness
    print("a) Increase brightness (+50)")
    brighter = cv2.add(img, 50)  # Safer than img + 50 (handles overflow)
    cv2.imshow('1a. Brighter (+50)', brighter)
    print("   All pixels increased by 50")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Decrease brightness
    print("b) Decrease brightness (-50)")
    darker = cv2.subtract(img, 50)  # Safer than img - 50
    cv2.imshow('1b. Darker (-50)', darker)
    print("   All pixels decreased by 50")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Using NumPy with clipping
    print("c) Using NumPy with clipping")
    print("   This method gives you more control")
    brighter_np = np.clip(img.astype(np.int16) + 80, 0, 255).astype(np.uint8)
    cv2.imshow('1c. Brighter (NumPy +80)', brighter_np)
    print("   np.clip ensures values stay in 0-255 range")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CONTRAST ADJUSTMENT ==========
    print("2. CONTRAST ADJUSTMENT")
    print("=" * 60)
    print("Contrast is adjusted by multiplying pixel values.")
    print("  alpha > 1.0: Increases contrast (more separation)")
    print("  alpha < 1.0: Decreases contrast (less separation)")
    print()
    
    # Increase contrast
    print("a) Increase contrast (alpha=1.5)")
    high_contrast = cv2.convertScaleAbs(img, alpha=1.5, beta=0)
    cv2.imshow('2a. Higher Contrast (1.5x)', high_contrast)
    print("   Bright areas become brighter, dark areas become darker")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Decrease contrast
    print("b) Decrease contrast (alpha=0.5)")
    low_contrast = cv2.convertScaleAbs(img, alpha=0.5, beta=0)
    cv2.imshow('2b. Lower Contrast (0.5x)', low_contrast)
    print("   Image becomes more washed out, less distinction")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Very high contrast
    print("c) Very high contrast (alpha=2.0)")
    very_high_contrast = cv2.convertScaleAbs(img, alpha=2.0, beta=0)
    cv2.imshow('2c. Very High Contrast (2.0x)', very_high_contrast)
    print("   Dramatic effect - watch for clipping!")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== COMBINED ADJUSTMENT ==========
    print("3. COMBINED BRIGHTNESS AND CONTRAST")
    print("=" * 60)
    print("Formula: output = alpha * input + beta")
    print("  alpha = contrast factor")
    print("  beta = brightness offset")
    print()
    
    # Brighter and more contrast
    print("a) Brighter and higher contrast (alpha=1.3, beta=30)")
    adjusted1 = cv2.convertScaleAbs(img, alpha=1.3, beta=30)
    cv2.imshow('3a. Brighter + Higher Contrast', adjusted1)
    print("   More vibrant, punchy look")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Darker and less contrast
    print("b) Darker and lower contrast (alpha=0.7, beta=-30)")
    adjusted2 = cv2.convertScaleAbs(img, alpha=0.7, beta=-30)
    cv2.imshow('3b. Darker + Lower Contrast', adjusted2)
    print("   Moody, low-key effect")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Creative adjustment
    print("c) Creative adjustment (alpha=1.5, beta=-20)")
    adjusted3 = cv2.convertScaleAbs(img, alpha=1.5, beta=-20)
    cv2.imshow('3c. High Contrast + Slightly Darker', adjusted3)
    print("   Dramatic, cinematic look")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== COMPARISON ==========
    print("4. SIDE-BY-SIDE COMPARISON")
    print("=" * 60)
    print("Comparing multiple adjustments")
    print()
    
    cv2.imshow('4a. Original', img)
    cv2.imshow('4b. Brighter', brighter)
    cv2.imshow('4c. Darker', darker)
    cv2.imshow('4d. High Contrast', high_contrast)
    cv2.imshow('4e. Low Contrast', low_contrast)
    cv2.imshow('4f. Brighter + High Contrast', adjusted1)
    
    print("Compare the different adjustments")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== HISTOGRAM DEMONSTRATION ==========
    print("5. UNDERSTANDING WITH HISTOGRAMS")
    print("=" * 60)
    print("Let's visualize how these adjustments affect pixel distribution")
    print()
    
    # Convert to grayscale for simpler histogram
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray_bright = cv2.add(gray, 50)
    gray_dark = cv2.subtract(gray, 50)
    gray_high_contrast = cv2.convertScaleAbs(gray, alpha=1.5, beta=0)
    
    # Calculate histograms
    hist_original = cv2.calcHist([gray], [0], None, [256], [0, 256])
    hist_bright = cv2.calcHist([gray_bright], [0], None, [256], [0, 256])
    hist_dark = cv2.calcHist([gray_dark], [0], None, [256], [0, 256])
    hist_contrast = cv2.calcHist([gray_high_contrast], [0], None, [256], [0, 256])
    
    print("Histogram analysis:")
    print("  - Brightness adjustment shifts the entire histogram left/right")
    print("  - Contrast adjustment spreads/compresses the histogram")
    print("  (Histogram visualization requires matplotlib - see lecture)")
    print()
    
    # ========== PRACTICAL TIPS ==========
    print("6. PRACTICAL TIPS")
    print("=" * 60)
    print()
    print("Best practices:")
    print("  1. Use cv2.convertScaleAbs() for combined adjustments")
    print("  2. Use cv2.add() and cv2.subtract() to prevent overflow")
    print("  3. Start with small adjustments (alpha: 0.8-1.2, beta: ±20)")
    print("  4. Preview before saving")
    print("  5. Consider the mood you want to create")
    print()
    print("Common uses:")
    print("  - Fix underexposed photos: increase brightness + contrast")
    print("  - Fix overexposed photos: decrease brightness")
    print("  - Add drama: increase contrast")
    print("  - Create mood: adjust both carefully")
    print()
    
    # ========== SAVING ==========
    print("7. SAVING ADJUSTED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_brighter.jpg', brighter)
    cv2.imwrite('output_darker.jpg', darker)
    cv2.imwrite('output_high_contrast.jpg', high_contrast)
    cv2.imwrite('output_adjusted_combined.jpg', adjusted1)
    
    print("✓ Saved 4 adjusted images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Brightness: Add/subtract a constant (beta)")
    print("  - Contrast: Multiply by a factor (alpha)")
    print("  - Formula: output = alpha * input + beta")
    print("  - Use cv2.convertScaleAbs() for safe, combined adjustments")
    print("  - cv2.add() and cv2.subtract() prevent overflow")
    print("  - Adjust to fix problems or create artistic effects")
    print("=" * 60)

if __name__ == "__main__":
    main()
