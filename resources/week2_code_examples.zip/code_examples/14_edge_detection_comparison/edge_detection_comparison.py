"""
Edge Detection Comparison
Demonstrates different edge detection algorithms to identify boundaries in images.

Topics Covered:
- Sobel operator (horizontal and vertical edges)
- Scharr operator (improved Sobel)
- Laplacian edge detection
- Canny edge detection (most sophisticated)

Key Concepts:
- Edges = rapid changes in pixel intensity
- Different algorithms have different strengths
- Always blur before edge detection to reduce noise
- Canny is multi-stage and produces cleanest results
"""

import cv2
import numpy as np

def detect_sobel_edges(img_gray):
    """
    Sobel edge detection - detects horizontal and vertical edges separately
    
    Uses two kernels (Gx and Gy) to find edges in both directions
    """
    # Detect horizontal edges (Gx)
    sobel_x = cv2.Sobel(img_gray, cv2.CV_64F, 1, 0, ksize=3)
    
    # Detect vertical edges (Gy)
    sobel_y = cv2.Sobel(img_gray, cv2.CV_64F, 0, 1, ksize=3)
    
    # Combine both directions using magnitude
    sobel_combined = cv2.magnitude(sobel_x, sobel_y)
    
    # Convert back to uint8
    sobel_combined = np.uint8(sobel_combined)
    
    # Also return individual directions for visualization
    sobel_x_abs = np.uint8(np.absolute(sobel_x))
    sobel_y_abs = np.uint8(np.absolute(sobel_y))
    
    return sobel_x_abs, sobel_y_abs, sobel_combined

def detect_scharr_edges(img_gray):
    """
    Scharr edge detection - similar to Sobel but more accurate
    
    Better rotation invariance than Sobel
    """
    # Detect horizontal edges
    scharr_x = cv2.Scharr(img_gray, cv2.CV_64F, 1, 0)
    
    # Detect vertical edges
    scharr_y = cv2.Scharr(img_gray, cv2.CV_64F, 0, 1)
    
    # Combine both directions
    scharr_combined = cv2.magnitude(scharr_x, scharr_y)
    scharr_combined = np.uint8(scharr_combined)
    
    return scharr_combined

def detect_laplacian_edges(img_gray):
    """
    Laplacian edge detection - detects edges in all directions at once
    
    Very sensitive to noise - blur first!
    """
    # Apply Laplacian
    laplacian = cv2.Laplacian(img_gray, cv2.CV_64F)
    
    # Convert to uint8
    laplacian = np.uint8(np.absolute(laplacian))
    
    return laplacian

def detect_canny_edges(img_gray, threshold1=50, threshold2=150):
    """
    Canny edge detection - most sophisticated multi-stage algorithm
    
    Steps:
    1. Noise reduction (Gaussian blur)
    2. Gradient calculation
    3. Non-maximum suppression (thin edges)
    4. Double thresholding (strong vs weak edges)
    5. Edge tracking by hysteresis
    
    Args:
        img_gray: Grayscale image
        threshold1: Lower threshold for weak edges
        threshold2: Upper threshold for strong edges
    """
    edges = cv2.Canny(img_gray, threshold1, threshold2)
    return edges

def main():
    # Load image
    img = cv2.imread('../Resources/mountain.jpg')
    
    if img is None:
        print("Error: Could not load image")
        print("Make sure 'mountain.jpg' is in the Resources folder")
        return
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # IMPORTANT: Blur before edge detection to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    print("\nEdge Detection Demo")
    print("=" * 50)
    print("\nApplying edge detection algorithms...")
    
    # Apply different edge detection methods
    sobel_x, sobel_y, sobel_combined = detect_sobel_edges(blurred)
    scharr = detect_scharr_edges(blurred)
    laplacian = detect_laplacian_edges(blurred)
    
    # Try different Canny thresholds
    canny_weak = detect_canny_edges(blurred, 30, 90)
    canny_medium = detect_canny_edges(blurred, 50, 150)
    canny_strong = detect_canny_edges(blurred, 100, 200)
    
    # Create comparison displays
    # Convert gray to BGR for consistent display
    gray_bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    
    # Resize all images to same size for grid
    width, height = 400, 300
    
    # First comparison: Sobel directions and combined
    sobel_comparison = np.hstack([
        cv2.resize(cv2.cvtColor(sobel_x, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(sobel_y, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(sobel_combined, cv2.COLOR_GRAY2BGR), (width, height))
    ])
    
    # Add labels for Sobel
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(sobel_comparison, "Sobel X (Vertical Edges)", (10, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(sobel_comparison, "Sobel Y (Horizontal Edges)", (410, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(sobel_comparison, "Sobel Combined", (810, 30), 
                font, 0.6, (255, 255, 255), 2)
    
    # Second comparison: Different algorithms
    algorithms_comparison = np.hstack([
        cv2.resize(cv2.cvtColor(sobel_combined, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(scharr, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(laplacian, cv2.COLOR_GRAY2BGR), (width, height))
    ])
    
    cv2.putText(algorithms_comparison, "Sobel", (10, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(algorithms_comparison, "Scharr", (410, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(algorithms_comparison, "Laplacian", (810, 30), 
                font, 0.6, (255, 255, 255), 2)
    
    # Third comparison: Canny with different thresholds
    canny_comparison = np.hstack([
        cv2.resize(cv2.cvtColor(canny_weak, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(canny_medium, cv2.COLOR_GRAY2BGR), (width, height)),
        cv2.resize(cv2.cvtColor(canny_strong, cv2.COLOR_GRAY2BGR), (width, height))
    ])
    
    cv2.putText(canny_comparison, "Canny (30, 90)", (10, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(canny_comparison, "Canny (50, 150)", (410, 30), 
                font, 0.6, (255, 255, 255), 2)
    cv2.putText(canny_comparison, "Canny (100, 200)", (810, 30), 
                font, 0.6, (255, 255, 255), 2)
    
    # Display all comparisons
    cv2.imshow('Original', img)
    cv2.imshow('Blurred (reduces noise)', cv2.cvtColor(blurred, cv2.COLOR_GRAY2BGR))
    cv2.imshow('Sobel Directions', sobel_comparison)
    cv2.imshow('Algorithm Comparison', algorithms_comparison)
    cv2.imshow('Canny Thresholds', canny_comparison)
    
    print("\nKEY OBSERVATIONS:")
    print("\nSobel:")
    print("  - Fast, directional edge detection")
    print("  - X detects vertical edges, Y detects horizontal")
    print("  - Noisier than Canny")
    print("\nScharr:")
    print("  - Like Sobel but more accurate")
    print("  - Better rotation invariance")
    print("\nLaplacian:")
    print("  - Detects all directions at once")
    print("  - Very sensitive to noise!")
    print("\nCanny:")
    print("  - Most sophisticated, best results")
    print("  - Multi-stage algorithm")
    print("  - Clean, thin edges")
    print("  - Adjust thresholds: lower=more edges, higher=fewer edges")
    print("\nBEST PRACTICE:")
    print("  Always blur image before edge detection!")
    print("  Gaussian blur reduces noise and improves results")
    print("\nPress any key to exit...")
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
