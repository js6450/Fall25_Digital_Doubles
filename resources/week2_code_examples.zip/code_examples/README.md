# Week 2 Code Examples

This folder contains comprehensive code examples for Week 2: Complete Image Processing (Basic + Advanced).

## 📚 Overview

Week 2 covers ALL image processing fundamentals and advanced techniques. These examples progressively build your skills from loading images to advanced edge detection and artistic effects. Each example is self-contained and includes detailed comments and documentation.

**Note:** Due to Week 1's extended environment setup time, Week 2 now includes both basic and advanced image processing. Video processing has been moved to Week 3.

---

## 🗂️ Example Structure

### Basic Image Processing (Examples 01-10)

#### 01_image_loading_basics
**Loading, Displaying, and Saving Images**
- Read images from files using `cv2.imread()`
- Display images in windows
- Save processed images
- Handle different image formats
- Check for loading errors

#### 02_color_space_conversions
**Working with Different Color Spaces**
- BGR to RGB conversion
- BGR to Grayscale
- BGR to HSV (Hue, Saturation, Value)
- Understanding OpenCV's BGR default
- Visualizing color channels separately
- When to use different color spaces

#### 03_image_transformations
**Resizing, Rotating, and Flipping**
- Resize images to specific dimensions
- Scale by percentage
- Different interpolation methods
- Rotate images (90°, 180°, 270°)
- Flip horizontally and vertically
- Cropping regions of interest

#### 04_basic_filters
**Introduction to Image Filtering**
- Gaussian blur for smoothing
- Median blur for noise reduction
- Box blur (averaging)
- Bilateral filter (edge-preserving blur)
- When to use each filter type
- Parameter adjustment

#### 05_brightness_contrast
**Adjusting Image Brightness and Contrast**
- Increase/decrease brightness
- Adjust contrast with alpha parameter
- Combine brightness and contrast
- Safe value clipping
- Interactive adjustment

#### 06_thresholding_demo
**Binary Image Creation**
- Simple binary thresholding
- Binary inverse threshold
- Otsu's automatic threshold
- Adaptive thresholding
- Applications in image segmentation

#### 07_pixel_manipulation
**Direct Pixel Access and Modification**
- Access individual pixel values
- Modify color channels
- Create artistic effects through pixel manipulation
- Channel swapping
- Posterization effect
- Color isolation

#### 08_image_compositing
**Combining Multiple Images**
- Alpha blending (weighted averaging)
- Picture-in-picture overlays
- Creating collages
- Basic watermarking
- Region-based compositing
- Masking techniques

#### 09_complete_image_processor
**Comprehensive Image Processing Pipeline** ⭐
- Load, process, and save in one program
- Apply multiple effects in sequence
- User-controlled processing options
- Template for lab assignments
- Clean, modular code structure

#### 10_interactive_demo
**Real-time Interactive Image Effects**
- Keyboard-controlled effects switching
- Multiple filter modes
- Live parameter adjustment
- Understanding user interaction patterns
- Template for interactive projects

---

### Advanced Image Processing (Examples 11-14)

#### 11_custom_convolution
**Understanding Convolution and Custom Kernels** 🎓
- How convolution works mathematically
- Creating custom 3x3 and 5x5 kernels
- Edge detection with custom kernels
- Emboss and sharpen effects
- Understanding kernel design
- Using `cv2.filter2D()` function

#### 12_blur_filters_comparison
**Comparing Different Blur Techniques**
- Gaussian blur (smooth, natural)
- Median blur (good for salt-and-pepper noise)
- Bilateral blur (edge-preserving)
- Box blur (simple averaging)
- Motion blur (directional)
- Side-by-side comparison
- When to use each method

#### 13_sharpening_filters
**Image Sharpening Techniques** ✨
- Unsharp mask method
- Laplacian sharpening
- Custom sharpen kernels
- Adjustable sharpening strength
- Before/after visualization
- Avoiding over-sharpening artifacts

#### 14_edge_detection_comparison
**Edge Detection Algorithms** 🔍
- **Sobel** - Gradient-based edge detection
  - Vertical and horizontal edges
  - Combined gradient magnitude
- **Laplacian** - Second derivative method
  - Detects edges in all directions
  - More sensitive to noise
- **Canny** - Multi-stage algorithm
  - Automatic edge thinning
  - Hysteresis thresholding
  - Best for clean edge detection
- Compare results across all methods
- Parameter tuning for each algorithm

---

### Artistic & Advanced (Example 15)

#### 15_pixel_animation
**Creating Animated Visual Effects** 🎨 BONUS
- Time-based pixel manipulation
- Creating wave and ripple effects
- Color cycling animations
- Combining multiple effects
- Real-time generative art
- Template for creative projects

---

## 🚀 Getting Started

### Running an Example

1. Navigate to an example folder:
   ```bash
   cd 01_image_loading_basics
   ```

2. Run the Python script:
   ```bash
   python image_loading_basics.py
   ```

3. Follow any on-screen instructions for controls

### Common Controls

Most examples use these keyboard controls:
- **Q** or **ESC** - Quit the program
- **S** - Save the current image
- **Number keys (1-9)** - Switch between different effects/modes
- **Space** - Pause/resume (in animated examples)

### Requirements

All examples require:
- Python 3.8+
- OpenCV (`opencv-python`)
- NumPy

Install dependencies:
```bash
pip install opencv-python numpy
```

Or on some systems:
```bash
pip install opencv-python numpy --break-system-packages
```

---

## 📖 Learning Path

### Complete Beginner Path
Work through these examples in order:

1. **01_image_loading_basics** - Start here! Learn to load/save images
2. **02_color_space_conversions** - Understand color representation
3. **03_image_transformations** - Resize, rotate, flip
4. **04_basic_filters** - Your first image effects
5. **05_brightness_contrast** - Adjust image properties
6. **06_thresholding_demo** - Create binary images
7. **07_pixel_manipulation** - Direct pixel access
8. **08_image_compositing** - Combine images
9. **09_complete_image_processor** - Put it all together
10. **10_interactive_demo** - Add interactivity

### Advanced Student Path
After basics, focus on these:

1. **11_custom_convolution** - Understand the math behind filters
2. **12_blur_filters_comparison** - Deep dive into blurring
3. **13_sharpening_filters** - Enhance image details
4. **14_edge_detection_comparison** - Find edges and contours
5. **15_pixel_animation** - Creative applications

### For Lab Assignment
These examples are especially useful:

- **09_complete_image_processor** - Great template structure
- **10_interactive_demo** - Add user controls
- **07_pixel_manipulation** - Create unique effects
- **14_edge_detection_comparison** - Advanced technique showcase

---

## 🎯 Key Concepts by Example

| Example | Basic I/O | Color | Transform | Filter | Convolution | Edges | Interactive |
|---------|-----------|-------|-----------|--------|-------------|-------|-------------|
| 01      | ✅        |       |           |        |             |       |             |
| 02      | ✅        | ✅    |           |        |             |       |             |
| 03      | ✅        |       | ✅        |        |             |       |             |
| 04      | ✅        |       |           | ✅     |             |       |             |
| 05      | ✅        |       |           | ✅     |             |       | ✅          |
| 06      | ✅        |       |           | ✅     |             |       |             |
| 07      | ✅        | ✅    |           |        |             |       |             |
| 08      | ✅        |       |           |        |             |       |             |
| 09      | ✅        | ✅    | ✅        | ✅     |             |       | ✅          |
| 10      | ✅        |       |           | ✅     |             |       | ✅          |
| 11      | ✅        |       |           | ✅     | ✅          |       |             |
| 12      | ✅        |       |           | ✅     | ✅          |       | ✅          |
| 13      | ✅        |       |           | ✅     | ✅          |       | ✅          |
| 14      | ✅        |       |           | ✅     | ✅          | ✅    | ✅          |
| 15      | ✅        | ✅    |           |        |             |       | ✅          |

---

## 💡 Tips for Learning

1. **Start with example 01** - Don't skip the basics!
2. **Run before reading** - See what the example does first
3. **Read the docstrings** - Each file has detailed documentation
4. **Experiment with parameters** - Change values and see what happens
5. **Combine techniques** - Mix code from multiple examples
6. **Use provided images** - The Resources folder has test images
7. **Try your own images** - See how effects work on different content
8. **Build on templates** - Examples 09 and 10 are great starting points

---

## 🔧 Troubleshooting

### Image won't load
- Check file path is correct
- Make sure image file exists in Resources folder
- Verify image format is supported (.jpg, .png, .bmp)
- Look for None return value from cv2.imread()

### Window doesn't display
- Make sure you called cv2.imshow()
- Did you call cv2.waitKey()?
- Try cv2.waitKey(0) for indefinite wait
- Check cv2.destroyAllWindows() is called

### Colors look wrong
- OpenCV uses BGR, not RGB by default
- Convert with cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
- Or swap channels manually: img[:,:,[2,1,0]]

### Program is slow
- Reduce image size with cv2.resize()
- Use smaller kernel sizes
- Simplify the processing pipeline
- Check for infinite loops

### Import errors
Install missing packages:
```bash
pip install opencv-python numpy matplotlib
```

---

## 📝 Lab 1 Assignment Tips

For your Lab 1 assignment:

**Requirements:**
- Load at least one image
- Apply at least 3 different transformations/effects
- Display original and processed images
- Save the results
- Document your code with comments

**Good Examples to Reference:**
- Use **09_complete_image_processor** as your template
- Get effect ideas from **04, 12, 13, 14**
- Learn compositing from **08**
- See interactive controls in **10**

**Creative Ideas:**
- Combine filters in unique ways
- Create artistic effects with pixel manipulation (07)
- Apply edge detection creatively (14)
- Try custom kernels (11)
- Make animated effects (15)

**Documentation:**
- Comment each major code block
- Explain parameter choices
- Note if you used AI assistance
- Include before/after examples in your submission

---

## 🎓 Conceptual Understanding

### What is Convolution?
Examples 11-14 focus on convolution - a fundamental operation in image processing:
- Slides a small matrix (kernel) across the image
- Multiplies and sums values at each position
- Creates effects like blur, sharpen, edge detection
- Foundation for many advanced CV techniques

### Color Spaces Matter
Example 02 shows why color spaces are important:
- **BGR**: OpenCV's default (for historical reasons)
- **RGB**: Standard for most other libraries
- **Grayscale**: Single channel, simpler/faster
- **HSV**: Better for color-based selection

### Filters vs Kernels
- **Filter**: General term for image transformation
- **Kernel**: Small matrix used in convolution
- Examples 04 use built-in filters
- Examples 11-14 use custom kernels

---

## 🌟 Featured Examples

**Best for understanding basics:**
- Example 01 (image loading) - Start here!
- Example 02 (color spaces) - Essential concept
- Example 04 (basic filters) - Your first effects

**Best for lab assignments:**
- Example 09 (complete processor) ⭐ - Full template
- Example 10 (interactive demo) - Add user controls

**Best for understanding advanced concepts:**
- Example 11 (convolution) - See the math
- Example 14 (edge detection) 🔍 - Compare algorithms

**Best for creative projects:**
- Example 07 (pixel manipulation) - Unique effects
- Example 15 (animation) 🎨 - Generative art

---

## 📚 Resources

### In This Folder
- `Resources/` - Sample images for testing
  - mountain.jpg
  - ocean.jpg
  - pinkflower.jpg
  - whiteflower.jpg

### Course Materials
- `Week2_Lecture_Notes.md` - Detailed explanations
- `Week2_Slides_Content.md` - Slide reference
- Course Google Drive - Additional resources

### External Resources
- [OpenCV Python Tutorials](https://docs.opencv.org/master/d6/d00/tutorial_py_root.html)
- [OpenCV Documentation](https://docs.opencv.org/)
- [NumPy Documentation](https://numpy.org/doc/)

---

## 🎯 Next Steps

After completing Week 2 examples:

1. ✅ Complete Lab 1 assignment (due Week 3)
2. 📖 Read Week 2 assigned reading (Hito Steyerl - "In Defense of the Poor Image")
3. 🎥 Prepare for Week 3: Live Video Capture & Real-time Processing
4. 💡 Start thinking about your final project concept
5. 🔬 Experiment with combining techniques from multiple examples

---

## 📞 Need Help?

- Review the lecture notes: `Week2_Lecture_Notes.md`
- Check the slides: `Week2_Slides_Content.md`
- Attend office hours: jiwon.shin@nyu.edu
- Post in class discussion forum
- Ask questions during class

---

## ✅ Week 2 Learning Checklist

By the end of Week 2, you should be able to:
- [ ] Load, display, and save images
- [ ] Convert between color spaces (BGR, RGB, Grayscale, HSV)
- [ ] Resize, rotate, and flip images
- [ ] Apply basic filters (blur, sharpen)
- [ ] Adjust brightness and contrast
- [ ] Create binary images with thresholding
- [ ] Access and modify individual pixels
- [ ] Combine multiple images
- [ ] Understand convolution and kernels
- [ ] Detect edges using Sobel, Laplacian, and Canny
- [ ] Create an interactive image processing program

If you can check most of these boxes, you're ready for Week 3! 🎉

---

**Happy coding! 🚀**

*Remember: The best way to learn is by experimenting. Break things, try new combinations, and have fun!*

---

*Last updated: October 30, 2025*  
*Week 2 now includes ALL image processing (basic + advanced). Video processing moved to Week 3.*
