# Week 2 Code Examples

This folder contains comprehensive code examples for Week 2: Advanced Image Processing & Video Fundamentals.

## 📚 Overview

These examples progressively build your skills in image and video processing, from basic filters to advanced motion detection. Each example is self-contained and includes detailed comments and documentation.

## 🗂️ Example Structure

### Image Processing (Examples 01-04)

#### 01_custom_convolution
**Custom Kernels with filter2D**
- Learn how convolution works
- Create custom image filters
- Understand kernel operations
- Experiment with different kernel designs

#### 02_blur_filters_comparison
**Comparing Different Blur Methods**
- Gaussian blur
- Median blur
- Bilateral blur
- Box blur
- Side-by-side comparison

#### 03_sharpening_filters
**Image Sharpening Techniques**
- Unsharp mask method
- Custom sharpen kernels
- Parameter adjustment
- Before/after visualization

#### 04_edge_detection_comparison
**Edge Detection Algorithms**
- Sobel edge detection
- Laplacian edge detection
- Canny edge detection
- Compare results across methods

---

### Video Fundamentals (Examples 05-07)

#### 05_video_capture_basics
**Reading Video from Webcam and Files**
- Initialize video capture
- Read frames in a loop
- Handle webcam vs. file input
- Basic frame display

#### 06_video_properties
**Getting and Setting Video Properties**
- Read frame rate, resolution
- Set capture properties
- Display video metadata
- Handle different video sources

#### 07_video_processing_effects
**Real-time Filter Application**
- Apply filters to live video
- Switch effects with keyboard
- Multiple effect options (blur, edge, sharpen, etc.)
- Interactive control system

---

### Motion Detection (Examples 08-10)

#### 08_frame_differencing
**Basic Motion Detection**
- Frame-by-frame comparison
- Absolute difference calculation
- Threshold adjustment
- Motion visualization

#### 09_motion_detection_complete
**Robust Motion Detection with Contours** ⭐
- Complete motion detection pipeline
- Noise reduction with morphology
- Contour detection
- Bounding box tracking
- Area filtering

#### 10_background_subtraction
**Advanced Background Modeling**
- MOG2 (Mixture of Gaussians)
- KNN (K-Nearest Neighbors)
- Compare algorithms
- Shadow detection
- Learning rate adjustment

---

### Comprehensive Examples

#### 11_interactive_video_processor
**Complete Interactive System** ⭐ CAPSTONE EXAMPLE
- **5 different processing modes:**
  1. FILTERS - Various image filters
  2. MOTION - Frame differencing
  3. BACKGROUND - Background subtraction
  4. HYBRID - Combined effects
  5. ORIGINAL - No processing
- Real-time parameter adjustment
- Comprehensive UI and controls
- Template for your projects
- Clean, modular architecture

#### 12_video_recording
**Saving Processed Video** 🎁 BONUS
- Record video to file
- Multiple codec options
- Screenshot capture
- Recording controls
- Output management

---

## 🚀 Getting Started

### Running an Example

1. Navigate to an example folder:
   ```bash
   cd 01_custom_convolution
   ```

2. Run the Python script:
   ```bash
   python custom_convolution.py
   ```

3. Follow the on-screen instructions for controls

### General Controls

Most examples use similar keyboard controls:
- **Q** - Quit the program
- **Space** - Start/stop (for recording examples)
- **Number keys** - Switch modes
- **Letter keys** - Apply effects or adjust parameters

### Requirements

All examples require:
- Python 3.8+
- OpenCV (cv2)
- NumPy

Install dependencies:
```bash
pip install opencv-python numpy
```

---

## 📖 Learning Path

### For Beginners
Start with these examples in order:
1. **01_custom_convolution** - Understand basic filtering
2. **02_blur_filters_comparison** - See different blur methods
3. **05_video_capture_basics** - Learn video basics
4. **07_video_processing_effects** - Combine images + video

### For Intermediate Students
Try these more advanced examples:
1. **08_frame_differencing** - Motion detection basics
2. **09_motion_detection_complete** - Full motion pipeline
3. **10_background_subtraction** - Advanced algorithms
4. **11_interactive_video_processor** - Put it all together

### For Advanced Projects
Use these as templates:
- **11_interactive_video_processor** - Complete interactive system
- **12_video_recording** - Save your work

---

## 🎯 Key Concepts by Example

| Example | Convolution | Video I/O | Motion | Morphology | Contours | UI/Controls |
|---------|-------------|-----------|--------|------------|----------|-------------|
| 01      | ✅          |           |        |            |          |             |
| 02      | ✅          |           |        |            |          |             |
| 03      | ✅          |           |        |            |          |             |
| 04      | ✅          |           |        |            |          | ✅          |
| 05      |             | ✅        |        |            |          |             |
| 06      |             | ✅        |        |            |          |             |
| 07      | ✅          | ✅        |        |            |          | ✅          |
| 08      |             | ✅        | ✅     |            |          | ✅          |
| 09      |             | ✅        | ✅     | ✅         | ✅       | ✅          |
| 10      |             | ✅        | ✅     | ✅         | ✅       | ✅          |
| 11      | ✅          | ✅        | ✅     | ✅         | ✅       | ✅          |
| 12      | ✅          | ✅        |        |            |          | ✅          |

---

## 💡 Tips for Learning

1. **Run the examples first** - See what they do before reading the code
2. **Read the docstrings** - Each file has detailed documentation at the top
3. **Experiment with parameters** - Change threshold values, kernel sizes, etc.
4. **Combine techniques** - Use code from multiple examples in your projects
5. **Build on the templates** - Examples 11 and 12 are great starting points

---

## 🔧 Troubleshooting

### Webcam not working?
All examples automatically fall back to video files from the Resources folder if webcam is unavailable.

### Video won't play?
Make sure the Resources folder contains the required video files:
- `walking_on_the_beach.mp4`
- `ocean_waves.mp4`
- `soccer.mp4`
- `ice_hockey.mp4`

### Performance issues?
- Reduce frame size in the resize operations
- Close other applications
- Try simpler filters first

### Import errors?
Install required packages:
```bash
pip install opencv-python numpy --break-system-packages
```

---

## 📝 Lab Assignment Tips

For your lab assignments, you can:
- **Modify parameters** in any example to see different results
- **Combine techniques** from multiple examples
- **Use example 11** as a template for your own interactive system
- **Add new filters** by following the pattern in examples 07 and 11

---

## 🎓 Next Steps

After completing these examples:
1. Complete the Week 2 lab assignment
2. Experiment with combining different techniques
3. Try applying filters to your own images/videos
4. Start thinking about your final project
5. Move on to Week 3 for live video capture and real-time processing

---

## 📞 Need Help?

- Check the lecture notes in `Week2_Lecture_Notes.md`
- Review the slides content in `Week2_Slides_Content.md`
- Post questions in the class forum
- Attend office hours

---

## 🌟 Featured Examples

**Best for learning concepts:**
- Example 01 (custom convolution)
- Example 08 (frame differencing)

**Best for project templates:**
- Example 11 (interactive processor) ⭐
- Example 12 (video recording) 🎁

**Best for understanding algorithms:**
- Example 09 (motion detection complete)
- Example 10 (background subtraction)

---

Happy coding! 🚀

Remember: The best way to learn is by experimenting. Don't be afraid to break things and try new ideas!
