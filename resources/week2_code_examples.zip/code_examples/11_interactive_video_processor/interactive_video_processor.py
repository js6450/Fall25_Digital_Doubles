"""
Week 2 - Example 11: Interactive Video Processor ⭐
Comprehensive example combining all Week 2 concepts

This is the capstone example for Week 2, combining:
- Multiple image processing filters
- Real-time video manipulation
- Motion detection
- Background subtraction
- Interactive keyboard controls
- Multi-mode visualization

This example serves as a complete template for students to:
- Understand full video processing pipelines
- See how different techniques can be combined
- Build their own interactive video applications
- Experiment with different effects and parameters

Students can use this as a starting point for their lab assignments
and final projects.

Key Features:
- 5 different processing modes
- Real-time parameter adjustment
- Multiple visualization options
- Clean, modular code structure
- Extensive documentation

Modes:
1. FILTERS: Apply various image filters (blur, edge, sharpen, etc.)
2. MOTION: Frame differencing motion detection
3. BACKGROUND: Background subtraction
4. HYBRID: Combine filters with motion/background
5. ORIGINAL: No processing

Usage:
- Number keys 1-5: Switch between modes
- Letter keys: Apply different effects (mode-dependent)
- 't'/'+'/'-': Adjust thresholds/parameters
- 'h': Toggle help display
- 'q': Quit
"""

import cv2
import numpy as np

# ==================== FILTER FUNCTIONS ====================

def apply_blur(frame, kernel_size=15):
    """Apply Gaussian blur"""
    return cv2.GaussianBlur(frame, (kernel_size, kernel_size), 0)

def apply_edge_detection(frame):
    """Apply Canny edge detection"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

def apply_sharpening(frame):
    """Apply sharpening filter"""
    kernel = np.array([[-1, -1, -1],
                       [-1,  9, -1],
                       [-1, -1, -1]])
    return cv2.filter2D(frame, -1, kernel)

def apply_grayscale(frame):
    """Convert to grayscale"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

def apply_negative(frame):
    """Apply negative effect"""
    return cv2.bitwise_not(frame)

def apply_emboss(frame):
    """Apply emboss effect"""
    kernel = np.array([[-2, -1, 0],
                       [-1,  1, 1],
                       [ 0,  1, 2]])
    embossed = cv2.filter2D(frame, -1, kernel)
    return cv2.cvtColor(cv2.cvtColor(embossed, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR)

# ==================== MOTION DETECTION CLASS ====================

class MotionDetector:
    """Simple motion detection using frame differencing"""
    
    def __init__(self, threshold=25):
        self.threshold = threshold
        self.prev_frame = None
    
    def detect(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        
        if self.prev_frame is None:
            self.prev_frame = gray
            return np.zeros_like(gray), []
        
        frame_diff = cv2.absdiff(self.prev_frame, gray)
        _, thresh = cv2.threshold(frame_diff, self.threshold, 255, cv2.THRESH_BINARY)
        
        # Apply morphology
        kernel = np.ones((5, 5), np.uint8)
        thresh = cv2.dilate(thresh, kernel, iterations=2)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, 
                                       cv2.CHAIN_APPROX_SIMPLE)
        
        self.prev_frame = gray
        return thresh, contours

# ==================== MAIN PROCESSOR CLASS ====================

class InteractiveVideoProcessor:
    """
    Main video processing class with multiple modes
    """
    
    def __init__(self):
        # Video capture
        self.cap = None
        self.frame_width = 640
        self.frame_height = 480
        
        # Processing modes
        self.modes = {
            '1': 'FILTERS',
            '2': 'MOTION',
            '3': 'BACKGROUND',
            '4': 'HYBRID',
            '5': 'ORIGINAL'
        }
        self.current_mode = 'FILTERS'
        
        # Filter effects
        self.filters = {
            'o': ('Original', lambda x: x),
            'b': ('Blur', apply_blur),
            'e': ('Edge Detection', apply_edge_detection),
            'g': ('Grayscale', apply_grayscale),
            's': ('Sharpen', apply_sharpening),
            'n': ('Negative', apply_negative),
            'm': ('Emboss', apply_emboss)
        }
        self.current_filter = 'o'
        
        # Motion detection
        self.motion_detector = MotionDetector(threshold=25)
        self.motion_threshold = 25
        
        # Background subtraction
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=16, detectShadows=True
        )
        
        # UI settings
        self.show_help = True
        
    def initialize_capture(self):
        """Initialize video capture"""
        # Try webcam first
        self.cap = cv2.VideoCapture(0)
        
        if not self.cap.isOpened():
            print("Webcam not available, using video file...")
            self.cap = cv2.VideoCapture('../Resources/walking_on_the_beach.mp4')
        
        return self.cap.isOpened()
    
    def process_frame(self, frame):
        """
        Process frame based on current mode
        
        Returns:
            processed_frame, info_text
        """
        info = []
        
        if self.current_mode == 'ORIGINAL':
            result = frame.copy()
            info.append("Mode: Original (No Processing)")
        
        elif self.current_mode == 'FILTERS':
            filter_name, filter_func = self.filters[self.current_filter]
            result = filter_func(frame)
            info.append(f"Mode: FILTERS - {filter_name}")
        
        elif self.current_mode == 'MOTION':
            # Motion detection
            motion_mask, contours = self.motion_detector.detect(frame)
            
            # Draw contours on frame
            result = frame.copy()
            cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
            
            # Count objects
            num_objects = len([c for c in contours if cv2.contourArea(c) > 500])
            
            info.append(f"Mode: MOTION DETECTION")
            info.append(f"Threshold: {self.motion_threshold}")
            info.append(f"Objects detected: {num_objects}")
        
        elif self.current_mode == 'BACKGROUND':
            # Background subtraction
            fg_mask = self.bg_subtractor.apply(frame)
            
            # Process mask
            kernel = np.ones((3, 3), np.uint8)
            fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
            fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
            
            # Apply mask to original
            result = cv2.bitwise_and(frame, frame, mask=fg_mask)
            
            # Find contours
            contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, 
                                          cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
            
            info.append(f"Mode: BACKGROUND SUBTRACTION")
            info.append(f"Foreground objects: {len(contours)}")
        
        elif self.current_mode == 'HYBRID':
            # Apply filter first
            filter_name, filter_func = self.filters[self.current_filter]
            filtered = filter_func(frame)
            
            # Then apply motion detection
            motion_mask, contours = self.motion_detector.detect(frame)
            
            result = filtered.copy()
            cv2.drawContours(result, contours, -1, (0, 255, 0), 2)
            
            info.append(f"Mode: HYBRID - {filter_name} + Motion")
        
        return result, info
    
    def draw_ui(self, frame, info):
        """Draw UI elements on frame"""
        result = frame.copy()
        
        # Draw info text
        y_pos = 30
        for text in info:
            cv2.putText(result, text, (10, y_pos), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            y_pos += 30
        
        # Draw help if enabled
        if self.show_help:
            self.draw_help(result)
        
        return result
    
    def draw_help(self, frame):
        """Draw help overlay"""
        help_text = [
            "=== CONTROLS ===",
            "Modes:",
            "  1: Filters",
            "  2: Motion Detection",
            "  3: Background Subtraction",
            "  4: Hybrid (Filter + Motion)",
            "  5: Original",
            "",
            "Filters (in FILTERS/HYBRID mode):",
            "  b: Blur",
            "  e: Edge Detection",
            "  g: Grayscale",
            "  s: Sharpen",
            "  n: Negative",
            "  m: Emboss",
            "",
            "Other:",
            "  h: Toggle this help",
            "  q: Quit"
        ]
        
        # Semi-transparent overlay
        overlay = frame.copy()
        cv2.rectangle(overlay, (frame.shape[1] - 400, 0), 
                     (frame.shape[1], len(help_text) * 25 + 20), 
                     (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Draw text
        y_pos = 25
        for text in help_text:
            cv2.putText(frame, text, (frame.shape[1] - 390, y_pos), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            y_pos += 25
    
    def handle_key(self, key):
        """Handle keyboard input"""
        if key == ord('q'):
            return False
        
        # Mode switching
        if chr(key) in self.modes:
            self.current_mode = self.modes[chr(key)]
            print(f"Switched to mode: {self.current_mode}")
        
        # Filter switching
        elif chr(key) in self.filters:
            self.current_filter = chr(key)
            filter_name = self.filters[chr(key)][0]
            print(f"Switched to filter: {filter_name}")
        
        # Toggle help
        elif key == ord('h'):
            self.show_help = not self.show_help
            print(f"Help: {'ON' if self.show_help else 'OFF'}")
        
        # Adjust motion threshold
        elif key == ord('t'):
            self.motion_threshold = (self.motion_threshold + 10) % 100 + 10
            self.motion_detector.threshold = self.motion_threshold
            print(f"Motion threshold: {self.motion_threshold}")
        
        return True
    
    def run(self):
        """Main processing loop"""
        if not self.initialize_capture():
            print("Error: Could not open video source")
            return
        
        print("=" * 60)
        print("Interactive Video Processor")
        print("=" * 60)
        print("This example combines all Week 2 concepts:")
        print("  - Multiple image filters")
        print("  - Motion detection")
        print("  - Background subtraction")
        print("  - Hybrid effects")
        print("\nPress 'h' to toggle help overlay")
        print("Press 'q' to quit")
        print("=" * 60)
        
        while True:
            ret, frame = self.cap.read()
            
            if not ret:
                # Loop video
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue
            
            # Resize frame
            frame = cv2.resize(frame, (self.frame_width, self.frame_height))
            
            # Process frame
            processed, info = self.process_frame(frame)
            
            # Draw UI
            result = self.draw_ui(processed, info)
            
            # Display
            cv2.imshow('Interactive Video Processor', result)
            
            # Handle input
            key = cv2.waitKey(30) & 0xFF
            if not self.handle_key(key):
                break
        
        # Cleanup
        self.cap.release()
        cv2.destroyAllWindows()
        print("Processing stopped.")

# ==================== MAIN ====================

def main():
    processor = InteractiveVideoProcessor()
    processor.run()

if __name__ == "__main__":
    main()
