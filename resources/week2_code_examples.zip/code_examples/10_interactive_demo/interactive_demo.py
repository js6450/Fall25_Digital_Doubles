"""
Interactive Image Processing Demo (BONUS)
Digital Doubles - Week 1

This is an optional bonus example that demonstrates real-time image processing
using OpenCV trackbars. You can adjust parameters interactively and see
the results immediately.

Features:
- Brightness and contrast adjustment with sliders
- Blur strength control
- Threshold value control
- Real-time preview

This is great for experimenting and understanding how different parameter
values affect the output!

Press 'q' to quit, 's' to save current result.
"""

import cv2
import numpy as np

class InteractiveProcessor:
    """
    Interactive image processor with trackbar controls.
    """
    
    def __init__(self, image_path):
        """Initialize the processor with an image."""
        self.original = cv2.imread(image_path)
        if self.original is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Resize if image is too large
        height, width = self.original.shape[:2]
        if width > 1200 or height > 800:
            scale = min(1200/width, 800/height)
            self.original = cv2.resize(self.original, None, fx=scale, fy=scale)
        
        self.current_mode = 'brightness'
        self.window_name = 'Interactive Image Processor (Press Q to quit, S to save)'
        
        # Default values
        self.brightness = 50  # 0-100, 50 is neutral
        self.contrast = 50    # 0-100, 50 is neutral (1.0x)
        self.blur = 0         # 0-50, 0 is no blur
        self.threshold = 127  # 0-255
        
    def nothing(self, x):
        """Callback function for trackbars (required but does nothing)."""
        pass
    
    def brightness_contrast_mode(self):
        """Mode for adjusting brightness and contrast."""
        cv2.namedWindow(self.window_name)
        
        # Create trackbars
        cv2.createTrackbar('Brightness', self.window_name, 
                          self.brightness, 100, self.nothing)
        cv2.createTrackbar('Contrast', self.window_name, 
                          self.contrast, 100, self.nothing)
        
        print("=" * 60)
        print("BRIGHTNESS & CONTRAST MODE")
        print("=" * 60)
        print("Adjust sliders to see real-time changes")
        print("  Brightness: 0-100 (50 = neutral)")
        print("  Contrast: 0-100 (50 = neutral)")
        print()
        print("Controls:")
        print("  Press 's' to save current image")
        print("  Press 'q' to quit")
        print("=" * 60)
        print()
        
        while True:
            # Get current trackbar positions
            brightness = cv2.getTrackbarPos('Brightness', self.window_name)
            contrast = cv2.getTrackbarPos('Contrast', self.window_name)
            
            # Convert to processing values
            # Brightness: 0-100 → -50 to +50
            beta = brightness - 50
            # Contrast: 0-100 → 0.5 to 1.5
            alpha = contrast / 50.0
            
            # Apply adjustments
            result = cv2.convertScaleAbs(self.original, alpha=alpha, beta=beta)
            
            # Display current values
            cv2.putText(result, f'Brightness: {beta:+d}', (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(result, f'Contrast: {alpha:.2f}x', (10, 60), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            # Show result
            cv2.imshow(self.window_name, result)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                filename = f'interactive_brightness{beta}_contrast{alpha:.2f}.jpg'
                cv2.imwrite(filename, result)
                print(f"Saved: {filename}")
        
        cv2.destroyAllWindows()
    
    def blur_mode(self):
        """Mode for adjusting blur."""
        cv2.namedWindow(self.window_name)
        
        # Create trackbar
        cv2.createTrackbar('Blur Strength', self.window_name, 
                          self.blur, 50, self.nothing)
        
        print("=" * 60)
        print("BLUR MODE")
        print("=" * 60)
        print("Adjust slider to see real-time blur changes")
        print("  Blur: 0-50 (0 = no blur)")
        print()
        print("Controls:")
        print("  Press 's' to save current image")
        print("  Press 'q' to quit")
        print("=" * 60)
        print()
        
        while True:
            # Get current trackbar position
            blur_strength = cv2.getTrackbarPos('Blur Strength', self.window_name)
            
            # Apply blur (convert to odd number for kernel size)
            if blur_strength == 0:
                result = self.original.copy()
            else:
                kernel_size = blur_strength * 2 + 1  # Ensure odd number
                result = cv2.GaussianBlur(self.original, (kernel_size, kernel_size), 0)
            
            # Display current value
            cv2.putText(result, f'Blur: {blur_strength}', (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            # Show result
            cv2.imshow(self.window_name, result)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                filename = f'interactive_blur{blur_strength}.jpg'
                cv2.imwrite(filename, result)
                print(f"Saved: {filename}")
        
        cv2.destroyAllWindows()
    
    def threshold_mode(self):
        """Mode for adjusting threshold."""
        # Convert to grayscale
        gray = cv2.cvtColor(self.original, cv2.COLOR_BGR2GRAY)
        
        cv2.namedWindow(self.window_name)
        
        # Create trackbar
        cv2.createTrackbar('Threshold', self.window_name, 
                          self.threshold, 255, self.nothing)
        
        print("=" * 60)
        print("THRESHOLD MODE")
        print("=" * 60)
        print("Adjust slider to see real-time threshold changes")
        print("  Threshold: 0-255")
        print("  Working on grayscale version of image")
        print()
        print("Controls:")
        print("  Press 's' to save current image")
        print("  Press 'q' to quit")
        print("=" * 60)
        print()
        
        while True:
            # Get current trackbar position
            thresh_val = cv2.getTrackbarPos('Threshold', self.window_name)
            
            # Apply threshold
            _, result = cv2.threshold(gray, thresh_val, 255, cv2.THRESH_BINARY)
            
            # Convert back to BGR for display
            result_bgr = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
            
            # Display current value
            cv2.putText(result_bgr, f'Threshold: {thresh_val}', (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            # Show result
            cv2.imshow(self.window_name, result_bgr)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                filename = f'interactive_threshold{thresh_val}.jpg'
                cv2.imwrite(filename, result)
                print(f"Saved: {filename}")
        
        cv2.destroyAllWindows()

def main():
    """Main function with mode selection."""
    print()
    print("=" * 60)
    print("        INTERACTIVE IMAGE PROCESSOR (BONUS)")
    print("             Digital Doubles - Week 1")
    print("=" * 60)
    print()
    print("This demo lets you adjust image processing parameters")
    print("in real-time using trackbar sliders!")
    print()
    
    # Default image
    default_image = '../Resources/pinkflower.jpg'
    
    try:
        processor = InteractiveProcessor(default_image)
    except ValueError as e:
        print(f"Error: {e}")
        return
    
    print(f"✓ Image loaded: {default_image}")
    print()
    print("Select a mode:")
    print("  1. Brightness & Contrast")
    print("  2. Blur")
    print("  3. Threshold")
    print("  4. Exit")
    print()
    
    choice = input("Enter your choice (1-4): ").strip()
    print()
    
    if choice == '1':
        processor.brightness_contrast_mode()
    elif choice == '2':
        processor.blur_mode()
    elif choice == '3':
        processor.threshold_mode()
    elif choice == '4':
        print("Goodbye!")
    else:
        print("Invalid choice.")
    
    print()
    print("=" * 60)
    print("Thanks for using the Interactive Processor!")
    print("=" * 60)

if __name__ == "__main__":
    main()
