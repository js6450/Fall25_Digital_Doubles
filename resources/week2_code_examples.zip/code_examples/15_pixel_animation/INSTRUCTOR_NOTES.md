# Week 1 Supplementary Material: Pixel Animation Examples

## Summary for Instructor (Jiwon Shin)

### What Was Created

I've added a new **Example 12: Pixel Animation** to supplement the Week 1 code examples. This example teaches students how to create animations by varying pixel values over time.

### Location
`/DigitalDoubles/Week1/code_examples/12_pixel_animation/`

### Files Created

1. **pixel_animation_template.py** (RECOMMENDED START)
   - Blank template for students to create their own animations
   - Includes one simple example (brightness pulse)
   - Contains 8 animation ideas at the bottom with code snippets
   - Well-commented for students to understand what to modify
   - **Best for:** Students who want to experiment immediately

2. **pixel_animation_simple.py** (BEGINNER LEVEL)
   - Three simple animations to understand basics
   - Brightness pulse, color shift, and moving gradient
   - Clean, readable code with detailed comments
   - Runs automatically through all three animations
   - **Best for:** Understanding fundamental concepts

3. **pixel_animation.py** (ADVANCED LEVEL)
   - Six sophisticated animation techniques
   - Interactive controls (number keys to switch, 's' to save frames)
   - More complex effects: waves, glitches, pixelation
   - **Best for:** Students who want to see advanced possibilities

4. **README.md**
   - Comprehensive documentation
   - Learning objectives
   - Customization ideas
   - Technical notes and troubleshooting
   - Related concepts and next steps

### Learning Objectives

Students will learn:
1. How to use frame count as a time variable
2. How to create smooth animations using mathematical functions (sine, cosine)
3. How to modify pixel values based on both time and spatial position
4. Different animation techniques for various effects
5. Performance considerations for real-time animation

### How These Examples Fit Into Week 1

These examples bridge Week 1 and Week 2 concepts:
- **Builds on Week 1:** Pixel manipulation, color spaces, image transformations
- **Prepares for Week 2:** Real-time video processing, frame-by-frame manipulation
- **Standalone value:** Demonstrates creative applications of fundamental concepts

### Technical Details

**Dependencies:**
- OpenCV (cv2)
- NumPy
- Python math library
- All standard Week 1 requirements

**Performance:**
- Scripts automatically resize large images for smooth playback
- Target: 30 FPS
- Works with Week 1 resource images

**Controls:**
- 'q' = quit
- 's' = save frame (advanced version)
- '1-6' = switch animations (advanced version)
- 'n' = next animation (simple version)

### Pedagogical Approach

**Progressive Difficulty:**
1. Start with template (hands-on experimentation)
2. Move to simple examples (understanding concepts)
3. Explore advanced examples (see possibilities)

**Key Teaching Moments:**
- Frame count as time variable (fundamental concept)
- Mathematical functions create smooth animations
- Combining spatial (x, y) and temporal (frame) dimensions
- Importance of clipping values and type conversion
- Creative applications of technical concepts

### Suggested Class Usage

**Option 1: Quick Demo (10 minutes)**
- Show `pixel_animation.py` with different effects
- Discuss how frame count creates time-based animation
- Have students identify which effects they find interesting

**Option 2: Lab Activity (30 minutes)**
- Students use `pixel_animation_template.py`
- Challenge: Create one unique animation
- Share results with class
- Discuss different approaches

**Option 3: Homework Extension**
- Students modify one of the simple examples
- Add their own animation to the template
- Document what mathematical function they used and why

### Integration with Course Materials

**Connects to:**
- Week 1, Example 08: Pixel Manipulation (direct pixel access)
- Week 1, Example 06: Brightness and Contrast (pixel value modification)
- Week 2: Video Processing (frame-by-frame thinking)
- Week 3: Real-time processing (live effects)

**Supports Final Project:**
- Digital installation with live video capture
- Real-time effects and transformations
- Creative use of computer vision

### Updates Made

Also updated the main `Week1/code_examples/README.md` to include this new example as Example 12.

### Testing Recommendations

Before class:
1. Run `pixel_animation_simple.py` to verify it works
2. Try the template to ensure students can easily modify it
3. Check that all animations run smoothly on the classroom computer

### Potential Discussion Points

1. **Mathematical Functions in Art:**
   - How do sine waves create natural-looking motion?
   - What other mathematical patterns could be interesting?

2. **Time in Digital Media:**
   - How is time represented in code?
   - Discrete (frames) vs. continuous (actual time)

3. **Performance vs. Quality:**
   - Why resize images?
   - Trade-offs in real-time processing

4. **From Static to Dynamic:**
   - How does thinking about time change image processing?
   - Preparing for video (Week 2)

### Additional Resources for Students

Mentioned in README:
- Mathematical function references
- Animation timing concepts
- Color space considerations for animation
- Links to related examples

---

## Quick Reference: Running the Examples

```bash
cd DigitalDoubles/Week1/code_examples/12_pixel_animation

# Start with template (recommended for experimentation)
python pixel_animation_template.py

# Or view simple examples (recommended for learning)
python pixel_animation_simple.py

# Or explore advanced demos
python pixel_animation.py
```

---

**Created:** October 2025  
**Status:** Ready for use in Week 1  
**Prerequisites:** Completion of examples 01-08
