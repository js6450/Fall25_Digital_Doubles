"""
Pixel Animation Examples
Week 1 - Digital Doubles
Supplementary Code Example

This script demonstrates how to create animations by varying pixel values over time.
We'll explore several animation techniques:
1. Wave effects - creating ripples across the image
2. Color cycling - animating through color channels
3. Brightness pulsing - rhythmic brightness changes
4. Pixelation animation - dynamic mosaic effects
5. RGB channel rotation - shifting color channels over time
6. Glitch effects - random pixel displacement

Press 'q' to quit during any animation
Press 's' to save a frame during animation
Press 1-6 to switch between different animations
"""

import cv2
import numpy as np
import time
import math

def load_image(image_path):
    """Load an image and handle errors."""
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Could not load image at {image_path}")
        return None
    return img

def wave_effect(img, frame_count):
    """
    Create a wave effect that ripples across the image.
    Uses sine wave to modulate pixel brightness based on position and time.
    """
    result = img.copy().astype(float)
    height, width = img.shape[:2]
    
    # Calculate wave parameters
    frequency = 0.05  # How many waves across the image
    speed = 0.1  # How fast the wave moves
    amplitude = 30  # How strong the brightness change is
    
    # Create coordinate grids
    x = np.arange(width)
    y = np.arange(height)
    X, Y = np.meshgrid(x, y)
    
    # Calculate wave offset based on position and time
    wave = amplitude * np.sin(frequency * X + frequency * Y + speed * frame_count)
    
    # Apply wave to all color channels
    for channel in range(3):
        result[:, :, channel] += wave
    
    # Clip values to valid range
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def color_cycle(img, frame_count):
    """
    Cycle through color channels, creating a rainbow-like animation effect.
    Rotates the hue in HSV color space.
    """
    # Convert to HSV for easier color manipulation
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(float)
    
    # Shift the hue channel based on frame count
    hue_shift = (frame_count * 2) % 180  # OpenCV uses 0-180 for hue
    hsv[:, :, 0] = (hsv[:, :, 0] + hue_shift) % 180
    
    # Convert back to BGR
    hsv = hsv.astype(np.uint8)
    result = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    
    return result

def brightness_pulse(img, frame_count):
    """
    Create a pulsing brightness effect using a sine wave.
    The entire image brightens and darkens rhythmically.
    """
    result = img.copy().astype(float)
    
    # Calculate brightness multiplier using sine wave
    # Maps sine output (-1 to 1) to brightness range (0.5 to 1.5)
    pulse = 0.5 + 0.5 * math.sin(frame_count * 0.1)
    brightness_factor = 0.5 + pulse
    
    # Apply brightness change
    result = result * brightness_factor
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def pixelation_animation(img, frame_count):
    """
    Animate pixelation level - creates a dynamic mosaic effect.
    Pixel block size varies over time using a sine wave.
    """
    # Calculate pixel size (oscillates between 2 and 30)
    pixel_size = int(15 + 14 * math.sin(frame_count * 0.1))
    pixel_size = max(2, pixel_size)  # Ensure minimum size
    
    height, width = img.shape[:2]
    
    # Shrink image to create pixelation
    temp_height = max(1, height // pixel_size)
    temp_width = max(1, width // pixel_size)
    temp = cv2.resize(img, (temp_width, temp_height), interpolation=cv2.INTER_LINEAR)
    
    # Scale back up to create blocky effect
    result = cv2.resize(temp, (width, height), interpolation=cv2.INTER_NEAREST)
    
    return result

def rgb_channel_rotation(img, frame_count):
    """
    Rotate RGB channels over time, creating surreal color effects.
    The channels shift positions cyclically.
    """
    b, g, r = cv2.split(img)
    
    # Determine rotation state based on frame count
    rotation_cycle = (frame_count // 30) % 6  # Change every 30 frames
    
    # Different channel combinations
    rotations = [
        (b, g, r),  # Original BGR
        (r, b, g),  # Rotate right
        (g, r, b),  # Rotate right again
        (r, g, b),  # RGB (Red-Green-Blue)
        (g, b, r),  # GBR
        (b, r, g),  # BRG
    ]
    
    result = cv2.merge(rotations[rotation_cycle])
    return result

def glitch_effect(img, frame_count):
    """
    Create a glitch effect by displacing random horizontal slices.
    Simulates digital corruption or signal interference.
    """
    result = img.copy()
    height, width = img.shape[:2]
    
    # Create random glitches every 10 frames
    if frame_count % 10 == 0:
        num_glitches = np.random.randint(3, 8)
        
        for _ in range(num_glitches):
            # Random slice height and position
            slice_height = np.random.randint(5, 30)
            y_pos = np.random.randint(0, height - slice_height)
            
            # Random horizontal shift
            shift = np.random.randint(-50, 50)
            
            # Extract the slice
            slice_img = result[y_pos:y_pos+slice_height, :].copy()
            
            # Apply horizontal shift
            if shift > 0:
                # Shift right
                slice_img = np.roll(slice_img, shift, axis=1)
            elif shift < 0:
                # Shift left
                slice_img = np.roll(slice_img, shift, axis=1)
            
            # Optionally add color distortion
            if np.random.random() > 0.5:
                # Separate channels and shift them differently
                b, g, r = cv2.split(slice_img)
                r = np.roll(r, 5, axis=1)
                b = np.roll(b, -5, axis=1)
                slice_img = cv2.merge([b, g, r])
            
            # Place modified slice back
            result[y_pos:y_pos+slice_height, :] = slice_img
    
    return result

def create_animation_display(img, animation_func, animation_name, duration_seconds=10, fps=30):
    """
    Display an animation using the given animation function.
    
    Args:
        img: Source image
        animation_func: Function that takes (img, frame_count) and returns animated frame
        animation_name: Name to display in window
        duration_seconds: How long to run the animation
        fps: Target frames per second
    """
    print(f"\nDisplaying: {animation_name}")
    print("Press 'q' to quit, 's' to save a frame, or 1-6 to switch animations")
    
    window_name = f"Pixel Animation - {animation_name}"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    
    frame_delay = int(1000 / fps)  # Delay in milliseconds
    total_frames = duration_seconds * fps
    
    for frame in range(total_frames):
        # Generate animated frame
        result = animation_func(img, frame)
        
        # Add frame counter text
        text = f"Frame: {frame} | FPS: {fps}"
        cv2.putText(result, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (255, 255, 255), 2)
        
        # Display the frame
        cv2.imshow(window_name, result)
        
        # Handle keyboard input
        key = cv2.waitKey(frame_delay) & 0xFF
        
        if key == ord('q'):
            print("Quitting animation...")
            cv2.destroyWindow(window_name)
            return 'quit'
        elif key == ord('s'):
            filename = f"animation_{animation_name.replace(' ', '_')}_frame_{frame}.jpg"
            cv2.imwrite(filename, result)
            print(f"Saved frame: {filename}")
        elif key in [ord('1'), ord('2'), ord('3'), ord('4'), ord('5'), ord('6')]:
            cv2.destroyWindow(window_name)
            return key
    
    cv2.destroyWindow(window_name)
    return None

def main():
    """Main function to run pixel animation demonstrations."""
    
    # Load the image - adjust path as needed
    image_path = "../Resources/pinkflower.jpg"  # Change this to your image path
    img = load_image(image_path)
    
    if img is None:
        print("Please check the image path and try again.")
        return
    
    # Resize image for better performance if it's too large
    height, width = img.shape[:2]
    if width > 800:
        scale = 800 / width
        new_width = int(width * scale)
        new_height = int(height * scale)
        img = cv2.resize(img, (new_width, new_height))
        print(f"Resized image to {new_width}x{new_height} for performance")
    
    print("\n" + "="*60)
    print("PIXEL ANIMATION DEMONSTRATIONS")
    print("="*60)
    print("\nThis demo shows 6 different pixel animation techniques.")
    print("Each animation will run for 10 seconds.")
    print("\nControls:")
    print("  q - Quit")
    print("  s - Save current frame")
    print("  1 - Wave Effect")
    print("  2 - Color Cycling")
    print("  3 - Brightness Pulse")
    print("  4 - Pixelation Animation")
    print("  5 - RGB Channel Rotation")
    print("  6 - Glitch Effect")
    
    # Animation menu
    animations = [
        (wave_effect, "Wave Effect"),
        (color_cycle, "Color Cycling"),
        (brightness_pulse, "Brightness Pulse"),
        (pixelation_animation, "Pixelation Animation"),
        (rgb_channel_rotation, "RGB Channel Rotation"),
        (glitch_effect, "Glitch Effect")
    ]
    
    current_animation = 0
    
    while True:
        animation_func, animation_name = animations[current_animation]
        result = create_animation_display(img, animation_func, animation_name)
        
        if result == 'quit':
            break
        elif result in [ord('1'), ord('2'), ord('3'), ord('4'), ord('5'), ord('6')]:
            # Switch to requested animation
            current_animation = result - ord('1')
        else:
            # Move to next animation
            current_animation = (current_animation + 1) % len(animations)
    
    cv2.destroyAllWindows()
    print("\nAnimation demo complete!")

if __name__ == "__main__":
    main()
