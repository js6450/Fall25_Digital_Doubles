# Pixel Animation Examples

## Overview
This folder contains examples demonstrating how to create animations by varying pixel values over time. These examples show how frame count can be used as a time variable to create dynamic visual effects.

## Files

### `pixel_animation_template.py`
**Start here for creating your own animations!**

A blank template with:
- Comments explaining where to add your code
- Example animation already implemented
- Helpful animation ideas at the bottom
- Ready-to-run structure

**Perfect for:** Students who want to experiment and create their own pixel animations from scratch.

### `pixel_animation_simple.py`
**Recommended for beginners**

A simplified introduction to pixel animation with three basic techniques:
1. **Brightness Pulse** - Makes the entire image pulse brighter and darker using a sine wave
2. **Color Shift** - Animates each color channel independently to create color cycling effects
3. **Moving Gradient** - Creates an animated gradient that sweeps across the image

**Key Concepts:**
- Using frame count as time
- Mathematical functions (sine waves) for smooth animations
- Modifying pixel values based on position and time
- Clipping values to maintain valid pixel ranges

### `pixel_animation.py`
**Advanced demonstrations**

A comprehensive demonstration with six different animation techniques:
1. **Wave Effect** - Ripples that move across the image
2. **Color Cycling** - HSV hue rotation for rainbow effects
3. **Brightness Pulse** - Rhythmic brightness changes
4. **Pixelation Animation** - Dynamic mosaic effects with varying block sizes
5. **RGB Channel Rotation** - Shifts color channels to create surreal effects
6. **Glitch Effect** - Digital corruption simulation with slice displacement

**Features:**
- Interactive controls (switch between animations with number keys)
- Frame saving capability (press 's')
- Performance optimizations
- Multiple animation modes

## How to Run

### Simple Version (Recommended Start)
```bash
cd 12_pixel_animation
python pixel_animation_simple.py
```

### Advanced Version
```bash
python pixel_animation.py
```

## Controls

### Both Scripts:
- `q` - Quit the animation
- Window will automatically advance through animations

### Advanced Script Only:
- `s` - Save current frame as image
- `1-6` - Jump to specific animation:
  - `1` - Wave Effect
  - `2` - Color Cycling
  - `3` - Brightness Pulse
  - `4` - Pixelation Animation
  - `5` - RGB Channel Rotation
  - `6` - Glitch Effect

### Simple Script Only:
- `n` - Skip to next animation

## Learning Objectives

After working through these examples, you should understand:

1. **Time-based Animation**
   - How to use frame count as a time variable
   - Creating loops and cycles with mathematical functions

2. **Pixel Value Manipulation**
   - Modifying brightness across entire images
   - Working with individual color channels
   - Creating spatial patterns based on pixel coordinates

3. **Mathematical Functions**
   - Using sine and cosine for smooth oscillations
   - Controlling frequency, amplitude, and phase
   - Creating complex patterns from simple functions

4. **Performance Considerations**
   - When to use `.copy()` vs. in-place operations
   - Efficient array operations with NumPy
   - Balancing visual quality with frame rate

## Customization Ideas

Try modifying the code to:
1. Change animation speed (modify the multiplier on frame count)
2. Adjust wave frequencies and amplitudes
3. Create your own animation function combining multiple effects
4. Add more complex mathematical patterns
5. Animate only specific regions of the image
6. Create animations that respond to image content (e.g., brighter in bright areas)

## Technical Notes

### Frame Rate
- Both scripts target 30 FPS
- Actual performance depends on image size and computer speed
- Consider resizing large images for smoother playback

### Mathematical Functions
The examples use several mathematical concepts:
- **Sine waves**: `math.sin()` creates smooth oscillations between -1 and 1
- **Phase shifts**: Adding constants to the input shifts the wave in time
- **Frequency**: Multiplying the input changes how fast the wave oscillates
- **Amplitude**: Multiplying the output changes the strength of the effect

### Color Spaces
- Most operations work in BGR (OpenCV's default)
- Color cycling uses HSV for intuitive hue manipulation
- Converting between color spaces: `cv2.cvtColor()`

## Common Issues and Solutions

**Animation runs too fast/slow:**
- Adjust the frame delay in `cv2.waitKey()`
- Modify the multiplier on frame count (e.g., `frame * 0.1` to `frame * 0.05`)

**Image looks distorted:**
- Check that values are clipped to 0-255
- Ensure you're converting back to `uint8` data type

**Performance issues:**
- Resize the input image to smaller dimensions
- Simplify complex calculations
- Use NumPy vectorized operations instead of loops

## Related Concepts

These examples build on concepts from earlier Week 1 examples:
- `08_pixel_manipulation` - Direct pixel access and modification
- `06_brightness_contrast` - Brightness adjustments
- `03_color_space_conversions` - Working with different color spaces

## Next Steps

After mastering these examples, explore:
- Combining multiple animation techniques
- Creating animations that respond to mouse/keyboard input
- Saving animations as video files (Week 2 material)
- Adding audio reactivity
- Creating interactive installations with real-time effects
