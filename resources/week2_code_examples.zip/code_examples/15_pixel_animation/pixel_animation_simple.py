"""
Simple Pixel Animation Example
Week 1 - Digital Doubles

This simplified script demonstrates the basics of pixel animation.
Great for beginners to understand how time can be used to animate pixels.

Key Concepts:
- Using frame count as a time variable
- Modifying pixel values based on time
- Creating smooth animations with mathematical functions
"""

import cv2
import numpy as np
import math

def animate_brightness(img, frame):
    """
    Simple brightness animation using sine wave.
    
    Args:
        img: Input image
        frame: Current frame number (represents time)
    
    Returns:
        Animated frame
    """
    # Make a copy to avoid modifying original
    result = img.copy().astype(float)
    
    # Use sine wave to create oscillating value between 0.5 and 1.5
    # This makes the image pulse between darker and brighter
    brightness = 1.0 + 0.5 * math.sin(frame * 0.1)
    
    # Apply brightness to all pixels
    result = result * brightness
    
    # Make sure values stay in valid range (0-255)
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def animate_color_shift(img, frame):
    """
    Shift colors by modifying individual color channels.
    
    Args:
        img: Input image
        frame: Current frame number
    
    Returns:
        Color-shifted frame
    """
    result = img.copy().astype(float)
    
    # Create oscillating values for each channel
    # Blue channel oscillates between 0.7 and 1.3
    blue_factor = 1.0 + 0.3 * math.sin(frame * 0.1)
    # Green channel oscillates at different rate
    green_factor = 1.0 + 0.3 * math.sin(frame * 0.1 + math.pi / 3)
    # Red channel oscillates at yet another rate
    red_factor = 1.0 + 0.3 * math.sin(frame * 0.1 + 2 * math.pi / 3)
    
    # Apply different factors to each color channel
    result[:, :, 0] *= blue_factor   # Blue channel
    result[:, :, 1] *= green_factor  # Green channel
    result[:, :, 2] *= red_factor    # Red channel
    
    # Keep values in valid range
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def animate_gradient(img, frame):
    """
    Create an animated gradient that moves across the image.
    
    Args:
        img: Input image
        frame: Current frame number
    
    Returns:
        Frame with animated gradient overlay
    """
    result = img.copy().astype(float)
    height, width = result.shape[:2]
    
    # Create a gradient that moves horizontally
    # X coordinates from 0 to width
    x = np.arange(width)
    # Repeat for each row
    x_grid = np.tile(x, (height, 1))
    
    # Create oscillating gradient
    # The gradient moves across the screen over time
    gradient = 0.5 + 0.5 * np.sin((x_grid / width * 4 * math.pi) + (frame * 0.1))
    
    # Apply gradient as brightness modifier
    # Expand gradient to 3 channels
    gradient_3d = np.repeat(gradient[:, :, np.newaxis], 3, axis=2)
    
    result = result * (0.5 + 0.5 * gradient_3d)
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def main():
    """Run simple pixel animation examples."""
    
    # Load an image
    image_path = "../Resources/pinkflower.jpg"
    img = cv2.imread(image_path)
    
    if img is None:
        print(f"Error: Could not load image at {image_path}")
        print("Please check the path and try again.")
        return
    
    # Resize if image is too large
    height, width = img.shape[:2]
    if width > 600:
        scale = 600 / width
        img = cv2.resize(img, (int(width * scale), int(height * scale)))
    
    print("\nSimple Pixel Animation Examples")
    print("=" * 40)
    print("\nShowing three animation types:")
    print("1. Brightness animation (pulsing)")
    print("2. Color shift animation")
    print("3. Moving gradient animation")
    print("\nPress 'q' to quit")
    print("Press 'n' to skip to next animation")
    print("=" * 40)
    
    # Define animation functions
    animations = [
        (animate_brightness, "Brightness Pulse"),
        (animate_color_shift, "Color Shift"),
        (animate_gradient, "Moving Gradient")
    ]
    
    for animation_func, animation_name in animations:
        print(f"\nNow showing: {animation_name}")
        
        window_name = f"Simple Animation - {animation_name}"
        cv2.namedWindow(window_name)
        
        # Run animation for 5 seconds at 30 fps
        for frame in range(150):  # 150 frames = 5 seconds at 30 fps
            
            # Generate animated frame
            animated_frame = animation_func(img, frame)
            
            # Add text showing frame number
            cv2.putText(animated_frame, f"{animation_name} - Frame: {frame}", 
                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.7, (255, 255, 255), 2)
            
            # Show the frame
            cv2.imshow(window_name, animated_frame)
            
            # Wait and check for key press (33ms = ~30fps)
            key = cv2.waitKey(33) & 0xFF
            
            if key == ord('q'):
                print("Quitting...")
                cv2.destroyAllWindows()
                return
            elif key == ord('n'):
                print("Skipping to next animation...")
                break
        
        cv2.destroyWindow(window_name)
    
    cv2.destroyAllWindows()
    print("\nAll animations complete!")
    print("\nKey Takeaway:")
    print("By using the frame count as a time variable and applying")
    print("mathematical functions (like sine), we can create smooth,")
    print("repeating animations that modify pixel values over time.")

if __name__ == "__main__":
    main()
