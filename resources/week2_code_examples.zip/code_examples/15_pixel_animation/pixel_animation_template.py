"""
Pixel Animation Template
Week 1 - Digital Doubles

Use this template to create your own pixel animation!
Fill in the animate_custom() function with your own pixel manipulation code.

Tips:
- Use the 'frame' parameter to vary effects over time
- Use math.sin() and math.cos() for smooth, repeating animations
- Keep pixel values between 0-255
- Experiment with different mathematical functions!
"""

import cv2
import numpy as np
import math

def animate_custom(img, frame):
    """
    YOUR CUSTOM ANIMATION GOES HERE!
    
    Args:
        img: The input image (NumPy array with shape [height, width, 3])
        frame: The current frame number (increases by 1 each frame)
               Use this as your "time" variable
    
    Returns:
        result: Your animated image (must be same size as input)
    
    Example ideas:
    - Make brightness pulse using math.sin(frame * 0.1)
    - Make colors rotate using frame % 180
    - Create patterns using pixel coordinates
    - Combine multiple effects!
    """
    # Start by making a copy of the image
    result = img.copy().astype(float)
    
    # TODO: Add your animation code here!
    # For example, here's a simple brightness pulse:
    
    # Calculate a pulsing brightness value
    brightness_factor = 1.0 + 0.3 * math.sin(frame * 0.1)
    
    # Apply to all pixels
    result = result * brightness_factor
    
    # IMPORTANT: Always clip and convert back to uint8
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result

def main():
    """Main function - no need to modify this!"""
    
    # Load an image
    image_path = "../Resources/pinkflower.jpg"  # Change if needed
    img = cv2.imread(image_path)
    
    if img is None:
        print(f"Error: Could not load image at {image_path}")
        return
    
    # Resize if needed for performance
    height, width = img.shape[:2]
    if width > 600:
        scale = 600 / width
        img = cv2.resize(img, (int(width * scale), int(height * scale)))
    
    print("\nYour Custom Pixel Animation")
    print("=" * 40)
    print("Press 'q' to quit")
    print("Press 's' to save current frame")
    print("=" * 40)
    
    cv2.namedWindow("Custom Animation")
    frame = 0
    
    while True:
        # Generate animated frame
        animated_frame = animate_custom(img, frame)
        
        # Add frame counter
        cv2.putText(animated_frame, f"Frame: {frame}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (255, 255, 255), 2)
        
        # Display
        cv2.imshow("Custom Animation", animated_frame)
        
        # Handle keyboard input (33ms delay = ~30 FPS)
        key = cv2.waitKey(33) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('s'):
            filename = f"custom_animation_frame_{frame}.jpg"
            cv2.imwrite(filename, animated_frame)
            print(f"Saved: {filename}")
        
        frame += 1
    
    cv2.destroyAllWindows()
    print("\nAnimation complete!")

if __name__ == "__main__":
    main()


# ========================================
# ANIMATION IDEAS TO TRY
# ========================================

"""
1. WAVE EFFECT ACROSS IMAGE:
   Create ripples using sine waves based on x and y coordinates

   x = np.arange(width)
   y = np.arange(height)
   X, Y = np.meshgrid(x, y)
   wave = 30 * np.sin(0.05 * X + 0.05 * Y + 0.1 * frame)
   result[:, :, channel] += wave

2. ZOOMING PIXELATION:
   Make pixel blocks grow and shrink over time
   
   pixel_size = int(5 + 5 * math.sin(frame * 0.1))
   temp = cv2.resize(img, (width//pixel_size, height//pixel_size))
   result = cv2.resize(temp, (width, height), interpolation=cv2.INTER_NEAREST)

3. COLOR CHANNEL SHIFT:
   Move different color channels in different directions
   
   b, g, r = cv2.split(result)
   shift = int(10 * math.sin(frame * 0.1))
   r = np.roll(r, shift, axis=1)
   b = np.roll(b, -shift, axis=1)
   result = cv2.merge([b, g, r])

4. SPIRAL GRADIENT:
   Create rotating gradients using atan2
   
   center_x, center_y = width // 2, height // 2
   x = np.arange(width) - center_x
   y = np.arange(height) - center_y
   X, Y = np.meshgrid(x, y)
   angle = np.arctan2(Y, X)
   gradient = np.sin(angle * 3 + frame * 0.1)

5. EDGE GLOW:
   Make edges pulse by detecting them first
   
   gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
   edges = cv2.Canny(gray, 100, 200)
   glow = edges * (0.5 + 0.5 * math.sin(frame * 0.1))
   # Add glow back to original image

6. KALEIDOSCOPE:
   Create symmetrical patterns by mirroring regions
   
   # Copy and flip sections to create symmetry
   quarter = img[:height//2, :width//2]
   # Mirror this across axes

7. SCANLINE EFFECT:
   Create moving horizontal lines like old TVs
   
   scanline = int(frame % height)
   result[scanline, :] = [255, 255, 255]  # White line

8. DISPLACEMENT MAP:
   Shift pixels based on sine waves
   
   shift_x = 20 * np.sin(frame * 0.1 + Y * 0.1)
   shift_y = 20 * np.cos(frame * 0.1 + X * 0.1)
   # Use cv2.remap to apply shifts
"""
