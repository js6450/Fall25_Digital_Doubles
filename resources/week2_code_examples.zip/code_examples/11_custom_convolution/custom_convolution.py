"""
Week 2 - Example 01: Custom Convolution with filter2D
Digital Doubles - DM-GY 9201 B

This example demonstrates how to apply custom convolution kernels to images
using OpenCV's filter2D function. You'll see how different kernels create
different effects on images.

Topics covered:
- Creating custom kernels (NumPy arrays)
- Normalizing kernels
- Using cv2.filter2D() for convolution
- Understanding how kernel values affect the output

Press any key to advance through the examples.
Press 'q' to quit at any time.
"""

import cv2
import numpy as np
import os

def main():
    # Get the path to the Resources folder
    # Assumes this script is in Week2/code_examples/01_custom_convolution/
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resources_path = os.path.join(script_dir, '..', 'Resources')
    
    # Load an image
    img_path = os.path.join(resources_path, 'mountain.jpg')
    img = cv2.imread(img_path)
    
    if img is None:
        print(f"Error: Could not load image from {img_path}")
        print("Make sure the Resources folder contains mountain.jpg")
        return
    
    # Convert to grayscale for clearer demonstration
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    print("Custom Convolution Examples")
    print("=" * 50)
    print("\nPress any key to see each kernel effect")
    print("Press 'q' to quit\n")
    
    # Show original
    cv2.imshow('Original Image', gray)
    cv2.waitKey(0)
    
    # ========================================
    # 1. Identity Kernel - No Change
    # ========================================
    print("1. Identity Kernel (no change)")
    print("   [[0, 0, 0],")
    print("    [0, 1, 0],")
    print("    [0, 0, 0]]")
    
    identity = np.array([[0, 0, 0],
                        [0, 1, 0],
                        [0, 0, 0]], dtype=np.float32)
    
    result_identity = cv2.filter2D(gray, -1, identity)
    
    cv2.imshow('Identity Kernel (No Change)', result_identity)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 2. Box Blur - Simple Average
    # ========================================
    print("\n2. Box Blur Kernel (simple average)")
    print("   [[1, 1, 1],")
    print("    [1, 1, 1],")
    print("    [1, 1, 1]] / 9")
    
    box_blur = np.ones((3, 3), dtype=np.float32) / 9
    result_box = cv2.filter2D(gray, -1, box_blur)
    
    cv2.imshow('Box Blur (3x3)', result_box)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 3. Gaussian-like Blur
    # ========================================
    print("\n3. Gaussian-like Blur (weighted average)")
    print("   [[1,  2,  1],")
    print("    [2,  4,  2],")
    print("    [1,  2,  1]] / 16")
    
    gaussian_like = np.array([[1, 2, 1],
                             [2, 4, 2],
                             [1, 2, 1]], dtype=np.float32) / 16
    
    result_gaussian = cv2.filter2D(gray, -1, gaussian_like)
    
    cv2.imshow('Gaussian-like Blur', result_gaussian)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 4. Sharpen Kernel
    # ========================================
    print("\n4. Sharpen Kernel (emphasize edges)")
    print("   [[ 0, -1,  0],")
    print("    [-1,  5, -1],")
    print("    [ 0, -1,  0]]")
    
    sharpen = np.array([[0, -1, 0],
                       [-1, 5, -1],
                       [0, -1, 0]], dtype=np.float32)
    
    result_sharpen = cv2.filter2D(gray, -1, sharpen)
    
    cv2.imshow('Sharpened', result_sharpen)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 5. Edge Detection Kernel
    # ========================================
    print("\n5. Edge Detection Kernel")
    print("   [[-1, -1, -1],")
    print("    [-1,  8, -1],")
    print("    [-1, -1, -1]]")
    
    edge_detect = np.array([[-1, -1, -1],
                           [-1,  8, -1],
                           [-1, -1, -1]], dtype=np.float32)
    
    result_edge = cv2.filter2D(gray, -1, edge_detect)
    
    cv2.imshow('Edge Detection', result_edge)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 6. Emboss Kernel
    # ========================================
    print("\n6. Emboss Kernel (3D effect)")
    print("   [[-2, -1,  0],")
    print("    [-1,  1,  1],")
    print("    [ 0,  1,  2]]")
    
    emboss = np.array([[-2, -1, 0],
                      [-1,  1, 1],
                      [0,  1, 2]], dtype=np.float32)
    
    result_emboss = cv2.filter2D(gray, -1, emboss)
    # Add 128 to shift the range to visible (emboss produces negative values)
    result_emboss = cv2.add(result_emboss, 128)
    
    cv2.imshow('Emboss Effect', result_emboss)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 7. Horizontal Edge Detection (Sobel-like)
    # ========================================
    print("\n7. Horizontal Edge Detection")
    print("   [[-1, -2, -1],")
    print("    [ 0,  0,  0],")
    print("    [ 1,  2,  1]]")
    
    horizontal_edge = np.array([[-1, -2, -1],
                               [0,  0,  0],
                               [1,  2,  1]], dtype=np.float32)
    
    result_h_edge = cv2.filter2D(gray, -1, horizontal_edge)
    # Take absolute value to see all edges
    result_h_edge = cv2.convertScaleAbs(result_h_edge)
    
    cv2.imshow('Horizontal Edges', result_h_edge)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 8. Vertical Edge Detection (Sobel-like)
    # ========================================
    print("\n8. Vertical Edge Detection")
    print("   [[-1,  0,  1],")
    print("    [-2,  0,  2],")
    print("    [-1,  0,  1]]")
    
    vertical_edge = np.array([[-1, 0, 1],
                             [-2, 0, 2],
                             [-1, 0, 1]], dtype=np.float32)
    
    result_v_edge = cv2.filter2D(gray, -1, vertical_edge)
    result_v_edge = cv2.convertScaleAbs(result_v_edge)
    
    cv2.imshow('Vertical Edges', result_v_edge)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 9. Motion Blur (Horizontal)
    # ========================================
    print("\n9. Motion Blur (Horizontal)")
    print("   Creating a 9x9 horizontal motion blur kernel")
    
    size = 9
    motion_blur = np.zeros((size, size))
    motion_blur[int((size-1)/2), :] = np.ones(size)
    motion_blur = motion_blur / size
    
    result_motion = cv2.filter2D(gray, -1, motion_blur)
    
    cv2.imshow('Motion Blur (Horizontal)', result_motion)
    key = cv2.waitKey(0)
    if key == ord('q'):
        cv2.destroyAllWindows()
        return
    
    # ========================================
    # 10. Comparison Grid
    # ========================================
    print("\n10. Creating comparison grid of all effects...")
    
    # Resize all images to same size for comparison
    h, w = gray.shape
    new_h, new_w = h // 2, w // 2
    
    # Resize all results
    imgs_to_compare = [
        ('Original', gray),
        ('Identity', result_identity),
        ('Box Blur', result_box),
        ('Gaussian', result_gaussian),
        ('Sharpen', result_sharpen),
        ('Edge Detect', result_edge),
        ('Emboss', result_emboss),
        ('H-Edges', result_h_edge),
        ('V-Edges', result_v_edge),
        ('Motion Blur', result_motion)
    ]
    
    # Create a grid: 2 rows x 5 columns
    row1 = []
    row2 = []
    
    for i, (name, img) in enumerate(imgs_to_compare):
        # Resize
        small = cv2.resize(img, (new_w, new_h))
        
        # Add text label
        labeled = small.copy()
        cv2.putText(labeled, name, (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        if i < 5:
            row1.append(labeled)
        else:
            row2.append(labeled)
    
    # Concatenate images
    top_row = np.hstack(row1)
    bottom_row = np.hstack(row2)
    comparison_grid = np.vstack([top_row, bottom_row])
    
    cv2.imshow('Comparison: All Kernel Effects', comparison_grid)
    print("\nComparison grid displayed!")
    print("Notice how different kernels create different effects")
    print("\nPress any key to exit...")
    cv2.waitKey(0)
    
    # Clean up
    cv2.destroyAllWindows()
    
    print("\n" + "=" * 50)
    print("Key Takeaways:")
    print("- Kernels are small matrices that define convolution operations")
    print("- Positive values brighten, negative values darken")
    print("- Center value determines emphasis on current pixel")
    print("- Normalization (dividing by sum) maintains brightness")
    print("- Different kernel patterns create different effects")
    print("- You can design custom kernels for specific effects!")
    print("=" * 50)

if __name__ == "__main__":
    main()
