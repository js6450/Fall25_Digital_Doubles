"""
Basic Filters
Digital Doubles - Week 1

This script demonstrates various blurring and smoothing filters:
- Gaussian Blur (most common)
- Median Blur (removes salt-and-pepper noise)
- Bilateral Filter (preserves edges)
- Average Blur (simple box filter)

Blurring is used to reduce noise and detail in images.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Basic Filters Demo")
    print("=" * 60)
    print()
    
    # Load image
    print("Loading image...")
    img = cv2.imread('../Resources/whiteflower.jpg')
    
    if img is None:
        print("Error: Could not load image")
        return
    
    height, width = img.shape[:2]
    print(f"✓ Image loaded: {width}x{height} pixels")
    print()
    
    # Display original
    cv2.imshow('Original Image', img)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== GAUSSIAN BLUR ==========
    print("1. GAUSSIAN BLUR")
    print("=" * 60)
    print("Gaussian blur is the most commonly used blur filter.")
    print("It creates a smooth, natural-looking blur.")
    print()
    
    # Small blur
    print("a) Small blur (kernel size 5x5)")
    gaussian_small = cv2.GaussianBlur(img, (5, 5), 0)
    print("   Subtle smoothing effect")
    cv2.imshow('1a. Gaussian Blur 5x5', gaussian_small)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Medium blur
    print("b) Medium blur (kernel size 15x15)")
    gaussian_medium = cv2.GaussianBlur(img, (15, 15), 0)
    print("   More noticeable blur")
    cv2.imshow('1b. Gaussian Blur 15x15', gaussian_medium)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Large blur
    print("c) Strong blur (kernel size 35x35)")
    gaussian_large = cv2.GaussianBlur(img, (35, 35), 0)
    print("   Heavy blur, painterly effect")
    cv2.imshow('1c. Gaussian Blur 35x35', gaussian_large)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    print("Note: Kernel size must be odd numbers (3, 5, 7, 9, ...)")
    print("      Larger kernel = more blur")
    print()
    cv2.destroyAllWindows()
    
    # ========== MEDIAN BLUR ==========
    print("2. MEDIAN BLUR")
    print("=" * 60)
    print("Median blur is excellent for removing 'salt and pepper' noise")
    print("(random black and white pixels).")
    print()
    
    # Add some noise to demonstrate
    print("Adding salt and pepper noise to the image...")
    noisy_img = img.copy()
    
    # Add salt (white pixels)
    num_salt = int(0.02 * img.size)
    coords = [np.random.randint(0, i, num_salt) for i in img.shape[:2]]
    noisy_img[coords[0], coords[1]] = 255
    
    # Add pepper (black pixels)
    num_pepper = int(0.02 * img.size)
    coords = [np.random.randint(0, i, num_pepper) for i in img.shape[:2]]
    noisy_img[coords[0], coords[1]] = 0
    
    cv2.imshow('2a. Noisy Image (salt & pepper)', noisy_img)
    print("Notice the random black and white dots")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Apply median blur to remove noise
    print("Applying median blur to remove noise...")
    median_filtered = cv2.medianBlur(noisy_img, 5)
    cv2.imshow('2b. After Median Blur (5)', median_filtered)
    print("Noise is greatly reduced!")
    print("Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    # Compare with Gaussian on noisy image
    print("Comparison: Gaussian blur on same noisy image")
    gaussian_on_noisy = cv2.GaussianBlur(noisy_img, (5, 5), 0)
    cv2.imshow('2c. Gaussian Blur on noisy image', gaussian_on_noisy)
    print("Gaussian doesn't remove noise as effectively")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== BILATERAL FILTER ==========
    print("3. BILATERAL FILTER")
    print("=" * 60)
    print("Bilateral filter smooths while preserving edges.")
    print("Great for artistic effects or noise reduction with edge preservation.")
    print()
    
    # Apply bilateral filter
    print("Applying bilateral filter...")
    bilateral = cv2.bilateralFilter(img, 9, 75, 75)
    
    # Show comparison
    cv2.imshow('3a. Original', img)
    cv2.imshow('3b. Bilateral Filter', bilateral)
    cv2.imshow('3c. Gaussian Blur (same strength)', cv2.GaussianBlur(img, (9, 9), 0))
    
    print("Compare the edges:")
    print("  - Bilateral: Edges remain sharp")
    print("  - Gaussian: Everything is blurred uniformly")
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== AVERAGE BLUR ==========
    print("4. AVERAGE (BOX) BLUR")
    print("=" * 60)
    print("Average blur (also called box blur) is the simplest blur.")
    print("It replaces each pixel with the average of surrounding pixels.")
    print()
    
    average_blur = cv2.blur(img, (15, 15))
    
    cv2.imshow('4a. Original', img)
    cv2.imshow('4b. Average Blur 15x15', average_blur)
    cv2.imshow('4c. Gaussian Blur 15x15', cv2.GaussianBlur(img, (15, 15), 0))
    
    print("Average blur vs Gaussian blur:")
    print("  - Average: Simpler, faster, but can create artifacts")
    print("  - Gaussian: Smoother, more natural-looking")
    print()
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== COMPARISON ==========
    print("5. SIDE-BY-SIDE COMPARISON")
    print("=" * 60)
    print("Let's compare all blur types together")
    print()
    
    # Create comparison with different blurs
    gaussian_comp = cv2.GaussianBlur(img, (15, 15), 0)
    median_comp = cv2.medianBlur(img, 15)
    bilateral_comp = cv2.bilateralFilter(img, 15, 80, 80)
    average_comp = cv2.blur(img, (15, 15))
    
    cv2.imshow('5a. Original', img)
    cv2.imshow('5b. Gaussian', gaussian_comp)
    cv2.imshow('5c. Median', median_comp)
    cv2.imshow('5d. Bilateral', bilateral_comp)
    cv2.imshow('5e. Average', average_comp)
    
    print("Look at the differences in smoothness and edge preservation")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== SAVING ==========
    print("6. SAVING FILTERED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_gaussian_blur.jpg', gaussian_medium)
    cv2.imwrite('output_median_blur.jpg', median_filtered)
    cv2.imwrite('output_bilateral_filter.jpg', bilateral)
    cv2.imwrite('output_average_blur.jpg', average_blur)
    
    print("✓ Saved 4 filtered images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Gaussian blur: General purpose, natural-looking")
    print("  - Median blur: Best for salt & pepper noise")
    print("  - Bilateral filter: Smooths while preserving edges")
    print("  - Average blur: Simple and fast, but less sophisticated")
    print()
    print("When to use which:")
    print("  - General smoothing → Gaussian")
    print("  - Noise reduction → Median")
    print("  - Artistic effects → Bilateral")
    print("  - Quick and simple → Average")
    print("=" * 60)

if __name__ == "__main__":
    main()
