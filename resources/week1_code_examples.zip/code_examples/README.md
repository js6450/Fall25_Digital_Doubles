# Week 1: Introduction & Image Processing Fundamentals

**Digital Doubles - DM-GY 9201 B**  
**Instructor:** Jiwon Shin

---

## Overview

This folder contains all materials for Week 1, including lecture notes, code examples, and setup guides. This week focuses on fundamental image processing techniques using Python and OpenCV.

---

## Contents

### 📄 Documentation
- **Week1_Lecture_Notes.md** - Complete lecture notes with embedded links for students to review after class
- **Week1_Slides_Content.md** - Detailed content for creating presentation slides
- **Installation_Setup_Guide.md** - Step-by-step installation instructions and troubleshooting

### 🖼️ Resources
- **Resources/** - Sample images for use in code examples
  - mountain.jpg
  - ocean.jpg
  - pinkflower.jpg
  - whiteflower.jpg

### 💻 Code Examples

All code examples are organized in separate folders with descriptive names:

#### 01. Setup Verification
**Folder:** `01_setup_verification/`  
**File:** `setup_verification.py`

Checks if all required packages (OpenCV, NumPy, Matplotlib) are installed correctly and displays version numbers.

**Run:** `python setup_verification.py`

---

#### 02. Image Loading Basics
**Folder:** `02_image_loading_basics/`  
**File:** `image_loading_basics.py`

Demonstrates fundamental operations:
- Loading images from files
- Displaying images in windows
- Getting image properties (dimensions, channels, data type)
- Saving images
- Error handling

**Run:** `python image_loading_basics.py`

---

#### 03. Color Space Conversions
**Folder:** `03_color_space_conversions/`  
**File:** `color_space_conversions.py`

Explores different color spaces:
- BGR (OpenCV default)
- RGB (standard)
- Grayscale
- HSV (Hue, Saturation, Value)
- Channel splitting and merging

**Run:** `python color_space_conversions.py`

---

#### 04. Image Transformations
**Folder:** `04_image_transformations/`  
**File:** `image_transformations.py`

Covers geometric transformations:
- Resizing (specific size, percentage, maintaining aspect ratio)
- Cropping (simple and center crop)
- Rotating (90°, 180°, 270°, arbitrary angles)
- Flipping (horizontal, vertical, both)
- Different interpolation methods

**Run:** `python image_transformations.py`

---

#### 05. Basic Filters
**Folder:** `05_basic_filters/`  
**File:** `basic_filters.py`

Demonstrates various blurring and smoothing filters:
- Gaussian Blur (most common)
- Median Blur (removes salt-and-pepper noise)
- Bilateral Filter (preserves edges)
- Average Blur (simple box filter)
- Comparison of all methods

**Run:** `python basic_filters.py`

---

#### 06. Brightness and Contrast
**Folder:** `06_brightness_contrast/`  
**File:** `brightness_contrast.py`

Shows how to adjust image intensity:
- Brightness adjustment (adding/subtracting values)
- Contrast adjustment (multiplying values)
- Combined adjustments
- Formula: output = alpha * input + beta

**Run:** `python brightness_contrast.py`

---

#### 07. Thresholding Demo
**Folder:** `07_thresholding_demo/`  
**File:** `thresholding_demo.py`

Explores converting grayscale to binary:
- Simple binary threshold
- Inverse binary threshold
- Adaptive threshold (for varying lighting)
- Otsu's method (automatic threshold selection)
- Comparison and use cases

**Run:** `python thresholding_demo.py`

---

#### 08. Pixel Manipulation
**Folder:** `08_pixel_manipulation/`  
**File:** `pixel_manipulation.py`

Direct pixel-level operations:
- Accessing individual pixel values
- Modifying single pixels and regions
- Creating colored regions
- Splitting and merging color channels
- Channel swapping for creative effects

**Run:** `python pixel_manipulation.py`

---

#### 09. Image Compositing
**Folder:** `09_image_compositing/`  
**File:** `image_compositing.py`

Layering and combining images:
- Placing smaller images on larger backgrounds
- Positioning images at specific locations
- Alpha blending for transparency
- Creating collages
- Watermarks and picture-in-picture effects

**Run:** `python image_compositing.py`

---

#### 10. Complete Image Processor
**Folder:** `10_complete_image_processor/`  
**File:** `complete_image_processor.py`

**⭐ Comprehensive Example**

Combines all Week 1 techniques into a single, well-organized program:
- Loads and validates images
- Applies multiple transformations
- Uses various filters and effects
- Saves all results
- Demonstrates proper code organization and error handling

This serves as a template for students to build their own image processors.

**Run:** `python complete_image_processor.py`

---

#### 11. Interactive Demo (BONUS)
**Folder:** `11_interactive_demo/`  
**File:** `interactive_demo.py`

**🎁 Optional Bonus Example**

Real-time image processing with interactive controls:
- Trackbar sliders for adjusting parameters
- Brightness and contrast adjustment
- Blur strength control
- Threshold value control
- Real-time preview

Great for experimenting and understanding parameter effects!

**Run:** `python interactive_demo.py`

---

## Running the Examples

### Prerequisites
Make sure you have completed the setup:
1. Python 3.8+ installed
2. Required packages installed: `pip install opencv-python numpy matplotlib`
3. Run `01_setup_verification/setup_verification.py` to verify

### How to Run

Navigate to the Week1 folder and run examples from their directories:

```bash
cd Week1/01_setup_verification
python setup_verification.py
```

Or run from the Week1 folder using relative paths:

```bash
cd Week1
python 01_setup_verification/setup_verification.py
```

### Interactive Examples

Most examples use `cv2.waitKey(0)` - press any key while the image window is active to continue to the next step.

To exit: Press 'q' (for examples that support it) or close the window.

---

## Learning Path

**Recommended order for students:**

1. **Start here:** `01_setup_verification` - Make sure everything is installed
2. **Basics:** `02_image_loading_basics` - Learn fundamental operations
3. **Color:** `03_color_space_conversions` - Understand color representations
4. **Transform:** `04_image_transformations` - Geometric manipulations
5. **Filter:** `05_basic_filters` - Smoothing and noise reduction
6. **Adjust:** `06_brightness_contrast` - Intensity modifications
7. **Binary:** `07_thresholding_demo` - Converting to black and white
8. **Pixels:** `08_pixel_manipulation` - Direct pixel access
9. **Compose:** `09_image_compositing` - Layering images
10. **Complete:** `10_complete_image_processor` - See it all together
11. **Bonus:** `11_interactive_demo` - Experiment interactively

---

## Key Concepts Covered

### Week 1 Learning Objectives

By the end of Week 1, students should be able to:

✓ Load, display, and save images using OpenCV  
✓ Understand images as NumPy arrays  
✓ Convert between color spaces (BGR, RGB, Grayscale, HSV)  
✓ Resize, crop, rotate, and flip images  
✓ Apply various filters (Gaussian, Median, Bilateral)  
✓ Adjust brightness and contrast  
✓ Apply thresholding techniques  
✓ Manipulate pixels directly  
✓ Composite and layer images  
✓ Build a complete image processing program

---

## Common Issues & Tips

### Issue: "Could not load image"
- Check that the path is correct
- Verify the image file exists in the Resources folder
- Use relative paths from where you're running the script

### Issue: Image colors look wrong
- OpenCV uses BGR, not RGB!
- Convert with `cv2.cvtColor(img, cv2.COLOR_BGR2RGB)` if needed

### Issue: cv2.imshow() doesn't work
- Make sure to call `cv2.waitKey(0)` after imshow
- On Mac, you might need XQuartz installed
- Try using matplotlib as an alternative

### Issue: "Kernel size must be odd"
- For filters like Gaussian blur, use odd numbers: 3, 5, 7, 9, etc.

### Tip: Understanding coordinates
- Image indexing is `[y, x]` not `[x, y]`
- `img[row, column]` or `img[y, x]`

---

## Week 1 Assignments

### Reading Assignment
**Article:** "Art in a Time of Surveillance" - The Intercept  
**Due:** Next class (October 31, 2025)

### Lab Assignment 1
**Create a Python program demonstrating basic image processing techniques**  
**Requirements:** Apply at least 3 different transformations/filters  
**Due:** Next class (October 31, 2025)

See **Week1_Lecture_Notes.md** for complete assignment details.

---

## Additional Resources

### Documentation
- [OpenCV Documentation](https://docs.opencv.org/)
- [OpenCV Python Tutorials](https://docs.opencv.org/master/d6/d00/tutorial_py_root.html)
- [NumPy Documentation](https://numpy.org/doc/)

### Helpful Links
- [Real Python OpenCV Tutorial](https://realpython.com/opencv-python/)
- [LearnOpenCV](https://learnopencv.com/)
- [PyImageSearch](https://www.pyimagesearch.com/)

---

## Need Help?

- **Office Hours:** By appointment - email jiwon.shin@nyu.edu
- **Technical Issues:** IT Service Desk (nyu.edu/it/servicedesk)
- **Installation Problems:** See Installation_Setup_Guide.md

---

## Next Week Preview

**Week 2:** Advanced Image Processing & Video Fundamentals
- Convolution and kernels
- Custom filters
- Video processing basics
- Motion detection
- Frame differencing

---

**Last Updated:** October 2025
