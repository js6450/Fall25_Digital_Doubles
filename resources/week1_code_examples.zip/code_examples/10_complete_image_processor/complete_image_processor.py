"""
Complete Image Processor
Digital Doubles - Week 1

This is a comprehensive example that combines multiple image processing techniques
into a single program. It demonstrates:
- Loading and validation
- Multiple transformations
- Filters and effects
- Proper organization and error handling
- Saving results

This serves as a template for building your own image processing programs.

Press any key to move through the processing steps.
"""

import cv2
import numpy as np
import os

def load_image(image_path):
    """
    Load an image with error handling.
    
    Args:
        image_path: Path to the image file
        
    Returns:
        Loaded image or None if failed
    """
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Could not load image from '{image_path}'")
        return None
    return img

def save_image(image, filename, output_dir='output'):
    """
    Save an image to the output directory.
    
    Args:
        image: Image to save
        filename: Name of the output file
        output_dir: Directory to save to (created if doesn't exist)
    """
    # Create output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    output_path = os.path.join(output_dir, filename)
    success = cv2.imwrite(output_path, image)
    
    if success:
        print(f"  ✓ Saved: {output_path}")
    else:
        print(f"  ✗ Failed to save: {output_path}")

def process_image(image_path, show_steps=True):
    """
    Complete image processing pipeline.
    
    Args:
        image_path: Path to input image
        show_steps: Whether to display each processing step
    """
    print("=" * 60)
    print("Complete Image Processor")
    print("=" * 60)
    print()
    
    # ========== STEP 1: LOAD IMAGE ==========
    print("Step 1: Loading Image")
    print("-" * 60)
    img = load_image(image_path)
    if img is None:
        return
    
    height, width, channels = img.shape
    print(f"✓ Image loaded successfully")
    print(f"  Dimensions: {width}x{height}")
    print(f"  Channels: {channels}")
    print(f"  Size: {img.nbytes / 1024:.2f} KB")
    print()
    
    if show_steps:
        cv2.imshow('Original Image', img)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        print()
    
    # Store original for comparison
    original = img.copy()
    
    # ========== STEP 2: COLOR SPACE CONVERSIONS ==========
    print("Step 2: Color Space Conversions")
    print("-" * 60)
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    print("✓ Converted to grayscale")
    
    # Convert to HSV
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    print("✓ Converted to HSV")
    
    if show_steps:
        cv2.imshow('Grayscale', gray)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 3: RESIZING ==========
    print("Step 3: Resizing")
    print("-" * 60)
    
    # Create thumbnail (25% of original)
    thumbnail = cv2.resize(img, None, fx=0.25, fy=0.25)
    print(f"✓ Created thumbnail: {thumbnail.shape[1]}x{thumbnail.shape[0]}")
    
    # Create medium size (50% of original)
    medium = cv2.resize(img, None, fx=0.5, fy=0.5)
    print(f"✓ Created medium: {medium.shape[1]}x{medium.shape[0]}")
    
    if show_steps:
        cv2.imshow('Thumbnail', thumbnail)
        cv2.imshow('Medium Size', medium)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 4: FILTERS ==========
    print("Step 4: Applying Filters")
    print("-" * 60)
    
    # Gaussian blur
    blurred = cv2.GaussianBlur(img, (15, 15), 0)
    print("✓ Applied Gaussian blur")
    
    # Bilateral filter (smooth but preserve edges)
    smooth = cv2.bilateralFilter(img, 9, 75, 75)
    print("✓ Applied bilateral filter")
    
    # Median blur on grayscale
    median = cv2.medianBlur(gray, 5)
    print("✓ Applied median blur to grayscale")
    
    if show_steps:
        cv2.imshow('Blurred', blurred)
        cv2.imshow('Smooth (Bilateral)', smooth)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 5: BRIGHTNESS/CONTRAST ==========
    print("Step 5: Adjusting Brightness and Contrast")
    print("-" * 60)
    
    # Increase brightness and contrast
    enhanced = cv2.convertScaleAbs(img, alpha=1.2, beta=30)
    print("✓ Enhanced (alpha=1.2, beta=30)")
    
    # Create vintage look (lower contrast, slight warm tint)
    vintage = cv2.convertScaleAbs(img, alpha=0.8, beta=20)
    # Add warm tint by boosting red channel
    vintage[:, :, 2] = np.clip(vintage[:, :, 2].astype(np.int16) + 20, 0, 255).astype(np.uint8)
    print("✓ Created vintage effect")
    
    if show_steps:
        cv2.imshow('Enhanced', enhanced)
        cv2.imshow('Vintage', vintage)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 6: THRESHOLDING ==========
    print("Step 6: Thresholding")
    print("-" * 60)
    
    # Binary threshold
    _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    print("✓ Applied binary threshold")
    
    # Otsu's threshold
    otsu_val, otsu_binary = cv2.threshold(gray, 0, 255, 
                                           cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    print(f"✓ Applied Otsu threshold (value: {otsu_val:.1f})")
    
    # Adaptive threshold
    adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                      cv2.THRESH_BINARY, 11, 2)
    print("✓ Applied adaptive threshold")
    
    if show_steps:
        cv2.imshow('Binary', binary)
        cv2.imshow('Otsu', otsu_binary)
        cv2.imshow('Adaptive', adaptive)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 7: CREATIVE EFFECTS ==========
    print("Step 7: Creative Effects")
    print("-" * 60)
    
    # Edge detection using Canny (bonus technique!)
    edges = cv2.Canny(gray, 100, 200)
    print("✓ Detected edges (Canny)")
    
    # Posterize
    posterized = (img // 64) * 64
    print("✓ Posterized (reduced color levels)")
    
    # Channel swap
    b, g, r = cv2.split(img)
    swapped = cv2.merge([r, g, b])
    print("✓ Swapped color channels")
    
    # High contrast dramatic
    dramatic = cv2.convertScaleAbs(img, alpha=1.5, beta=-20)
    print("✓ Created dramatic high-contrast version")
    
    if show_steps:
        cv2.imshow('Edges', edges)
        cv2.imshow('Posterized', posterized)
        cv2.imshow('Channel Swapped', swapped)
        cv2.imshow('Dramatic', dramatic)
        print("Press any key to continue...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    print()
    
    # ========== STEP 8: SAVE ALL RESULTS ==========
    print("Step 8: Saving All Results")
    print("-" * 60)
    
    # Save all processed versions
    save_image(original, '01_original.jpg')
    save_image(gray, '02_grayscale.jpg')
    save_image(thumbnail, '03_thumbnail.jpg')
    save_image(medium, '04_medium.jpg')
    save_image(blurred, '05_blurred.jpg')
    save_image(smooth, '06_smooth_bilateral.jpg')
    save_image(enhanced, '07_enhanced.jpg')
    save_image(vintage, '08_vintage.jpg')
    save_image(binary, '09_binary.jpg')
    save_image(otsu_binary, '10_otsu.jpg')
    save_image(adaptive, '11_adaptive.jpg')
    save_image(edges, '12_edges.jpg')
    save_image(posterized, '13_posterized.jpg')
    save_image(swapped, '14_channel_swapped.jpg')
    save_image(dramatic, '15_dramatic.jpg')
    
    print()
    print("✓ All images saved to 'output' directory")
    print()
    
    # ========== SUMMARY ==========
    print("=" * 60)
    print("Processing Complete!")
    print("=" * 60)
    print()
    print("Summary:")
    print(f"  Input: {image_path}")
    print(f"  Original size: {width}x{height}")
    print(f"  Total outputs: 15 images")
    print()
    print("Techniques applied:")
    print("  ✓ Color space conversions (Grayscale, HSV)")
    print("  ✓ Resizing (Thumbnail, Medium)")
    print("  ✓ Filters (Gaussian, Bilateral, Median)")
    print("  ✓ Brightness/Contrast adjustments")
    print("  ✓ Thresholding (Binary, Otsu, Adaptive)")
    print("  ✓ Creative effects (Edges, Posterize, Channel swap)")
    print()
    print("Check the 'output' directory for all results!")
    print("=" * 60)

def main():
    """
    Main function with menu interface.
    """
    print()
    print("=" * 60)
    print("           COMPLETE IMAGE PROCESSOR")
    print("           Digital Doubles - Week 1")
    print("=" * 60)
    print()
    print("This program demonstrates a complete image processing pipeline")
    print("combining all the techniques from Week 1.")
    print()
    
    # Default image
    default_image = '../Resources/mountain.jpg'
    
    print(f"Default image: {default_image}")
    print()
    print("Options:")
    print("  1. Process default image (show all steps)")
    print("  2. Process default image (no display, just save)")
    print("  3. Process custom image")
    print("  4. Exit")
    print()
    
    choice = input("Enter your choice (1-4): ").strip()
    print()
    
    if choice == '1':
        process_image(default_image, show_steps=True)
    elif choice == '2':
        process_image(default_image, show_steps=False)
    elif choice == '3':
        custom_path = input("Enter path to your image: ").strip()
        if os.path.exists(custom_path):
            show = input("Show steps? (y/n): ").strip().lower() == 'y'
            process_image(custom_path, show_steps=show)
        else:
            print(f"Error: File not found: {custom_path}")
    elif choice == '4':
        print("Goodbye!")
    else:
        print("Invalid choice. Please run again.")

if __name__ == "__main__":
    main()
