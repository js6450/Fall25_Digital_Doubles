"""
Setup Verification Script
Digital Doubles - Week 1

This script checks if all required packages are installed correctly
and displays version numbers.

Run this script after installation to verify your environment is ready.
"""

import sys

def check_package(package_name, import_name=None):
    """
    Check if a package is installed and get its version.
    
    Args:
        package_name: Display name of the package
        import_name: Name to use for import (if different from package_name)
    """
    if import_name is None:
        import_name = package_name.lower().replace('-', '_')
    
    try:
        module = __import__(import_name)
        version = getattr(module, '__version__', 'unknown')
        print(f"✓ {package_name} installed successfully")
        print(f"  Version: {version}")
        return True
    except ImportError as e:
        print(f"✗ {package_name} not found")
        print(f"  Error: {e}")
        return False

def main():
    """Main verification function."""
    print("=" * 60)
    print("Digital Doubles - Setup Verification")
    print("=" * 60)
    print()
    
    # Check Python version
    print("Python version:")
    print(f"  {sys.version}")
    print()
    
    # Check if Python version is 3.8+
    if sys.version_info < (3, 8):
        print("⚠ WARNING: Python 3.8 or higher is recommended")
        print(f"  You are using Python {sys.version_info.major}.{sys.version_info.minor}")
        print()
    
    # Check required packages
    print("Checking required packages...")
    print("-" * 60)
    print()
    
    all_installed = True
    
    # Check OpenCV
    all_installed &= check_package("OpenCV", "cv2")
    print()
    
    # Check NumPy
    all_installed &= check_package("NumPy", "numpy")
    print()
    
    # Check Matplotlib
    all_installed &= check_package("Matplotlib", "matplotlib")
    print()
    
    # Summary
    print("-" * 60)
    if all_installed:
        print("✓ All required packages are installed!")
        print("\nYou're ready for Week 1 of Digital Doubles!")
        print("\nNext steps:")
        print("  1. Make sure your webcam is connected")
        print("  2. Check out the code examples in the Week1 folder")
        print("  3. Try running 02_image_loading_basics to test image loading")
    else:
        print("✗ Some packages are missing")
        print("\nPlease install missing packages using:")
        print("  pip install opencv-python numpy matplotlib")
        print("\nOr on macOS/Linux:")
        print("  pip3 install opencv-python numpy matplotlib")
    
    print()
    print("=" * 60)

if __name__ == "__main__":
    main()
