"""
Image Compositing
Digital Doubles - Week 1

This script demonstrates how to layer and composite images:
- Placing smaller images on larger backgrounds
- Positioning images at specific locations
- Simple alpha blending
- Creating collages
- Practical applications like watermarks and overlays

Understanding compositing is essential for creating complex visual compositions.

Press any key to move through the examples.
"""

import cv2
import numpy as np

def main():
    print("=" * 60)
    print("Image Compositing Demo")
    print("=" * 60)
    print()
    
    # Load images
    print("Loading images...")
    background = cv2.imread('../Resources/ocean.jpg')
    overlay1 = cv2.imread('../Resources/pinkflower.jpg')
    overlay2 = cv2.imread('../Resources/whiteflower.jpg')
    
    if background is None or overlay1 is None or overlay2 is None:
        print("Error: Could not load one or more images")
        return
    
    print("✓ Images loaded")
    print(f"  Background: {background.shape[1]}x{background.shape[0]}")
    print(f"  Overlay 1: {overlay1.shape[1]}x{overlay1.shape[0]}")
    print(f"  Overlay 2: {overlay2.shape[1]}x{overlay2.shape[0]}")
    print()
    
    # Display original images
    cv2.imshow('Background: Ocean', background)
    cv2.imshow('Overlay 1: Pink Flower', overlay1)
    cv2.imshow('Overlay 2: White Flower', overlay2)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== BASIC OVERLAY ==========
    print("1. BASIC IMAGE OVERLAY")
    print("=" * 60)
    print("Placing a smaller image on top of a larger background")
    print()
    
    # Prepare overlay (resize to smaller)
    overlay_small = cv2.resize(overlay1, (300, 300))
    
    # Create a copy of background
    result1 = background.copy()
    
    # Define position (top-left corner coordinates)
    x_offset, y_offset = 50, 50
    
    print(f"Placing 300x300 overlay at position ({x_offset}, {y_offset})")
    
    # Calculate the region where overlay will go
    y1, y2 = y_offset, y_offset + overlay_small.shape[0]
    x1, x2 = x_offset, x_offset + overlay_small.shape[1]
    
    # Place the overlay
    result1[y1:y2, x1:x2] = overlay_small
    
    cv2.imshow('1. Basic Overlay', result1)
    print("The overlay completely replaces the background pixels")
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== MULTIPLE OVERLAYS ==========
    print("2. MULTIPLE OVERLAYS")
    print("=" * 60)
    print("Placing multiple images on the same background")
    print()
    
    result2 = background.copy()
    
    # Resize both overlays
    overlay1_small = cv2.resize(overlay1, (250, 250))
    overlay2_small = cv2.resize(overlay2, (250, 250))
    
    # Place first overlay (top-left)
    x1, y1 = 50, 50
    result2[y1:y1+250, x1:x1+250] = overlay1_small
    print(f"✓ Placed overlay 1 at ({x1}, {y1})")
    
    # Place second overlay (bottom-right)
    bg_height, bg_width = background.shape[:2]
    x2 = bg_width - 250 - 50
    y2 = bg_height - 250 - 50
    result2[y2:y2+250, x2:x2+250] = overlay2_small
    print(f"✓ Placed overlay 2 at ({x2}, {y2})")
    
    cv2.imshow('2. Multiple Overlays', result2)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== ALPHA BLENDING ==========
    print("3. ALPHA BLENDING")
    print("=" * 60)
    print("Blending images together with transparency")
    print("Formula: output = alpha * overlay + (1 - alpha) * background")
    print()
    
    result3 = background.copy()
    
    # Prepare overlay
    overlay_blend = cv2.resize(overlay1, (400, 400))
    
    # Position
    x_pos, y_pos = 100, 100
    y1, y2 = y_pos, y_pos + 400
    x1, x2 = x_pos, x_pos + 400
    
    # Get the region of background
    bg_region = result3[y1:y2, x1:x2]
    
    # Blend with different alpha values
    print("a) 50% transparency (alpha=0.5)")
    alpha = 0.5
    blended_50 = cv2.addWeighted(bg_region, 1-alpha, overlay_blend, alpha, 0)
    result3_50 = result3.copy()
    result3_50[y1:y2, x1:x2] = blended_50
    cv2.imshow('3a. Alpha Blend (0.5)', result3_50)
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    print("b) 30% transparency (alpha=0.3)")
    alpha = 0.3
    blended_30 = cv2.addWeighted(bg_region, 1-alpha, overlay_blend, alpha, 0)
    result3_30 = result3.copy()
    result3_30[y1:y2, x1:x2] = blended_30
    cv2.imshow('3b. Alpha Blend (0.3)', result3_30)
    print("   More background visible")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    print()
    
    print("c) 70% transparency (alpha=0.7)")
    alpha = 0.7
    blended_70 = cv2.addWeighted(bg_region, 1-alpha, overlay_blend, alpha, 0)
    result3_70 = result3.copy()
    result3_70[y1:y2, x1:x2] = blended_70
    cv2.imshow('3c. Alpha Blend (0.7)', result3_70)
    print("   More overlay visible")
    print("   Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== CREATING A COLLAGE ==========
    print("4. CREATING A COLLAGE")
    print("=" * 60)
    print("Arranging multiple images in a grid")
    print()
    
    # Create a blank canvas
    canvas_height, canvas_width = 800, 1200
    collage = np.ones((canvas_height, canvas_width, 3), dtype=np.uint8) * 255  # White background
    
    # Resize images to fit
    tile_size = 300
    img1 = cv2.resize(background, (tile_size, tile_size))
    img2 = cv2.resize(overlay1, (tile_size, tile_size))
    img3 = cv2.resize(overlay2, (tile_size, tile_size))
    
    # Arrange in a grid (with spacing)
    spacing = 50
    
    # Top row
    collage[spacing:spacing+tile_size, spacing:spacing+tile_size] = img1
    collage[spacing:spacing+tile_size, spacing*2+tile_size:spacing*2+tile_size*2] = img2
    collage[spacing:spacing+tile_size, spacing*3+tile_size*2:spacing*3+tile_size*3] = img3
    
    # Bottom row
    collage[spacing*2+tile_size:spacing*2+tile_size*2, spacing:spacing+tile_size] = img3
    collage[spacing*2+tile_size:spacing*2+tile_size*2, spacing*2+tile_size:spacing*2+tile_size*2] = img1
    collage[spacing*2+tile_size:spacing*2+tile_size*2, spacing*3+tile_size*2:spacing*3+tile_size*3] = img2
    
    print("Created a 3x2 collage with spacing")
    cv2.imshow('4. Collage', collage)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== WATERMARK ==========
    print("5. ADDING A WATERMARK")
    print("=" * 60)
    print("A practical use case: adding a semi-transparent watermark")
    print()
    
    result5 = background.copy()
    
    # Create a simple text watermark (using pixel manipulation)
    # In practice, you'd use cv2.putText(), but this demonstrates compositing
    watermark = np.zeros((100, 300, 3), dtype=np.uint8)
    cv2.putText(watermark, 'SAMPLE', (10, 60), 
                cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    
    # Position watermark in bottom-right corner
    h, w = background.shape[:2]
    wm_h, wm_w = watermark.shape[:2]
    x_pos = w - wm_w - 20
    y_pos = h - wm_h - 20
    
    # Get background region
    bg_region = result5[y_pos:y_pos+wm_h, x_pos:x_pos+wm_w]
    
    # Blend watermark with low opacity
    alpha = 0.3
    watermarked_region = cv2.addWeighted(bg_region, 1-alpha, watermark, alpha, 0)
    result5[y_pos:y_pos+wm_h, x_pos:x_pos+wm_w] = watermarked_region
    
    print("Added semi-transparent watermark in corner")
    cv2.imshow('5. Watermarked Image', result5)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== PICTURE-IN-PICTURE ==========
    print("6. PICTURE-IN-PICTURE EFFECT")
    print("=" * 60)
    print("Creating a small inset image")
    print()
    
    result6 = background.copy()
    
    # Create small inset
    inset = cv2.resize(overlay1, (200, 200))
    
    # Add a white border to the inset
    border_size = 5
    inset_bordered = cv2.copyMakeBorder(inset, border_size, border_size, 
                                         border_size, border_size, 
                                         cv2.BORDER_CONSTANT, value=[255, 255, 255])
    
    # Place in top-right corner
    x_pos = background.shape[1] - inset_bordered.shape[1] - 20
    y_pos = 20
    
    result6[y_pos:y_pos+inset_bordered.shape[0], 
            x_pos:x_pos+inset_bordered.shape[1]] = inset_bordered
    
    print("Created picture-in-picture with white border")
    cv2.imshow('6. Picture-in-Picture', result6)
    print("Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print()
    
    # ========== PRACTICAL TIPS ==========
    print("7. PRACTICAL TIPS")
    print("=" * 60)
    print()
    print("Key considerations for compositing:")
    print("  1. Check image sizes match the region you're placing them in")
    print("  2. Use .copy() to avoid modifying original images")
    print("  3. Be careful with coordinate order: [y, x] not [x, y]")
    print("  4. Consider using alpha blending for smoother integration")
    print("  5. Add borders or shadows for better visual separation")
    print()
    print("Common use cases:")
    print("  - Watermarks (logos, copyright)")
    print("  - Picture-in-picture effects")
    print("  - Collages and photo grids")
    print("  - Overlays (UI elements, labels)")
    print("  - Artistic compositions")
    print()
    
    # ========== SAVING ==========
    print("8. SAVING COMPOSITED IMAGES")
    print("=" * 60)
    
    cv2.imwrite('output_basic_overlay.jpg', result1)
    cv2.imwrite('output_multiple_overlays.jpg', result2)
    cv2.imwrite('output_alpha_blend.jpg', result3_50)
    cv2.imwrite('output_collage.jpg', collage)
    cv2.imwrite('output_watermark.jpg', result5)
    cv2.imwrite('output_picture_in_picture.jpg', result6)
    
    print("✓ Saved 6 composited images")
    print()
    
    print("-" * 60)
    print("Demo complete!")
    print()
    print("Key takeaways:")
    print("  - Place images using: img[y1:y2, x1:x2] = overlay")
    print("  - Blend images using: cv2.addWeighted()")
    print("  - Always check that regions match overlay size")
    print("  - Use alpha blending for transparency effects")
    print("  - Create borders with cv2.copyMakeBorder()")
    print("  - Compositing is essential for complex visual compositions")
    print("=" * 60)

if __name__ == "__main__":
    main()
